/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configuración básica
  trailingSlash: false,
  output: 'export',
  distDir: 'out',

  // Desactivar errores durante build para deployment
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },

  // Optimizaciones de imagen para export estático
  images: {
    unoptimized: true,
    domains: ['localhost', 'custodia360.es', 'www.custodia360.es'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },

  // Configuración experimental
  experimental: {
    turbo: {
      // Configuración para Turbopack
    },
  },
};
