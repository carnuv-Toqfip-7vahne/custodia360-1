// Enhanced form data interface for complete automation
// custodia360 - Facturación y contabilidad automatizada

export interface EntityFormData {
  // DATOS BÁSICOS DE LA ENTIDAD
  nombre_entidad: string;
  cif: string;
  tipo_entidad: string;
  num_menores: string;

  // DIRECCIÓN FISCAL COMPLETA (para AEAT y Stripe)
  direccion_linea1: string;        // "Calle Mayor 123, 2º A"
  direccion_linea2?: string;       // "Edificio Central" (opcional)
  codigo_postal: string;           // "28001"
  ciudad: string;                  // "Madrid"
  provincia: string;               // "Madrid"
  pais: string;                    // "España" (por defecto, pero configurable)

  // CONTACTO PRINCIPAL
  responsable: string;             // Nombre del responsable principal
  cargo_responsable: string;       // "Director", "Presidente", "Coordinador"
  email: string;                   // Email principal
  telefono: string;                // Teléfono principal

  // FACTURACIÓN (si diferente al contacto principal)
  email_facturacion?: string;      // Email específico para facturas
  persona_facturacion?: string;    // Persona responsable de facturación
  telefono_facturacion?: string;   // Teléfono de facturación

  // DELEGADO DE PROTECCIÓN (si ya designado)
  delegado_designado?: string;     // Nombre del delegado
  email_delegado?: string;         // Email del delegado
  telefono_delegado?: string;      // Teléfono del delegado
  cargo_delegado?: string;         // "Coordinador", "Entrenador principal", etc.

  // PREFERENCIAS Y CONFIGURACIÓN
  idioma_preferido: string;        // "es", "ca", "gl", "eu"
  horario_contacto?: string;       // "9:00-18:00", "Tardes", etc.
  forma_comunicacion?: string;     // "email", "telefono", "whatsapp"

  // INFORMACIÓN ADICIONAL
  observaciones?: string;          // Notas específicas de la entidad
  tiene_varios_centros?: boolean;  // Si opera en múltiples ubicaciones
  centros_adicionales?: string;    // Lista de centros adicionales

  // METADATOS INTERNOS
  plan_seleccionado?: string;      // Plan automáticamente seleccionado
  incluye_kit?: boolean;           // Kit de comunicación
  origen_registro?: string;        // "web", "telefono", "referencia"
  campana_origen?: string;         // Para tracking de marketing
}

// Validaciones específicas por país
export interface CountryValidation {
  codigo_postal_pattern: string;
  cif_pattern: string;
  telefono_pattern: string;
  required_fields: string[];
}

// Configuración por países (extensible)
export const COUNTRY_CONFIG: Record<string, CountryValidation> = {
  ES: {
    codigo_postal_pattern: '^[0-9]{5}$',
    cif_pattern: '^[A-HJ-NP-SUVW][0-9]{7}[0-9A-J]$|^[0-9]{8}[A-Z]$',
    telefono_pattern: '^[6-9][0-9]{8}$',
    required_fields: ['codigo_postal', 'provincia']
  },
  // Preparado para expansión internacional
  FR: {
    codigo_postal_pattern: '^[0-9]{5}$',
    cif_pattern: '^FR[0-9A-Z]{2}[0-9]{9}$',
    telefono_pattern: '^[0-9]{10}$',
    required_fields: ['codigo_postal', 'provincia']
  }
}

// Tipos de entidad expandidos
export const TIPOS_ENTIDAD = {
  // DEPORTIVAS
  'club_deportivo': 'Club Deportivo',
  'federacion': 'Federación Deportiva',
  'escuela_deportiva': 'Escuela Deportiva',
  'gimnasio': 'Gimnasio/Centro Fitness',

  // EDUCATIVAS
  'academia': 'Academia/Centro de Estudios',
  'conservatorio': 'Conservatorio/Escuela de Música',
  'centro_idiomas': 'Centro de Idiomas',
  'extraescolar': 'Actividades Extraescolares',

  // RELIGIOSAS
  'parroquia': 'Parroquia/Iglesia',
  'catequesis': 'Grupo de Catequesis',
  'movimiento_religioso': 'Movimiento Religioso',
  'seminario': 'Seminario/Centro Religioso',

  // OCIO Y TIEMPO LIBRE
  'centro_ocio': 'Centro de Ocio',
  'campamento': 'Campamento/Colonia',
  'ludoteca': 'Ludoteca',
  'scout': 'Grupo Scout',

  // ASOCIACIONES
  'asociacion_cultural': 'Asociación Cultural',
  'ong': 'ONG/Fundación',
  'centro_juvenil': 'Centro Juvenil',
  'otro': 'Otro'
} as const

// Cargos típicos por tipo de entidad
export const CARGOS_POR_TIPO = {
  'club_deportivo': ['Presidente', 'Director Deportivo', 'Coordinador', 'Entrenador Principal'],
  'parroquia': ['Párroco', 'Coordinador Pastoral', 'Catequista Principal', 'Responsable Juvenil'],
  'academia': ['Director', 'Coordinador Académico', 'Responsable de Centro'],
  'asociacion_cultural': ['Presidente', 'Secretario', 'Coordinador de Actividades'],
  'default': ['Director', 'Presidente', 'Coordinador', 'Responsable', 'Otro']
} as const
