import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, AlertTriangle, Users, FileText } from 'lucide-react'

export const metadata: Metadata = {
  title: '¿Qué es LOPIVI? - Ley Orgánica de Protección Infantil | Custodia360',
  description: 'Todo sobre la LOPIVI: qué es, a quién afecta, obligaciones y cómo cumplirla. Guía completa de la Ley Orgánica de Protección Integral a la Infancia y la Adolescencia.',
}

export default function LopiviPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            ¿Qué es la <span className="text-orange-600">LOPIVI</span>?
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            La Ley Orgánica de Protección Integral a la Infancia y la Adolescencia frente a la Violencia
          </p>
        </div>
      </section>

      {/* Definición */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-blue-50 rounded-lg p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Definición</h2>
            <p className="text-lg text-gray-700 mb-4">
              La LOPIVI es una ley española que entró en vigor el <strong>25 de junio de 2021</strong> con el objetivo de proteger a los menores de edad frente a cualquier forma de violencia.
            </p>
            <p className="text-lg text-gray-700">
              Esta ley establece un marco integral de medidas de sensibilización, prevención, detección, protección y reparación dirigido a todos los ámbitos donde se desarrolla la vida de los niños, niñas y adolescentes.
            </p>
          </div>

          {/* A quién afecta */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-orange-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <Users className="h-8 w-8 text-orange-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">¿A quién afecta?</h3>
              </div>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Centros educativos</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Centros deportivos</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Centros de ocio y tiempo libre</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Centros religiosos</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Entidades que trabajen con menores</span>
                </li>
              </ul>
            </div>

            <div className="bg-red-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">Obligaciones Principales</h3>
              </div>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Designar un delegado de protección</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Crear protocolos de actuación</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Formar al personal</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Establecer canales seguros</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Mantener registros</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Delegado de Protección */}
          <div className="bg-blue-50 rounded-lg p-8 mb-12">
            <div className="flex items-center mb-6">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">El Delegado de Protección</h3>
            </div>
            <p className="text-lg text-gray-700 mb-6">
              Figura clave del sistema de protección que debe ser designada por todas las entidades que trabajen con menores.
            </p>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Funciones:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Promover medidas de protección</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Coordinar con autoridades</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Formar al personal</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Gestionar comunicaciones</span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-gray-900 mb-3">Requisitos:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Formación especializada</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Disponibilidad permanente</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Conocimiento normativo</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                    <span className="text-gray-700">Capacidad de coordinación</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Sanciones */}
          <div className="bg-red-50 rounded-lg p-8 mb-12">
            <div className="flex items-center mb-6">
              <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">Sanciones por Incumplimiento</h3>
            </div>
            <p className="text-lg text-gray-700 mb-6">
              El incumplimiento de la LOPIVI puede conllevar sanciones graves para las entidades:
            </p>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">Leves</div>
                <p className="text-gray-700">Hasta 10.000€</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">Graves</div>
                <p className="text-gray-700">10.001€ - 100.000€</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">Muy Graves</div>
                <p className="text-gray-700">100.001€ - 1.000.000€</p>
              </div>
            </div>

            <div className="bg-red-100 rounded-lg p-4 mt-6">
              <p className="text-red-800 font-medium text-center">
                ⚠️ Además de las multas, puede haber cierre temporal o definitivo de la entidad
              </p>
            </div>
          </div>

          {/* Documentos Necesarios */}
          <div className="bg-green-50 rounded-lg p-8">
            <div className="flex items-center mb-6">
              <FileText className="h-8 w-8 text-green-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">Documentos Necesarios</h3>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Plan de protección integral</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Protocolos de actuación</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Código de conducta</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Manual de buenas prácticas</span>
                </li>
              </ul>

              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Registros de formación</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Canales de comunicación</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Designación del delegado</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Sistema de seguimiento</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Necesitas ayuda con la LOPIVI?</h2>
          <p className="text-xl mb-8 opacity-90">Te ayudamos a cumplir toda la normativa en 24 horas</p>

          <div className="flex justify-center gap-4">
            <Link
              href="/planes"
              className="px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Ver Planes
            </Link>
            <Link
              href="/contacto"
              className="px-8 py-4 bg-orange-700 text-white border-2 border-white rounded-lg hover:bg-orange-800 transition-colors font-semibold"
            >
              Contactar
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
