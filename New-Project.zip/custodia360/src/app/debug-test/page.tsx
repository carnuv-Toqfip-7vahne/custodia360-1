'use client'

import Link from 'next/link'

export default function DebugTestPage() {

  const handleDirectRedirect = () => {
    if (typeof window !== 'undefined') {
      alert('Simulando redirect directo...')
      window.location.href = '/contratacion/success?plan=test&entity=TestEntity'
    }
  }

  const handleDelayedRedirect = () => {
    if (typeof window !== 'undefined') {
      alert('Simulando redirect tipo Stripe...')
      setTimeout(() => {
        window.location.href = '/contratacion/success?plan=stripe-test&entity=StripeEntity'
      }, 1000)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            🔧 DEBUG - Pruebas Sistemáticas
          </h1>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Success Pages Tests */}
            <div className="bg-blue-50 rounded-lg p-6">
              <h3 className="text-xl font-bold text-blue-900 mb-4">📄 Success Pages</h3>
              <div className="space-y-3">
                <Link
                  href="/success-test"
                  className="block w-full bg-blue-600 text-white py-2 px-4 rounded text-center hover:bg-blue-700"
                >
                  Success Test (Estático)
                </Link>

                <Link
                  href="/contratacion/success"
                  className="block w-full bg-blue-600 text-white py-2 px-4 rounded text-center hover:bg-blue-700"
                >
                  Success Original (Sin parámetros)
                </Link>

                <Link
                  href="/contratacion/success?plan=1-50&entity=Club%20Test"
                  className="block w-full bg-blue-600 text-white py-2 px-4 rounded text-center hover:bg-blue-700"
                >
                  Success con Parámetros
                </Link>
              </div>
            </div>

            {/* Payment Flow Tests */}
            <div className="bg-green-50 rounded-lg p-6">
              <h3 className="text-xl font-bold text-green-900 mb-4">💳 Payment Flow</h3>
              <div className="space-y-3">
                <Link
                  href="/contratacion"
                  className="block w-full bg-green-600 text-white py-2 px-4 rounded text-center hover:bg-green-700"
                >
                  Formulario Contratación
                </Link>

                <Link
                  href="/contratacion?plan=1-50"
                  className="block w-full bg-green-600 text-white py-2 px-4 rounded text-center hover:bg-green-700"
                >
                  Contratación con Plan
                </Link>

                <Link
                  href="/planes"
                  className="block w-full bg-green-600 text-white py-2 px-4 rounded text-center hover:bg-green-700"
                >
                  Página Planes
                </Link>
              </div>
            </div>

            {/* Direct Redirects */}
            <div className="bg-orange-50 rounded-lg p-6">
              <h3 className="text-xl font-bold text-orange-900 mb-4">🔄 Redirects</h3>
              <div className="space-y-3">
                <button
                  onClick={handleDirectRedirect}
                  className="block w-full bg-orange-600 text-white py-2 px-4 rounded text-center hover:bg-orange-700"
                >
                  Redirect Directo (JS)
                </button>

                <button
                  onClick={handleDelayedRedirect}
                  className="block w-full bg-orange-600 text-white py-2 px-4 rounded text-center hover:bg-orange-700"
                >
                  Redirect con Delay (Tipo Stripe)
                </button>
              </div>
            </div>

            {/* Main Pages */}
            <div className="bg-purple-50 rounded-lg p-6">
              <h3 className="text-xl font-bold text-purple-900 mb-4">🏠 Páginas Principales</h3>
              <div className="space-y-3">
                <Link
                  href="/"
                  className="block w-full bg-purple-600 text-white py-2 px-4 rounded text-center hover:bg-purple-700"
                >
                  Página Principal
                </Link>

                <Link
                  href="/contacto"
                  className="block w-full bg-purple-600 text-white py-2 px-4 rounded text-center hover:bg-purple-700"
                >
                  Contacto
                </Link>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="mt-8 bg-gray-100 rounded-lg p-6">
            <h3 className="font-bold text-gray-900 mb-3">📋 Instrucciones de Debug:</h3>
            <ol className="list-decimal list-inside space-y-2 text-gray-700">
              <li>Prueba primero "Success Test (Estático)" - debe funcionar SIEMPRE</li>
              <li>Prueba "Success Original (Sin parámetros)" - debe funcionar</li>
              <li>Prueba "Success con Parámetros" - debe mostrar los parámetros</li>
              <li>Prueba los redirects directos - simulan lo que hace Stripe</li>
              <li>Si alguno falla, reporta exactamente cuál</li>
            </ol>
          </div>

          {/* Current URL Info */}
          <div className="mt-6 bg-yellow-50 rounded-lg p-4">
            <h4 className="font-medium text-yellow-800 mb-2">🌐 URL Actual:</h4>
            <p className="text-yellow-700 text-sm break-all">
              {typeof window !== 'undefined' ? window.location.href : 'Calculando...'}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
