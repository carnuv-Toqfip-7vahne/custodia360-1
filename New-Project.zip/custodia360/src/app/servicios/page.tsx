import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, Users, BookOpen, Award, CheckCircle, ArrowRight } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Servicios LOPIVI - Implementación Completa | Custodia360',
  description: 'Servicios completos de implementación LOPIVI: delegado certificado, protocolos, formación y cumplimiento garantizado en 24 horas.',
}

export default function ServiciosPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-red-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Servicios <span className="text-orange-600">LOPIVI</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Plan de protección e implementación completa y automatizada en 24 horas
          </p>
        </div>
      </section>

      {/* Servicios Principales */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">

            {/* Implementación LOPIVI */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Shield className="h-12 w-12 text-orange-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Implementación LOPIVI</h3>
                  <p className="text-orange-600">Cumplimiento total en 24 horas</p>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Análisis completo de la normativa</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Listo para tu entidad</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Documentación completa generada</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Sistema de gestión integrado</span>
                </li>
              </ul>
            </div>

            {/* Delegado Certificado */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Award className="h-12 w-12 text-blue-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Delegado Certificado</h3>
                  <p className="text-blue-600">Profesional especializado</p>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Formación especializada LOPIVI</span>
                </li>

                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Gestión de casos especializada</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Coordinación con autoridades</span>
                </li>
              </ul>
            </div>

            {/* Protocolos */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <BookOpen className="h-12 w-12 text-green-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Protocolos</h3>
                  <p className="text-green-600">Procedimientos claros y efectivos</p>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Protocolos de prevención</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Procedimientos de actuación</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Registros y documentación</span>
                </li>
              </ul>
            </div>

            {/* Formación */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Users className="h-12 w-12 text-purple-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Formación</h3>
                  <p className="text-purple-600">Capacitación continua del equipo</p>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Formación inicial obligatoria</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Actualizaciones periódicas</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Material didáctico incluido</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <span className="text-gray-700">Certificados de participación</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Proceso */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Nuestro Proceso</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">1</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Contratación</h3>
              <p className="text-gray-600">Selecciona tu plan y completa el pago online</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">2</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Implementación</h3>
              <p className="text-gray-600">Desplegamos todos los sistemas en 24 horas</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">3</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Mantenimiento</h3>
              <p className="text-gray-600">Soporte continuo, actualizaciones automáticas y botón de acciones rápidas para casos urgentes con pasos claros</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Listo para implementar la LOPIVI?</h2>
          <p className="text-xl mb-8 opacity-90">Comenzemos hoy mismo con tu protección</p>

          <div className="flex justify-center gap-4">
            <Link
              href="/planes"
              className="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-medium rounded-lg hover:bg-gray-100 transition-colors"
            >
              Ver Planes <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              href="/contacto"
              className="inline-flex items-center px-8 py-4 bg-orange-700 text-white border-2 border-white font-medium rounded-lg hover:bg-orange-800 transition-colors"
            >
              Contactar
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
