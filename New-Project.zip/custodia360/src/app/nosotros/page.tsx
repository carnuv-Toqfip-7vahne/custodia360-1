import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, Target, Users, Award, CheckCircle } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Sobre Nosotros - Custodia360 | Primera empresa automatizada LOPIVI',
  description: 'Conoce Custodia360, la primera empresa automatizada de España especializada en cumplimiento LOPIVI. Nuestra misión, visión y valores.',
}

export default function NosotrosPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-red-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Sobre <span className="text-orange-600">Nosotros</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Primera empresa automatizada de España especializada en cumplimiento LOPIVI
          </p>
        </div>
      </section>

      {/* Nuestra Historia */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Nuestra Historia</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Cuando entró en vigor la LOPIVI en 2021, observamos que las entidades enfrentaban enormes dificultades:
              consultorías tradicionales que cobraban miles de euros, procesos que duraban meses, y documentación
              compleja que generaba más confusión que protección.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed mt-4">
              Decidimos revolucionar este sector desarrollando la primera plataforma completamente automatizada
              que implementa toda la normativa LOPIVI en 24 horas, reduciendo costes en un 97% y garantizando
              el cumplimiento total.
            </p>
          </div>
        </div>
      </section>

      {/* Misión, Visión, Valores */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">

            {/* Misión */}
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <Target className="h-12 w-12 text-orange-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Misión</h3>
              <p className="text-gray-600">
                Democratizar el acceso al cumplimiento LOPIVI mediante tecnología avanzada,
                haciendo que la protección infantil sea accesible, rápida y efectiva para todas las entidades.
              </p>
            </div>

            {/* Visión */}
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Visión</h3>
              <p className="text-gray-600">
                Ser la referencia europea en protección infantil automatizada,
                garantizando que ningún menor esté desprotegido por falta de recursos o conocimiento.
              </p>
            </div>

            {/* Valores */}
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Valores</h3>
              <p className="text-gray-600">
                Innovación, transparencia, compromiso social y excelencia técnica.
                Cada línea de código está pensada para proteger a los menores.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Nuestro Equipo */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Nuestro Equipo</h2>
            <p className="text-lg text-gray-600">
              Un equipo multidisciplinar de especialistas en protección infantil, tecnología y derecho
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-green-50 rounded-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Equipo Técnico</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-1" />
                  <span className="text-gray-700">Desarrolladores especializados</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-1" />
                  <span className="text-gray-700">Arquitectos de software</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-1" />
                  <span className="text-gray-700">Especialistas en seguridad</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-1" />
                  <span className="text-gray-700">Expertos en automatización</span>
                </li>
              </ul>
            </div>

            <div className="bg-blue-50 rounded-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Equipo de Abogados Especialistas</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                  <span className="text-gray-700">Abogados especializados en LOPIVI</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                  <span className="text-gray-700">Expertos en protección de menores</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                  <span className="text-gray-700">Consultores en normativa deportiva</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                  <span className="text-gray-700">Asesores jurídicos en cumplimiento</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Nuestros Principios */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Nuestros Principios</h2>
            <p className="text-lg text-gray-600">Los valores que guían cada decisión en custodia360</p>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="flex items-start">
                <Award className="h-8 w-8 text-orange-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Excelencia Técnica</h3>
                  <p className="text-gray-600">
                    Cada línea de código, cada proceso, cada documento está diseñado con la máxima
                    precisión para garantizar la protección efectiva de los menores.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="flex items-start">
                <Shield className="h-8 w-8 text-blue-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Seguridad y Privacidad</h3>
                  <p className="text-gray-600">
                    Todos los datos están protegidos con los más altos estándares de seguridad.
                    La confidencialidad es sagrada en nuestro trabajo.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="flex items-start">
                <Users className="h-8 w-8 text-green-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Compromiso Social</h3>
                  <p className="text-gray-600">
                    No es solo nuestro trabajo, es nuestra vocación. Cada entidad que protegemos
                    representa miles de menores más seguros.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="flex items-start">
                <Target className="h-8 w-8 text-purple-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Innovación Constante</h3>
                  <p className="text-gray-600">
                    La normativa evoluciona, las amenazas cambian, y nosotros nos adaptamos.
                    Actualizamos automáticamente para estar siempre al día.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Quieres formar parte de nuestra misión?</h2>
          <p className="text-xl mb-8 opacity-90">Únete a las entidades que ya protegen a sus menores con custodia360</p>

          <div className="flex justify-center gap-4">
            <Link
              href="/planes"
              className="px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Ver Planes
            </Link>
            <Link
              href="/contacto"
              className="px-8 py-4 bg-orange-700 text-white border-2 border-white rounded-lg hover:bg-orange-800 transition-colors font-semibold"
            >
              Contactar
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
