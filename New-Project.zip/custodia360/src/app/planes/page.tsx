import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, Check, Clock, Users, Star, FileText, Zap } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Planes LOPIVI - Custodia360 | Precios y Características',
  description: 'Planes flexibles para cumplir la LOPIVI. Desde 19€ + IVA. Implementación en 24 horas con delegado certificado incluido.',
}

export default function PlanesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Planes <span className="text-orange-600">Custodia360</span>
          </h1>
          <p className="text-xl text-gray-600 mb-4">
            Todos los planes incluyen exactamente lo mismo
          </p>
          <div className="bg-orange-100 border border-orange-200 rounded-lg p-4 mb-8 max-w-2xl mx-auto">
            <p className="text-lg text-orange-800 font-semibold mb-2">
              💳 Pago fraccionado sin intereses
            </p>
            <p className="text-gray-700">
              Solo varía el precio según el número de menores. <strong>Paga solo el 50% ahora y el resto a los 6 meses</strong> sin ningún coste adicional.
            </p>
          </div>

          <div className="flex justify-center gap-4 mb-8">
            <Link
              href="/demo"
              className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold"
            >
              Ver Demo
            </Link>
            <Link
              href="/contacto"
              className="px-6 py-3 bg-white text-orange-600 border-2 border-orange-600 rounded-lg hover:bg-orange-50 transition-colors font-semibold"
            >
              Contactar
            </Link>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">24h</div>
              <div className="text-gray-600 text-sm">Implementación</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">100%</div>
              <div className="text-gray-600 text-sm">Automatizado</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">97%</div>
              <div className="text-gray-600 text-sm">Ahorro vs tradicional</div>
            </div>
          </div>
        </div>
      </section>

      {/* Planes Principales */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Planes Principales</h2>
            <p className="text-xl text-gray-600">Selecciona según el número de menores de tu entidad</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {/* Plan 1-50 */}
            <div className="bg-blue-50 rounded-lg shadow-lg p-8 border-2 border-blue-200 relative">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">1-50 menores</h3>
                <div className="text-5xl font-bold text-blue-600 mb-2">19€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
                <div className="bg-blue-100 rounded-lg p-3 mt-4">
                  <div className="text-blue-800 font-medium">+ 19€ a los 6 meses (+IVA)</div>
                  <div className="text-sm text-blue-600 mt-1">• Implementación completa en 24h</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Delegado de protección formado</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Plan de protección</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Protocolos de actuación</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Formación del personal</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Documentación completa</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=1-50"
                className="w-full bg-blue-600 text-white py-4 rounded-lg hover:bg-blue-700 transition-colors font-bold text-lg text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Plan 51-200 */}
            <div className="bg-green-50 rounded-lg shadow-lg p-8 border-2 border-green-200 relative">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">51-200 menores</h3>
                <div className="text-5xl font-bold text-green-600 mb-2">49€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
                <div className="bg-green-100 rounded-lg p-3 mt-4">
                  <div className="text-green-800 font-medium">+ 49€ a los 6 meses (+IVA)</div>
                  <div className="text-sm text-green-600 mt-1">• Implementación completa en 24h</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Delegado de protección formado</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Plan de protección</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Protocolos de actuación</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Formación del personal</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Documentación completa</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=51-200"
                className="w-full bg-green-600 text-white py-4 rounded-lg hover:bg-green-700 transition-colors font-bold text-lg text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Plan 201-500 */}
            <div className="bg-purple-50 rounded-lg shadow-lg p-8 border-2 border-purple-200 relative">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">201-500 menores</h3>
                <div className="text-5xl font-bold text-purple-600 mb-2">105€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
                <div className="bg-purple-100 rounded-lg p-3 mt-4">
                  <div className="text-purple-800 font-medium">+ 105€ a los 6 meses (+IVA)</div>
                  <div className="text-sm text-purple-600 mt-1">• Implementación completa en 24h</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Delegado de protección formado</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Plan de protección</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Protocolos de actuación</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Formación del personal</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Documentación completa</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=201-500"
                className="w-full bg-purple-600 text-white py-4 rounded-lg hover:bg-purple-700 transition-colors font-bold text-lg text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>
          </div>

          {/* Plan +501 y Planes Especiales */}
          <div className="grid md:grid-cols-3 gap-8">
            {/* Plan +501 */}
            <div className="bg-slate-50 rounded-lg shadow-lg p-8 border-2 border-slate-200">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">+501 menores</h3>
                <div className="text-5xl font-bold text-slate-600 mb-2">250€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
                <div className="bg-slate-100 rounded-lg p-3 mt-4">
                  <div className="text-slate-800 font-medium">+ 250€ a los 6 meses (+IVA)</div>
                  <div className="text-sm text-slate-600 mt-1">• Entidades Multideporte</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Delegado de protección formado</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Plan de protección</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Protocolos de actuación</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Formación del personal</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Documentación completa</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=501+"
                className="w-full bg-slate-600 text-white py-4 rounded-lg hover:bg-slate-700 transition-colors font-bold text-lg text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Custodia Temporal */}
            <div className="bg-yellow-50 rounded-lg shadow-lg p-8 border-2 border-yellow-200">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Custodia Temporal</h3>
                <div className="text-5xl font-bold text-yellow-600 mb-2">39€</div>
                <div className="text-gray-600">(+IVA) Pago único</div>
                <div className="bg-yellow-100 rounded-lg p-3 mt-4">
                  <div className="text-yellow-800 font-medium">Hasta 60 días</div>
                  <div className="text-sm text-yellow-600 mt-1">• Torneos, festivales, campus</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Delegado de protección temporal</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Protocolos básicos de actuación</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Documentación específica</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Cobertura completa del evento</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=temporal"
                className="w-full bg-yellow-600 text-white py-4 rounded-lg hover:bg-yellow-700 transition-colors font-bold text-lg text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Kit de Comunicación */}
            <div className="bg-teal-50 rounded-lg shadow-lg p-8 border-2 border-teal-200">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Kit de Comunicación</h3>
                <div className="text-5xl font-bold text-teal-600 mb-2">30€</div>
                <div className="text-gray-600">(+IVA) Pago único</div>
                <div className="bg-teal-100 rounded-lg p-3 mt-4">
                  <div className="text-teal-800 font-medium">Material LOPIVI</div>
                  <div className="text-sm text-teal-600 mt-1">• Carteles, comunicados, templates</div>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Qué incluye:</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Carteles informativos LOPIVI</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Comunicados para familias</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Templates personalizados</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span className="text-gray-700">Entrega en 24 horas</span>
                  </li>
                </ul>
              </div>

              <Link
                href="/kit-comunicacion"
                className="w-full bg-teal-600 text-white py-4 rounded-lg hover:bg-teal-700 transition-colors font-bold text-lg text-center block"
              >
                📋 Ver Kit
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Pago Fraccionado Destacado */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            💳 Pago Fraccionado Sin Intereses
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            No necesitas pagar todo de una vez. Facilitamos el cumplimiento LOPIVI con un sistema de pago cómodo y accesible.
          </p>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            <div className="bg-white bg-opacity-20 rounded-lg p-6 backdrop-blur-sm">
              <div className="text-4xl font-bold text-white mb-2">50%</div>
              <div className="text-orange-100 font-semibold mb-2">Pago Inicial</div>
              <div className="text-sm text-orange-100">
                Implementación inmediata en 24 horas
              </div>
            </div>

            <div className="bg-white bg-opacity-20 rounded-lg p-6 backdrop-blur-sm">
              <div className="text-4xl font-bold text-white mb-2">50%</div>
              <div className="text-orange-100 font-semibold mb-2">A los 6 meses</div>
              <div className="text-sm text-orange-100">
                Sin intereses ni comisiones adicionales
              </div>
            </div>
          </div>

          <p className="text-orange-100 mt-8 text-lg">
            <strong>Sin letra pequeña.</strong> Es exactamente lo que lees: pagas la mitad ahora y la mitad en 6 meses, sin ningún coste extra.
          </p>
        </div>
      </section>

      {/* Comparación */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Por qué Custodia360?</h2>
            <p className="text-xl text-gray-600">Comparación con métodos tradicionales</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Método Tradicional */}
            <div className="bg-red-50 rounded-lg p-8 border-2 border-red-200">
              <h3 className="text-2xl font-bold text-red-600 mb-6 text-center">❌ Método Tradicional</h3>

              <div className="space-y-4">
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-red-500 mr-3" />
                  <span className="text-gray-700">3-6 meses de implementación</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">💰</span>
                  <span className="text-gray-700">Entre 2.000€ - 8.000€ en consultorías</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">📋</span>
                  <span className="text-gray-700">Documentación genérica no personalizada</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">😰</span>
                  <span className="text-gray-700">Estrés y complejidad constante</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">🔄</span>
                  <span className="text-gray-700">Sin actualizaciones automáticas</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">⚠️</span>
                  <span className="text-gray-700">Riesgo de errores y multas</span>
                </div>
              </div>
            </div>

            {/* custodia360 */}
            <div className="bg-green-50 rounded-lg p-8 border-2 border-green-200">
              <h3 className="text-2xl font-bold text-green-600 mb-6 text-center">✅ Custodia360</h3>

              <div className="space-y-4">
                <div className="flex items-center">
                  <Zap className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Implementación en 24 horas</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">💵</span>
                  <span className="text-gray-700">Desde solo 19€ + IVA</span>
                </div>
                <div className="flex items-center">
                  <FileText className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Documentación personalizada</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">😌</span>
                  <span className="text-gray-700">Tranquilidad total garantizada</span>
                </div>
                <div className="flex items-center">
                  <span className="text-2xl mr-3">🔄</span>
                  <span className="text-gray-700">Actualizaciones automáticas incluidas</span>
                </div>
                <div className="flex items-center">
                  <Shield className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Cumpliendo</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Preguntas Frecuentes</h2>
            <p className="text-xl text-gray-600">Resolvemos las dudas más comunes sobre nuestros planes</p>
          </div>

          <div className="space-y-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Todos los planes incluyen lo mismo?</h3>
              <p className="text-gray-600">
                Sí, todos los planes incluyen exactamente los mismos servicios: delegado formado,
                documentación completa, formación del personal y soporte. Solo varía el precio según
                el número de menores.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Cómo funciona el pago en dos plazos?</h3>
              <p className="text-gray-600">
                Pagas la mitad del importe al contratar (implementación inmediata en 24h) y
                la otra mitad a los 6 meses. Esto hace que sea más accesible para todas las entidades.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Qué pasa si mi entidad crece y necesito cambiar de plan?</h3>
              <p className="text-gray-600">
                No hay problema. Contacta con nosotros y ajustamos tu plan al número actual de menores.
                Solo pagas la diferencia prorrateada.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿El Kit de Comunicación es obligatorio?</h3>
              <p className="text-gray-600">
                No, es opcional. Pero es muy recomendable porque te ayuda a comunicar correctamente
                las medidas LOPIVI a familias y personal, mejorando la transparencia.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Qué ocurre después de los 12 meses?</h3>
              <p className="text-gray-600">
                El servicio se renueva automáticamente para mantener el cumplimiento al día.
                Te avisamos con antelación y puedes cancelar cuando quieras.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">¿Listo para cumplir la LOPIVI?</h2>
          <p className="text-xl mb-8 opacity-90">
            Selecciona tu plan y comienza la implementación en 24 horas
          </p>

          <div className="flex justify-center gap-4">
            <Link
              href="/contratacion"
              className="px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold text-lg"
            >
              Empezar Ahora
            </Link>
            <Link
              href="/demo"
              className="px-8 py-4 bg-orange-700 text-white border-2 border-white rounded-lg hover:bg-orange-800 transition-colors font-semibold text-lg"
            >
              Ver Demo
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
