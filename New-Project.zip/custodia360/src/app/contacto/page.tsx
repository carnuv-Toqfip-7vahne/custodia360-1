import type { Metadata } from 'next'
import Link from 'next/link'
import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Contacto - Custodia360 | Especialistas en LOPIVI y Plan de Protección',
  description: 'Contacta con Custodia360 para implementar la LOPIVI y Plan de Protección en tu entidad. Teléfono, email y formulario de contacto disponibles.',
}

export default function ContactoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-red-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            <span className="text-orange-600">Contacto</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Estamos aquí para ayudarte con la implementación LOPIVI y Plan de Protección
          </p>
        </div>
      </section>

      {/* Información de Contacto */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">

            {/* Información */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Hablemos</h2>
              <p className="text-lg text-gray-600 mb-8">
                ¿Necesitas implementar la LOPIVI en tu entidad? Nuestro equipo especializado está disponible para ayudarte.
              </p>

              <div className="space-y-6">
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-orange-600 mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Teléfono</h3>
                    <p className="text-gray-600">678 771 198</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-orange-600 mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Email</h3>
                    <p className="text-gray-600">info@custodia360.es</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <MapPin className="h-6 w-6 text-orange-600 mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Ubicación</h3>
                    <p className="text-gray-600">Barcelona, España</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <Clock className="h-6 w-6 text-orange-600 mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Horario</h3>
                    <p className="text-gray-600">Lunes a Viernes: 9:00 - 18:00</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <MessageCircle className="h-6 w-6 text-orange-600 mr-4" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Respuesta</h3>
                    <p className="text-gray-600">Menos de 2 horas en horario laboral</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Formulario */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Envíanos un mensaje</h3>

              <form className="space-y-6">
                <div>
                  <label htmlFor="nombre" className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    id="nombre"
                    name="nombre"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Tu nombre completo"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="tu@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="telefono" className="block text-sm font-medium text-gray-700 mb-2">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    id="telefono"
                    name="telefono"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="678 123 456"
                  />
                </div>

                <div>
                  <label htmlFor="entidad" className="block text-sm font-medium text-gray-700 mb-2">
                    Entidad/Organización *
                  </label>
                  <input
                    type="text"
                    id="entidad"
                    name="entidad"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Nombre de tu entidad"
                  />
                </div>

                <div>
                  <label htmlFor="menores" className="block text-sm font-medium text-gray-700 mb-2">
                    Número aproximado de menores
                  </label>
                  <select
                    id="menores"
                    name="menores"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="">Selecciona un rango</option>
                    <option value="1-50">1-50 menores</option>
                    <option value="51-200">51-200 menores</option>
                    <option value="201-500">201-500 menores</option>
                    <option value="501+">Más de 501 menores</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="mensaje" className="block text-sm font-medium text-gray-700 mb-2">
                    Mensaje *
                  </label>
                  <textarea
                    id="mensaje"
                    name="mensaje"
                    rows={5}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Cuéntanos sobre tu entidad y qué necesitas..."
                  ></textarea>
                </div>

                <div className="flex items-start">
                  <input
                    id="acepto"
                    name="acepto"
                    type="checkbox"
                    required
                    className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded mt-1"
                  />
                  <label htmlFor="acepto" className="ml-3 text-sm text-gray-700">
                    Acepto la <Link href="/privacidad" className="text-orange-600 hover:text-orange-700">política de privacidad</Link> y el tratamiento de mis datos *
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors font-semibold"
                >
                  Enviar mensaje
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Rápido */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Preguntas Frecuentes</h2>

          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Cuánto tiempo tarda la implementación?</h3>
              <p className="text-gray-600">La implementación completa de la LOPIVI se realiza en 24 horas una vez contratado el servicio.</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Qué incluye el servicio?</h3>
              <p className="text-gray-600">Incluye delegado de protección certificado, todos los protocolos, formación del personal, documentación completa y mantenimiento continuo.</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Es válido para inspecciones?</h3>
              <p className="text-gray-600">Sí, nuestro sistema cumple al 100% con la normativa LOPIVI y está preparado para cualquier inspección oficial.</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Ofrecen soporte continuo?</h3>
              <p className="text-gray-600">Incluimos soporte en horario laboral y actualizaciones automáticas de toda la documentación.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Prefieres empezar directamente?</h2>
          <p className="text-xl mb-8 opacity-90">Implementa la LOPIVI en 2 minutos</p>

          <Link
            href="/planes"
            className="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-medium rounded-lg hover:bg-gray-100 transition-colors text-lg"
          >
            Ver Planes y Contratar
          </Link>
        </div>
      </section>
    </div>
  )
}
