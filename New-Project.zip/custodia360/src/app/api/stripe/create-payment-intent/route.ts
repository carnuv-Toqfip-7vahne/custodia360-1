import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2022-11-15'
});

export async function POST(req: NextRequest) {
  try {
    console.log('🔄 Stripe API called');

    const body = await req.json();
    console.log('📝 Request body:', JSON.stringify(body, null, 2));

    const {
      plan,
      includesKit = false,
      entityName,
      customerEmail,
      currentDomain = 'http://localhost:3000'
    } = body;

    // Validate basic fields
    if (!plan || !entityName || !customerEmail) {
      console.log('❌ Missing required fields');
      return NextResponse.json({
        error: 'Missing required fields',
        success: false
      }, { status: 400 });
    }

    // Simple pricing
    const prices: Record<string, number> = {
      '1-50': 22.99,
      '51-200': 59.29,
      '201-500': 127.05,
      '501+': 302.50,
      'temporal': 47.19
    };

    const baseAmount = prices[plan] || 59.29;
    const kitAmount = includesKit ? 36.30 : 0; // 30€ + IVA
    const totalAmount = baseAmount + kitAmount;

    console.log('💰 Calculated amounts:', {
      plan,
      baseAmount,
      kitAmount,
      totalAmount,
      includesKit
    });

    // Create Stripe session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'eur',
          product_data: {
            name: `Custodia360 - Plan ${plan} menores`,
            description: includesKit ? 'Incluye Kit de Comunicación' : 'Plan de protección LOPIVI'
          },
          unit_amount: Math.round(totalAmount * 100), // Convert to cents
        },
        quantity: 1,
      }],
      mode: 'payment',
      customer_email: customerEmail,
      success_url: `${currentDomain}/contratacion/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${currentDomain}/planes`,
      metadata: {
        plan,
        entityName,
        customerEmail,
        includesKit: includesKit.toString(),
        amount: totalAmount.toString()
      }
    });

    console.log('✅ Stripe session created:', {
      id: session.id,
      url: session.url,
      amount: totalAmount
    });

    return NextResponse.json({
      sessionId: session.id,
      checkoutUrl: session.url,
      amount: totalAmount,
      success: true
    });

  } catch (error) {
    console.error('💥 Stripe API error:', error);

    return NextResponse.json({
      error: 'Payment processing failed',
      details: error instanceof Error ? error.message : 'Unknown error',
      success: false
    }, { status: 500 });
  }
}
