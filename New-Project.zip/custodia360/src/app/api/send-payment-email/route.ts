import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { customerEmail, customerName, entityName, planName, amount, sessionId } = body

    console.log('📧 Enviando email de confirmación:', {
      customerEmail,
      planName,
      amount,
      sessionId
    })

    // Validate required fields
    if (!customerEmail || !customerName || !entityName) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Simple HTML email template
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Confirmación de pago - custodia360</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #e97316;">¡Pago confirmado!</h1>

            <p>Estimado/a ${customerName},</p>

            <p>Hemos recibido correctamente su pago por la protección LOPIVI para <strong>${entityName}</strong>.</p>

            <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0;">Detalles del pago:</h3>
              <ul style="list-style: none; padding: 0;">
                <li><strong>Plan:</strong> ${planName || 'Plan de Protección LOPIVI'}</li>
                <li><strong>Importe:</strong> ${amount ? amount.toFixed(2) : '0.00'} €</li>
                <li><strong>ID de transacción:</strong> ${sessionId}</li>
                <li><strong>Fecha:</strong> ${new Date().toLocaleDateString('es-ES')}</li>
              </ul>
            </div>

            <p>Su protección LOPIVI se implementará en las próximas 24 horas.</p>

            <p>Si tiene alguna pregunta, no dude en contactarnos.</p>

            <p>Saludos,<br>
            <strong>Equipo custodia360</strong><br>
            info@custodia360.es</p>
          </div>
        </body>
      </html>
    `

    // Send email
    const { data, error } = await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'custodia360 <onboarding@resend.dev>',
      to: [customerEmail],
      subject: `Confirmación de pago - ${entityName} - custodia360`,
      html: htmlContent
    })

    if (error) {
      console.error('❌ Error sending email:', error)
      return NextResponse.json(
        { success: false, error: 'Failed to send email', details: error },
        { status: 500 }
      )
    }

    console.log('✅ Email sent successfully:', data?.id)
    return NextResponse.json({
      success: true,
      emailId: data?.id,
      message: 'Email sent successfully'
    })

  } catch (error) {
    console.error('❌ Email API error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
