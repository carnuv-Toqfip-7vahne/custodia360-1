import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: NextRequest) {
  try {
    console.log('🧪 Test Email API: Iniciando test de envío...')

    // Validate API key
    if (!process.env.RESEND_API_KEY) {
      throw new Error('RESEND_API_KEY no está configurada')
    }

    console.log('🔑 API Key encontrada:', process.env.RESEND_API_KEY?.substring(0, 10) + '...')

    const body = await req.json()
    const { email = 'rsune@teamsml.com' } = body

    console.log('📧 Enviando email de prueba a:', email)

    // CORRECTED: Use proper domain for From address
    const result = await resend.emails.send({
      from: 'custodia360 <noreply@resend.dev>', // Using resend.dev domain for testing
      to: [email],
      subject: '🧪 Test Email - custodia360 System Check',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #EA5A27, #F97316); padding: 30px; border-radius: 10px; text-align: center; margin-bottom: 20px;">
            <h1 style="color: white; margin: 0; font-size: 28px;">🛡️ custodia360</h1>
            <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Sistema de Email Funcionando</p>
          </div>

          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #1F2937; margin-top: 0;">✅ Test de Email Exitoso</h2>
            <p style="color: #6B7280; line-height: 1.6;">
              Este email confirma que el sistema de envío automático de custodia360 está funcionando correctamente.
            </p>

            <div style="background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #10B981;">
              <h3 style="color: #059669; margin: 0 0 10px 0; font-size: 16px;">🔧 Datos del Test:</h3>
              <ul style="color: #6B7280; margin: 0; padding-left: 20px;">
                <li><strong>Fecha:</strong> ${new Date().toLocaleString('es-ES')}</li>
                <li><strong>Email destino:</strong> ${email}</li>
                <li><strong>Servidor:</strong> Resend API</li>
                <li><strong>Status:</strong> Enviado correctamente</li>
              </ul>
            </div>
          </div>

          <div style="background: #FEF3C7; padding: 15px; border-radius: 8px; border: 1px solid #F59E0B; margin-bottom: 20px;">
            <h3 style="color: #92400E; margin: 0 0 10px 0;">📋 Próximos pasos:</h3>
            <p style="color: #92400E; margin: 0;">
              Los emails de confirmación de pago y bienvenida se enviarán automáticamente tras cada transacción exitosa.
            </p>
          </div>

          <div style="text-align: center; padding: 20px; border-top: 1px solid #E5E7EB;">
            <p style="color: #6B7280; margin: 0; font-size: 14px;">
              📞 678 771 198 | ✉️ info@custodia360.es | 🌐 custodia360.es
            </p>
            <p style="color: #9CA3AF; margin: 10px 0 0 0; font-size: 12px;">
              © 2025 custodia360 - Protección infantil garantizada
            </p>
          </div>
        </div>
      `,
    })

    console.log('✅ Test email enviado exitosamente:', result)

    return NextResponse.json({
      success: true,
      message: 'Test email sent successfully',
      emailId: result.data?.id,
      timestamp: new Date().toISOString(),
      debugInfo: {
        to: email,
        from: 'custodia360 <noreply@resend.dev>',
        apiKeyStatus: process.env.RESEND_API_KEY ? 'configured' : 'missing'
      }
    })

  } catch (error) {
    console.error('❌ Error enviando test email:', error)

    const errorMessage = error instanceof Error ? error.message : 'Unknown error'

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to send test email',
        details: errorMessage,
        timestamp: new Date().toISOString(),
        debugInfo: {
          apiKeyConfigured: !!process.env.RESEND_API_KEY,
          errorType: typeof error
        }
      },
      { status: 500 }
    )
  }
}
