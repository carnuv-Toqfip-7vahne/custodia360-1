import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Check RESEND configuration
    const resendApiKey = process.env.RESEND_API_KEY
    const resendConfigured = !!resendApiKey
    const resendKeyEnd = resendApiKey ? resendApiKey.slice(-4) : null

    // Check Stripe configuration
    const stripeSecretKey = process.env.STRIPE_SECRET_KEY
    const stripeConfigured = !!stripeSecretKey

    // Check Webhook configuration (optional)
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
    const webhookConfigured = !!webhookSecret

    // Check other environment variables
    const nextPublicAppUrl = process.env.NEXT_PUBLIC_APP_URL
    const nodeEnv = process.env.NODE_ENV

    return NextResponse.json({
      resend: {
        configured: resendConfigured,
        keyEnd: resendKeyEnd
      },
      stripe: {
        configured: stripeConfigured
      },
      webhook: {
        configured: webhookConfigured
      },
      environment: {
        nodeEnv,
        appUrl: nextPublicAppUrl
      },
      // Para compatibilidad con test page
      stripeConfigured,
      resendConfigured,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Error checking configuration:', error)
    return NextResponse.json(
      { error: 'Failed to check configuration' },
      { status: 500 }
    )
  }
}
