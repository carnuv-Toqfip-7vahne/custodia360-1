import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

export async function POST(req: NextRequest) {
  try {
    console.log('🧪 Testing email configuration...')

    // Check if API key is present
    const apiKey = process.env.RESEND_API_KEY
    console.log('📧 Resend API Key present:', !!apiKey)
    console.log('📧 API Key starts with:', apiKey?.substring(0, 10) + '...')

    if (!apiKey) {
      return NextResponse.json(
        { error: 'RESEND_API_KEY not found in environment variables' },
        { status: 400 }
      )
    }

    const resend = new Resend(apiKey)

    const { email } = await req.json()
    const testEmail = email || 'rsune@teamsml.com'

    console.log('📧 Sending test email to:', testEmail)

    const result = await resend.emails.send({
      from: 'custodia360 <onboarding@resend.dev>',
      to: testEmail,
      subject: '🧪 Test Email from custodia360',
      html: `
        <h1>✅ Email Configuration Working!</h1>
        <p>This is a test email from custodia360.</p>
        <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
        <p><strong>To:</strong> ${testEmail}</p>
        <p>If you received this email, the Resend configuration is working correctly.</p>
      `,
    })

    console.log('✅ Test email result:', result)

    return NextResponse.json({
      success: true,
      message: 'Test email sent successfully',
      emailId: result.data?.id,
      result: result
    })

  } catch (error) {
    console.error('❌ Test email error:', error)

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to send test email',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
