import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2022-11-15',
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.text()
    const sig = req.headers.get('stripe-signature')!
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, sig, webhookSecret)
    } catch (err) {
      console.error('❌ Webhook signature verification failed:', err)
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
    }

    console.log('🎣 Webhook recibido:', event.type)

    // Manejar el evento de checkout completado
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session

      console.log('💳 Pago completado:', session.id)
      console.log('📧 Customer email:', session.customer_email)
      console.log('📋 Metadata:', session.metadata)

      // Extraer datos del metadata
      const metadata = session.metadata || {}

      // Enviar email automáticamente
      try {
        const emailData = {
          customerEmail: session.customer_email,
          customerName: metadata.contactName || metadata.entityName || 'Cliente',
          entityName: metadata.entityName || 'Tu entidad',
          planName: metadata.planName || 'Plan LOPIVI',
          amount: (session.amount_total || 0) / 100, // Stripe usa centavos
          sessionId: session.id
        }

        console.log('📧 Enviando email automático con datos:', emailData)

        // Llamar a nuestro API de emails
        const emailResponse = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/send-payment-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(emailData)
        })

        const emailResult = await emailResponse.json()

        if (emailResponse.ok && emailResult.success) {
          console.log('✅ Email enviado automáticamente desde webhook:', emailResult.emailId)
        } else {
          console.error('❌ Error enviando email desde webhook:', emailResult)
        }

      } catch (emailError) {
        console.error('💥 Error procesando email desde webhook:', emailError)
      }
    }

    return NextResponse.json({ received: true })

  } catch (error) {
    console.error('💥 Error procesando webhook:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    )
  }
}
