import { NextRequest, NextResponse } from 'next/server'
import { sendPaymentConfirmation, CustomerData, OrderData } from '@/lib/email'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    const {
      sessionId,
      customerData,
      orderData
    } = body

    console.log('📧 API: Iniciando envío de emails para sesión:', sessionId)

    // Validar datos requeridos
    if (!sessionId || !customerData || !orderData) {
      return NextResponse.json(
        { error: 'Missing required fields: sessionId, customerData, orderData' },
        { status: 400 }
      )
    }

    // Validar email del cliente
    if (!customerData.email) {
      return NextResponse.json(
        { error: 'Customer email is required' },
        { status: 400 }
      )
    }

    // Preparar datos para el email
    const customerEmailData: CustomerData = {
      nombre_entidad: customerData.nombre_entidad,
      cif: customerData.cif,
      responsable: customerData.responsable,
      email: customerData.email,
      telefono: customerData.telefono,
      direccion: customerData.direccion
    }

    const orderEmailData: OrderData = {
      sessionId: sessionId,
      planName: orderData.planName || 'Plan seleccionado',
      amount: orderData.amount || 0,
      includesKit: orderData.includesKit || false,
      paymentDate: new Date(),
      invoiceUrl: orderData.invoiceUrl
    }

    console.log('📧 Enviando email de confirmación a:', customerEmailData.email)

    // Enviar email de confirmación (esto también programa el de bienvenida)
    const result = await sendPaymentConfirmation(customerEmailData, orderEmailData)

    console.log('✅ Emails programados exitosamente')

    return NextResponse.json({
      success: true,
      message: 'Emails sent successfully',
      emailId: result.data?.id
    })

  } catch (error) {
    console.error('❌ Error enviando emails:', error)

    const errorMessage = error instanceof Error ? error.message : 'Unknown error'

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to send emails',
        details: errorMessage
      },
      { status: 500 }
    )
  }
}
