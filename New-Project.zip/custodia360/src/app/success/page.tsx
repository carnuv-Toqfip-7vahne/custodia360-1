import Link from 'next/link'
import { CheckCircle } from 'lucide-react'

export default function SuccessPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md mx-auto text-center p-8 bg-white rounded-lg shadow-lg">
        <div className="flex justify-center mb-6">
          <CheckCircle className="w-16 h-16 text-green-600" />
        </div>

        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          ¡Pago Exitoso!
        </h1>

        <p className="text-gray-600 mb-6">
          Tu pago se ha procesado correctamente.
          <br />
          Implementaremos tu protección LOPIVI en 24 horas.
        </p>

        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-700">
            <strong>Próximos pasos:</strong>
          </p>
          <ul className="text-sm text-gray-600 mt-2 text-left">
            <li>• Recibirás un email de confirmación</li>
            <li>• Te contactaremos en 24 horas</li>
            <li>• Implementación completa de LOPIVI</li>
          </ul>
        </div>

        <Link
          href="/"
          className="inline-block bg-orange-600 text-white px-6 py-2 rounded-md hover:bg-orange-700 transition-colors"
        >
          Volver al Inicio
        </Link>
      </div>
    </div>
  )
}
