import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Link from 'next/link'
import { Shield } from 'lucide-react'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Custodia360 - Cumplimiento LOPIVI Automático',
  description: 'Implementación LOPIVI completa en 24 horas. Protege tu entidad con menores de forma automática y cumple la normativa. Ahorra 97% vs consultorías tradicionales.',
  keywords: 'LOPIVI, protección infantil, cumplimiento normativo, entidades menores, delegado protección',
  authors: [{ name: 'Custodia360' }],
  creator: 'Custodia360',
  publisher: 'Custodia360',
  metadataBase: new URL('https://www.custodia360.es'),
  openGraph: {
    title: 'Custodia360 - Cumplimiento LOPIVI Automático',
    description: 'Implementación LOPIVI completa en 24 horas. Primera empresa automatizada de España.',
    url: 'https://www.custodia360.es',
    siteName: 'Custodia360',
    locale: 'es_ES',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body className={inter.className}>
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <Link href="/" className="flex items-center space-x-2">
                <Shield className="h-8 w-8 text-orange-600" />
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Custodia360</h1>
                </div>
              </Link>

              <div className="flex items-center space-x-8">
                <nav className="hidden md:flex space-x-8">
                  <Link href="/" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Inicio
                  </Link>
                  <Link href="/servicios" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Servicios
                  </Link>
                  <Link href="/planes" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Planes
                  </Link>
                  <Link href="/demo" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Demo
                  </Link>
                  <Link href="/lopivi" className="text-gray-600 hover:text-orange-600 transition-colors">
                    LOPIVI
                  </Link>
                  <Link href="/nosotros" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Nosotros
                  </Link>
                  <Link href="/guia-custodia360" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Guía
                  </Link>
                  <Link href="/contacto" className="text-gray-600 hover:text-orange-600 transition-colors">
                    Contacto
                  </Link>
                </nav>
              </div>
            </div>
          </div>
        </header>

        {children}
      </body>
    </html>
  )
}
