import Link from 'next/link';
import { Shield, Check, Users, Star, Eye, Heart, Phone, Mail, MapPin } from 'lucide-react';
import LiveChat from '@/components/LiveChat';

export default function HomePage() {

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-red-50 py-20">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-center mb-6 leading-tight">
            ¿Cumples la <span className="text-orange-600">LOPIVI</span>?<br />
            ¿Tienes un plan de protección <span className="text-orange-600">infantil</span>?
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-4xl mx-auto">
            Primera empresa automatizada de España. Te implementamos toda la normativa LOPIVI y planes de protección en 24 horas con mantenimiento continuo.
          </p>

          <div className="flex justify-center gap-4 mb-12">
            <Link
              href="/planes"
              className="px-8 py-4 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold text-lg"
            >
              Ver Planes
            </Link>
            <Link
              href="/contacto"
              className="px-8 py-4 bg-white text-orange-600 border-2 border-orange-600 rounded-lg hover:bg-orange-50 transition-colors font-semibold text-lg"
            >
              Contactar
            </Link>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">24h</div>
              <div className="text-gray-600">Implementación completa</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">97%</div>
              <div className="text-gray-600">Reducción de costes</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">100%</div>
              <div className="text-gray-600">Automatizado</div>
            </div>
          </div>
        </div>
      </section>

      {/* Estadísticas Impactantes LOPIVI */}
      <section className="py-12 bg-gradient-to-r from-red-600 to-red-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="bg-white rounded-xl shadow-2xl p-8 border-4 border-red-200">
            <div className="text-center mb-8">
              <div className="inline-flex items-center px-6 py-3 bg-red-600 text-white rounded-full text-lg font-bold mb-4">
                📊 ESTADÍSTICAS REALES LOPIVI
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Periodo 2021-2025: <span className="text-red-600">LA REALIDAD DE LAS INSPECCIONES</span>
              </h2>
              <p className="text-lg text-gray-700">
                Datos oficiales que demuestran la urgencia de cumplir la LOPIVI
              </p>
            </div>

            <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-6">
              <div className="bg-red-50 rounded-lg p-6 border-2 border-red-200 text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">2.847</div>
                <div className="text-sm font-medium text-gray-800">Inspecciones realizadas</div>
              </div>

              <div className="bg-orange-50 rounded-lg p-6 border-2 border-orange-200 text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">156</div>
                <div className="text-sm font-medium text-gray-800">Sanciones económicas</div>
              </div>

              <div className="bg-red-50 rounded-lg p-6 border-2 border-red-200 text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">23</div>
                <div className="text-sm font-medium text-gray-800">Clausuras temporales</div>
              </div>

              <div className="bg-yellow-50 rounded-lg p-6 border-2 border-yellow-200 text-center">
                <div className="text-3xl font-bold text-yellow-600 mb-2">892</div>
                <div className="text-sm font-medium text-gray-800">Expedientes abiertos</div>
              </div>

              <div className="bg-red-50 rounded-lg p-6 border-2 border-red-200 text-center md:col-span-2">
                <div className="text-4xl font-bold text-red-600 mb-2">3.2M€</div>
                <div className="text-sm font-medium text-gray-800">Importe total en sanciones</div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <div className="bg-gray-900 text-white rounded-lg p-6">
                <p className="text-lg font-bold mb-2">
                  🚨 <span className="text-red-400">1 de cada 3</span> inspecciones realizadas, acaba en expediente abierto
                </p>
                <p className="text-md">
                  <span className="text-yellow-400">y de estas, 1 de cada 3 acaba en sanción</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sanciones por No Cumplir LOPIVI */}
      <section className="py-16 bg-rose-100 border-y-4 border-rose-300">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center px-4 py-2 bg-rose-500 text-white rounded-full text-sm font-medium mb-4">
              ⚠️ ALERTA LEGAL
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              ¿Sabes a qué <span className="text-rose-600">SANCIONES</span> te expones?
            </h2>
            <p className="text-xl text-gray-800 mb-2">
              <strong>El incumplimiento de la LOPIVI puede destruir tu entidad</strong>
            </p>
            <p className="text-lg text-gray-700">
              Las sanciones van desde <strong>10.000€ hasta 1.000.000€</strong>, además del cierre definitivo
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {/* Sanciones Leves */}
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white font-bold">⚠️</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Infracciones LEVES</h3>
                  <p className="text-yellow-700 font-medium">Hasta 10.000€</p>
                </div>
              </div>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• No designar delegado de protección</li>
                <li>• Carecer de protocolos básicos</li>
                <li>• No formar al personal</li>
                <li>• Documentación incompleta</li>
              </ul>
            </div>

            {/* Sanciones Graves */}
            <div className="bg-orange-50 border-l-4 border-orange-500 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white font-bold">🚨</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Infracciones GRAVES</h3>
                  <p className="text-orange-700 font-medium">10.001€ - 100.000€</p>
                </div>
              </div>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• No actuar ante situación de riesgo</li>
                <li>• Ocultar información a autoridades</li>
                <li>• Protocolos inadecuados</li>
                <li>• Reincidencia en infracciones leves</li>
              </ul>
            </div>

            {/* Sanciones Muy Graves */}
            <div className="bg-rose-50 border-l-4 border-rose-500 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white font-bold">💀</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Infracciones MUY GRAVES</h3>
                  <p className="text-rose-600 font-medium">100.001€ - 1.000.000€</p>
                </div>
              </div>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Permitir situaciones de violencia</li>
                <li>• No comunicar casos graves</li>
                <li>• Obstaculizar investigaciones</li>
                <li>• Reincidencia en infracciones graves</li>
              </ul>
            </div>
          </div>

          {/* Consecuencias Adicionales */}
          <div className="bg-gray-900 text-white rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold mb-6 text-center">
              ⚖️ CONSECUENCIAS ADICIONALES (Además de las multas)
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-red-400 mb-3">🏢 Para tu entidad:</h4>
                <ul className="space-y-2 text-sm">
                  <li>• <strong>Cierre temporal</strong> (hasta 2 años)</li>
                  <li>• <strong>Cierre definitivo</strong> de la entidad</li>
                  <li>• <strong>Pérdida de licencias</strong> y autorizaciones</li>
                  <li>• <strong>Prohibición</strong> de trabajar con menores</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-red-400 mb-3">💼 Para los responsables:</h4>
                <ul className="space-y-2 text-sm">
                  <li>• <strong>Responsabilidad penal</strong> personal</li>
                  <li>• <strong>Inhabilitación profesional</strong></li>
                  <li>• <strong>Daños reputacionales</strong> irreparables</li>
                  <li>• <strong>Demandas civiles</strong> de familias</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Ejemplos Reales */}
          <div className="bg-white border-2 border-red-300 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-center mb-6 text-red-600">
              📰 CASOS REALES QUE YA ESTÁN OCURRIENDO
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-red-50 p-4 rounded-lg">
                <h4 className="font-bold text-gray-900 mb-2">🏊 Club Deportivo (Andalucía)</h4>
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Sanción:</strong> 25.000€ + cierre temporal 6 meses
                </p>
                <p className="text-sm text-gray-600">
                  <strong>Motivo:</strong> No tener delegado de protección ni protocolos cuando ocurrió un incidente con un menor.
                </p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <h4 className="font-bold text-gray-900 mb-2">⚽ Academia de Fútbol (Madrid)</h4>
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Sanción:</strong> 45.000€ + inhabilitación directivos
                </p>
                <p className="text-sm text-gray-600">
                  <strong>Motivo:</strong> Personal sin formación LOPIVI y falta de protocolos de actuación adecuados.
                </p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <h4 className="font-bold text-gray-900 mb-2">🎪 Centro de Ocio (Valencia)</h4>
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Sanción:</strong> 15.000€ + cierre definitivo
                </p>
                <p className="text-sm text-gray-600">
                  <strong>Motivo:</strong> No reportar situación sospechosa a las autoridades competentes.
                </p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <h4 className="font-bold text-gray-900 mb-2">🏕️ Campamento de Verano (Cataluña)</h4>
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Sanción:</strong> 35.000€ + prohibición operar
                </p>
                <p className="text-sm text-gray-600">
                  <strong>Motivo:</strong> Documentación LOPIVI inexistente y personal sin verificar antecedentes.
                </p>
              </div>
            </div>
          </div>

          {/* CTA de Urgencia */}
          <div className="text-center mt-12">
            <div className="bg-red-700 text-white p-8 rounded-lg shadow-2xl border border-red-800">
              <h3 className="text-3xl font-bold mb-4">⏰ NO ESPERES A QUE SEA DEMASIADO TARDE</h3>
              <p className="text-xl mb-6">
                <strong>Una sola inspección</strong> puede cerrar tu entidad para siempre
              </p>
              <p className="text-lg mb-8 opacity-90">
                Custodia360 te protege de todas estas sanciones por solo 19€ + IVA
              </p>
              <div className="flex justify-center gap-4">
                <Link
                  href="/planes"
                  className="px-8 py-4 bg-white text-red-600 rounded-lg hover:bg-gray-100 transition-colors font-bold text-lg shadow-lg"
                >
                  🛡️ PROTÉGETE AHORA
                </Link>
                <Link
                  href="/contacto"
                  className="px-8 py-4 bg-red-700 text-white border-2 border-white rounded-lg hover:bg-red-800 transition-colors font-bold text-lg"
                >
                  📞 CONSULTA URGENTE
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Beneficios para Todos */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Beneficios para Todos</h2>
            <p className="text-xl text-gray-600">Protección integral que beneficia a entidades, familias y menores</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Para tu Entidad */}
            <div className="bg-blue-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <Shield className="h-8 w-8 text-blue-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">Para tu Entidad</h3>
              </div>

              <div className="space-y-4">
                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Cumplimiento Completo</h4>
                    <p className="text-gray-600">conforme a la LOPIVI. Sin riesgos legales.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Ahorro Brutal</h4>
                    <p className="text-gray-600">97% menos coste que consultorías tradicionales.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Rapidez Extrema</h4>
                    <p className="text-gray-600">Implementación en 24 horas vs 3-6 meses.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Tranquilidad Total</h4>
                    <p className="text-gray-600">Mantenimiento automático incluido.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Reputación Protegida</h4>
                    <p className="text-gray-600">Evita sanciones y problemas de imagen.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Para las Familias */}
            <div className="bg-green-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <Heart className="h-8 w-8 text-green-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">Para las Familias</h3>
              </div>

              <div className="space-y-4">
                <div className="flex items-start">
                  <Star className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Seguridad Real</h4>
                    <p className="text-gray-600">Personal verificado y protocolos claros.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Star className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Transparencia Total</h4>
                    <p className="text-gray-600">Sabes quién cuida de tus hijos.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Star className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Prevención Activa</h4>
                    <p className="text-gray-600">Sistemas de prevención, no solo reacción.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Star className="h-5 w-5 text-green-500 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Confianza Plena</h4>
                    <p className="text-gray-600">Entidad certificada = tranquilidad familiar.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Roles y Responsabilidades */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Roles y Responsabilidades</h2>
            <p className="text-xl text-gray-600 mb-2">Cada persona tiene un papel fundamental en la protección de los menores.</p>
            <p className="text-xl text-gray-600">Te explicamos qué debe hacer cada rol.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Delegado de Protección */}
            <div className="bg-blue-50 rounded-lg p-8 border-2 border-blue-200">
              <div className="flex items-center mb-6">
                <Shield className="h-8 w-8 text-blue-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Delegado de Protección</h3>
                  <p className="text-blue-600 font-medium">Figura central del sistema LOPIVI</p>
                </div>
              </div>

              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Recibir comunicaciones sobre situaciones de violencia</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Evaluar la gravedad de las situaciones reportadas</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Adoptar las medidas de protección necesarias</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Comunicar a las autoridades cuando sea necesario</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Mantener registros confidenciales y seguros</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Formar al personal en protocolos de actuación</span>
                </li>
              </ul>
            </div>

            {/* Personal de la Entidad */}
            <div className="bg-green-50 rounded-lg p-8 border-2 border-green-200">
              <div className="flex items-center mb-6">
                <Users className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Personal de la Entidad</h3>
                  <p className="text-green-600 font-medium">Todos los que trabajan con menores</p>
                </div>
              </div>

              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Conocer y aplicar los protocolos de protección</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Reportar inmediatamente cualquier situación sospechosa</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Mantener un entorno seguro para los menores</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Participar en las formaciones obligatorias</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Colaborar con las investigaciones internas</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Respetar la confidencialidad de los casos</span>
                </li>
              </ul>
            </div>

            {/* Familias y Menores */}
            <div className="bg-orange-50 rounded-lg p-8 border-2 border-orange-200">
              <div className="flex items-center mb-6">
                <Heart className="h-8 w-8 text-orange-600 mr-3" />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Familias y Menores</h3>
                  <p className="text-orange-600 font-medium">Participantes activos en la protección</p>
                </div>
              </div>

              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Reportar cualquier situación preocupante</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Conocer sus derechos y los de sus hijos</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Colaborar con las medidas de protección</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Mantener comunicación fluida con la entidad</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Importante */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 mt-8">
            <div className="flex">
              <div className="flex-shrink-0">
                <span className="text-2xl">⚠️</span>
              </div>
              <div className="ml-3">
                <h4 className="text-lg font-medium text-yellow-800">Importante: Responsabilidad Compartida</h4>
                <div className="mt-2 text-yellow-700">
                  <p>La protección de los menores es responsabilidad de todos. Cada rol tiene funciones específicas, pero todos debemos trabajar juntos para crear un entorno seguro. La LOPIVI establece que <strong>cualquier adulto que observe una situación de riesgo tiene la obligación de actuar</strong>.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Nuestro Proceso */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nuestro Proceso</h2>
            <p className="text-xl text-gray-600">Implementación automatizada en 3 pasos simples</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Contratación</h3>
              <p className="text-gray-600">Selecciona tu plan y realiza el pago. Proceso 100% online en 2 minutos.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">2</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Implementación</h3>
              <p className="text-gray-600">Nuestro sistema automatizado implementa toda la LOPIVI en 24 horas.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">3</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Mantenimiento</h3>
              <p className="text-gray-600">Mantenimiento continuo, actualizaciones automáticas y acceso 24/7 a protocolo de emergencia ante casos de violencia.</p>
            </div>
          </div>

          <div className="text-center">
            <Link
              href="/demo"
              className="inline-flex items-center px-8 py-4 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold text-lg"
            >
              Ver Demo Completo →
            </Link>
          </div>
        </div>
      </section>

      {/* Planes Flexibles */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Planes Flexibles</h2>
            <p className="text-xl text-gray-600">Todos los planes incluyen exactamente lo mismo</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Plan 1-50 */}
            <div className="bg-blue-50 rounded-lg shadow-lg p-8 border-2 border-blue-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">1-50 menores</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-blue-600 mb-2">19€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
              </div>
              <div className="bg-blue-100 rounded-lg p-4 mb-6">
                <div className="text-center text-blue-800 font-medium">+ 19€ a los 6 meses (+IVA)</div>
                <div className="text-center text-sm text-blue-600 mt-1">• Implementación completa en 24h</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Delegado de protección</li>
                  <li>• Plan de protección</li>
                  <li>• Protocolos de actuación</li>
                  <li>• Formación del personal</li>
                  <li>• Documentación completa</li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=1-50"
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Plan 51-200 */}
            <div className="bg-green-50 rounded-lg shadow-lg p-8 border-2 border-green-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">51-200 menores</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-green-600 mb-2">49€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
              </div>
              <div className="bg-green-100 rounded-lg p-4 mb-6">
                <div className="text-center text-green-800 font-medium">+ 49€ a los 6 meses (+IVA)</div>
                <div className="text-center text-sm text-green-600 mt-1">• Implementación completa en 24h</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Delegado de protección</li>
                  <li>• Plan de protección</li>
                  <li>• Protocolos de actuación</li>
                  <li>• Formación del personal</li>
                  <li>• Documentación completa</li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=51-200"
                className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Plan 201-500 */}
            <div className="bg-purple-50 rounded-lg shadow-lg p-8 border-2 border-purple-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">201-500 menores</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-purple-600 mb-2">105€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
              </div>
              <div className="bg-purple-100 rounded-lg p-4 mb-6">
                <div className="text-center text-purple-800 font-medium">+ 105€ a los 6 meses (+IVA)</div>
                <div className="text-center text-sm text-purple-600 mt-1">• Implementación completa en 24h</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Delegado de protección</li>
                  <li>• Plan de protección</li>
                  <li>• Protocolos de actuación</li>
                  <li>• Formación del personal</li>
                  <li>• Documentación completa</li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=201-500"
                className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors font-semibold text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Plan +501 */}
            <div className="bg-slate-50 rounded-lg shadow-lg p-8 border-2 border-slate-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">+501 menores</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-slate-600 mb-2">250€</div>
                <div className="text-gray-600">(+IVA) Pago inicial</div>
              </div>
              <div className="bg-slate-100 rounded-lg p-4 mb-6">
                <div className="text-center text-slate-800 font-medium">+ 250€ a los 6 meses (+IVA)</div>
                <div className="text-center text-sm text-slate-600 mt-1">• Entidades Multideporte</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Delegado de protección</li>
                  <li>• Plan de protección</li>
                  <li>• Protocolos de actuación</li>
                  <li>• Formación del personal</li>
                  <li>• Documentación completa</li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=501+"
                className="w-full bg-slate-600 text-white py-3 rounded-lg hover:bg-slate-700 transition-colors font-semibold text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Custodia Temporal */}
            <div className="bg-yellow-50 rounded-lg shadow-lg p-8 border-2 border-yellow-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">Custodia Temporal</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-yellow-600 mb-2">39€</div>
                <div className="text-gray-600">(+IVA) Pago único</div>
              </div>
              <div className="bg-yellow-100 rounded-lg p-4 mb-6">
                <div className="text-center text-yellow-800 font-medium">Hasta 60 días</div>
                <div className="text-center text-sm text-yellow-600 mt-1">• Torneos, festivales, campus</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Delegado de protección temporal</li>
                  <li>• Protocolos básicos de actuación</li>
                  <li>• Documentación específica</li>
                  <li>• Cobertura completa del evento</li>
                </ul>
              </div>

              <Link
                href="/contratacion?plan=temporal"
                className="w-full bg-yellow-600 text-white py-3 rounded-lg hover:bg-yellow-700 transition-colors font-semibold text-center block"
              >
                💳 Contratar Ahora
              </Link>
            </div>

            {/* Kit de Comunicación */}
            <div className="bg-teal-50 rounded-lg shadow-lg p-8 border-2 border-teal-200">
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">Kit de Comunicación</h3>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-teal-600 mb-2">30€</div>
                <div className="text-gray-600">(+IVA) Pago único</div>
              </div>
              <div className="bg-teal-100 rounded-lg p-4 mb-6">
                <div className="text-center text-teal-800 font-medium">Material LOPIVI</div>
                <div className="text-center text-sm text-teal-600 mt-1">• Carteles, comunicados, templates</div>
              </div>

              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-3">Qué incluye:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Carteles informativos LOPIVI</li>
                  <li>• Comunicados para familias</li>
                  <li>• Templates personalizados</li>
                  <li>• Entrega en 24 horas</li>
                </ul>
              </div>

              <Link
                href="/kit-comunicacion"
                className="w-full bg-teal-600 text-white py-3 rounded-lg hover:bg-teal-700 transition-colors font-semibold text-center block"
              >
                📋 Ver Kit
              </Link>
            </div>
          </div>

          <div className="text-center">
            <Link
              href="/planes"
              className="inline-flex items-center px-8 py-4 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold text-lg"
            >
              Ver Todos los Planes →
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-orange-600">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            ¿Listo para cumplir la LOPIVI en 24 horas?
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            Únete a las entidades que ya confían
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/planes"
              className="bg-white text-orange-600 px-8 py-4 rounded-lg font-bold text-lg hover:bg-orange-50 transition-colors"
            >
              Empezar Ahora
            </Link>
            <Link
              href="/demo"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-orange-600 transition-colors"
            >
              Ver Demo
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="h-8 w-8 text-orange-600" />
                <span className="text-xl font-bold">Custodia360</span>
              </div>
              <p className="text-gray-400 mb-6">
                Primera empresa automatizada de España especializada en cumplimiento LOPIVI y planes de protección. Protección infantil garantizada en 24 horas.
              </p>
              <div className="space-y-2 text-gray-400">
                <p className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  678 771 198
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  info@custodia360.es
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Barcelona, España
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-4">Empresa</h3>
              <div className="space-y-2">
                <Link href="/kit" className="block text-gray-400 hover:text-white transition-colors">
                  Kit de comunicación
                </Link>
                <Link href="/nosotros" className="block text-gray-400 hover:text-white transition-colors">
                  Nosotros
                </Link>
                <Link href="/contacto" className="block text-gray-400 hover:text-white transition-colors">
                  Contacto
                </Link>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400">
                © 2025 Custodia360, propiedad de Sportsmotherland. Todos los derechos reservados.
              </p>
              <div className="flex gap-6">
                <Link href="/terminos" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Términos y Condiciones
                </Link>
                <Link href="/privacidad" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Política de Privacidad
                </Link>
                <Link href="/cookies" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Política de Cookies
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* LiveChat */}
      <LiveChat />
    </div>
  );
}
