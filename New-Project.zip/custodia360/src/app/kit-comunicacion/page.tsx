import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Kit de Comunicación LOPIVI - Material Personalizado | Custodia360',
  description: 'Kit completo de comunicación LOPIVI: carteles, comunicados y material educativo personalizado para tu entidad.',
}

export default function KitComunicacionPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Simplificado */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-orange-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Custodia360</h1>
              </div>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-600 hover:text-gray-900 transition-colors">Inicio</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-teal-50 to-cyan-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Kit de <span className="text-teal-600">Comunicación</span> LOPIVI
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Material personalizado para comunicar la protección LOPIVI en tu entidad
          </p>
          <div className="bg-teal-100 border-l-4 border-teal-500 p-6 max-w-3xl mx-auto mb-8">
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-teal-700">30€</div>
                <div className="text-sm text-teal-600">Precio único</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-teal-700">+IVA</div>
                <div className="text-sm text-teal-600">Incluye todo</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-teal-700">📧 24h</div>
                <div className="text-sm text-teal-600">Entrega digital</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contenido Principal */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        {/* Qué Incluye */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">¿Qué Incluye el Kit?</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Carteles Informativos */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-2xl">📋</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Carteles Informativos</h3>
              </div>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Cartel información general LOPIVI</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Cartel contacto delegado protección</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Cartel protocolos de actuación</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Cartel normas de convivencia</span>
                </li>
              </ul>
            </div>

            {/* Comunicados Familias */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-2xl">📝</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Comunicados Familias</h3>
              </div>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Comunicado implementación LOPIVI</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Carta compromiso protección</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Información canales comunicación</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Newsletter mensual protección</span>
                </li>
              </ul>
            </div>

            {/* Material Educativo */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-2xl">📚</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Material Educativo para Menores</h3>
              </div>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Guías educativas por edades</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Actividades de sensibilización</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>Recursos didácticos adaptados</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Características */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Características del Kit</h2>
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🎨</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Personalización</h4>
                <p className="text-gray-600 text-sm">Material adaptado con logo y datos de tu entidad</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">📱</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Formato Digital</h4>
                <p className="text-gray-600 text-sm">Archivos PDF de alta calidad listos para imprimir</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">⚡</span>
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Entrega Rápida</h4>
                <p className="text-gray-600 text-sm">Recíbelo por email en 24 horas</p>
              </div>
            </div>
          </div>
        </section>

        {/* Precio y Contratación */}
        <section className="bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg p-8 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Kit de Comunicación LOPIVI</h2>
          <div className="text-5xl font-bold mb-4">30€</div>
          <p className="text-xl mb-6 opacity-90">(+IVA) • Se añade a cualquier plan</p>
          <div className="bg-white/10 rounded-lg p-4 mb-6 max-w-md mx-auto">
            <p className="text-sm">✓ Material personalizado con tu logo</p>
            <p className="text-sm">✓ Entrega digital en 24 horas</p>
            <p className="text-sm">✓ Archivos PDF de alta calidad</p>
          </div>
          <Link
            href="/pago?plan=kit-comunicacion"
            className="inline-flex items-center px-8 py-4 bg-white text-teal-600 font-medium rounded-lg hover:bg-gray-100 transition-colors text-lg"
          >
            💳 Contratar Kit
          </Link>
        </section>

      </main>
    </div>
  )
}
