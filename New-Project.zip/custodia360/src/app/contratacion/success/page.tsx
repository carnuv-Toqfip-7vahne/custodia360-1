'use client'

import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { CheckCircle, Loader2 } from 'lucide-react'

export default function SuccessPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [plan, setPlan] = useState<string | null>(null)
  const [entity, setEntity] = useState<string | null>(null)

  useEffect(() => {
    // Safely get search params
    try {
      const urlParams = new URLSearchParams(window.location.search)
      setPlan(urlParams.get('plan'))
      setEntity(urlParams.get('entity'))
    } catch (error) {
      console.warn('Error reading URL params:', error)
    }

    // Simple delay to show success
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-orange-600 mb-4 mx-auto" />
          <h2 className="text-xl font-bold mb-2">¡Pago exitoso!</h2>
          <p className="text-gray-600">Preparando tu confirmación...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-lg mx-auto text-center p-8 bg-white rounded-lg shadow-lg">
        <CheckCircle className="w-16 h-16 text-green-600 mb-6 mx-auto" />

        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          ¡Pago Realizado con Éxito! 🎉
        </h1>

        <div className="bg-green-50 rounded-lg p-6 mb-6 text-left">
          <h3 className="font-semibold mb-3 text-green-800">Detalles de tu contratación:</h3>
          <div className="space-y-2 text-green-700">
            <p><strong>Entidad:</strong> {entity ? decodeURIComponent(entity) : 'Tu entidad'}</p>
            <p><strong>Plan contratado:</strong> {plan || 'Plan LOPIVI'} menores</p>
            <p><strong>Estado:</strong> ✅ Confirmado y pagado</p>
            <p><strong>Implementación:</strong> En las próximas 24 horas</p>
          </div>
        </div>

        <div className="bg-blue-50 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-blue-800 mb-2">📋 Próximos pasos:</h4>
          <div className="text-sm text-blue-700 text-left space-y-1">
            <p>✅ Pago procesado correctamente</p>
            <p>📧 Recibirás email de confirmación en breves</p>
            <p>🚀 Implementaremos tu LOPIVI en 24 horas</p>
            <p>📞 Te contactaremos para coordinar</p>
          </div>
        </div>

        <div className="space-y-3">
          <Link
            href="/"
            className="block w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors font-medium"
          >
            Volver al Inicio
          </Link>

          <Link
            href="/planes"
            className="block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Ver Otros Planes
          </Link>
        </div>

        <div className="mt-6 text-xs text-gray-500">
          <p>🔒 Pago procesado de forma segura</p>
          <p>💳 Transacción completada exitosamente</p>
        </div>

        {/* Debug info - visible without F12 */}
        <div className="mt-6 p-4 bg-gray-100 rounded-lg text-left">
          <h5 className="font-medium text-gray-800 mb-2">🔍 Debug Info:</h5>
          <div className="text-xs text-gray-700 space-y-1">
            <p><strong>URL actual:</strong> {typeof window !== 'undefined' ? window.location.href : 'N/A'}</p>
            <p><strong>Plan detectado:</strong> {plan || 'Ninguno'}</p>
            <p><strong>Entidad detectada:</strong> {entity || 'Ninguna'}</p>
            <p><strong>Timestamp:</strong> {new Date().toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
