'use client'

import Link from 'next/link'
import { ArrowLeft, Check } from 'lucide-react'
import { useSearchParams } from 'next/navigation'
import { useEffect, useState, Suspense } from 'react'
import { CUSTODIA360_PLANS, KIT_COMUNICACION } from '@/lib/stripe'
import SimplePayment from '@/components/SimplePayment'

// CORRECTED: Precios TOTALES del servicio completo (SIN IVA) - Redondeados
const planTotalPrices: Record<string, number> = {
  '1-50': 38,
  '51-200': 98,
  '201-500': 210,
  '501+': 500,
  'temporal': 39
}

const planNames: Record<string, string> = {
  '1-50': '1-50 menores',
  '51-200': '51-200 menores',
  '201-500': '201-500 menores',
  '501+': '+501 menores',
  'temporal': 'Custodia Temporal'
}

// Tipos de entidad expandidos para automatización
const TIPOS_ENTIDAD = {
  // DEPORTIVAS
  'club_deportivo': 'Club Deportivo',
  'federacion': 'Federación Deportiva',
  'escuela_deportiva': 'Escuela Deportiva',
  'gimnasio': 'Gimnasio/Centro Fitness',

  // EDUCATIVAS
  'academia': 'Academia/Centro de Estudios',
  'conservatorio': 'Conservatorio/Escuela de Música',
  'centro_idiomas': 'Centro de Idiomas',
  'extraescolar': 'Actividades Extraescolares',

  // RELIGIOSAS
  'parroquia': 'Parroquia/Iglesia',
  'catequesis': 'Grupo de Catequesis',
  'movimiento_religioso': 'Movimiento Religioso',
  'seminario': 'Seminario/Centro Religioso',

  // OCIO Y TIEMPO LIBRE
  'centro_ocio': 'Centro de Ocio',
  'campamento': 'Campamento/Colonia',
  'ludoteca': 'Ludoteca',
  'scout': 'Grupo Scout',

  // ASOCIACIONES
  'asociacion_cultural': 'Asociación Cultural',
  'ong': 'ONG/Fundación',
  'centro_juvenil': 'Centro Juvenil',
  'otro': 'Otro'
} as const

// Cargos dinámicos por tipo de entidad
const CARGOS_POR_TIPO = {
  'club_deportivo': ['Presidente', 'Director Deportivo', 'Coordinador', 'Entrenador Principal'],
  'parroquia': ['Párroco', 'Coordinador Pastoral', 'Catequista Principal', 'Responsable Juvenil'],
  'catequesis': ['Coordinador de Catequesis', 'Catequista Principal', 'Responsable Pastoral'],
  'academia': ['Director', 'Coordinador Académico', 'Responsable de Centro'],
  'asociacion_cultural': ['Presidente', 'Secretario', 'Coordinador de Actividades'],
  'centro_ocio': ['Director', 'Coordinador de Actividades', 'Responsable de Centro'],
  'default': ['Director', 'Presidente', 'Coordinador', 'Responsable', 'Otro']
} as const

interface FormData {
  // DATOS BÁSICOS DE LA ENTIDAD
  nombre_entidad: string;
  cif: string;
  tipo_entidad: string;
  num_menores: string;

  // DIRECCIÓN FISCAL COMPLETA (para AEAT y Stripe)
  direccion_linea1: string;
  codigo_postal: string;
  ciudad: string;
  provincia: string;
  pais: string;

  // CONTACTO PRINCIPAL
  responsable: string;
  cargo_responsable: string;
  email: string;
  telefono: string;

  // FACTURACIÓN (opcional)
  email_facturacion?: string;

  // DELEGADO DE PROTECCIÓN (opcional)
  delegado_designado?: string;
  email_delegado?: string;
  telefono_delegado?: string;

  // PREFERENCIAS
  idioma_preferido: string;
  observaciones?: string;
}

function ContratacionContent() {
  const searchParams = useSearchParams()
  const [selectedPlan, setSelectedPlan] = useState('')
  const [kitComunicacion, setKitComunicacion] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formData, setFormData] = useState<FormData>({
    nombre_entidad: '',
    cif: '',
    tipo_entidad: '',
    num_menores: '',
    direccion_linea1: '',
    codigo_postal: '',
    ciudad: '',
    provincia: '',
    pais: 'España',
    responsable: '',
    cargo_responsable: '',
    email: '',
    telefono: '',
    idioma_preferido: 'es'
  })

  const getAutoSelectedPlan = (numMenores: string): string => {
    const num = parseInt(numMenores)
    if (isNaN(num) || num <= 0) return ''

    if (num >= 1 && num <= 50) return '1-50'
    if (num >= 51 && num <= 200) return '51-200'
    if (num >= 201 && num <= 500) return '201-500'
    if (num >= 501) return '501+'

    return ''
  }

  // Cargos dinámicos según tipo de entidad
  const getAvailableCargos = () => {
    const tipo = formData.tipo_entidad as keyof typeof CARGOS_POR_TIPO
    return CARGOS_POR_TIPO[tipo] || CARGOS_POR_TIPO.default
  }

  // Autocompletar provincia según código postal
  const handleCodigoPostalChange = (cp: string) => {
    setFormData(prev => ({ ...prev, codigo_postal: cp }))

    // Autocompletado básico de provincias españolas
    const provinciaMap: Record<string, string> = {
      '01': 'Álava', '02': 'Albacete', '03': 'Alicante', '04': 'Almería',
      '05': 'Ávila', '06': 'Badajoz', '07': 'Illes Balears', '08': 'Barcelona',
      '09': 'Burgos', '10': 'Cáceres', '11': 'Cádiz', '12': 'Castellón',
      '13': 'Ciudad Real', '14': 'Córdoba', '15': 'A Coruña', '16': 'Cuenca',
      '17': 'Girona', '18': 'Granada', '19': 'Guadalajara', '20': 'Gipuzkoa',
      '21': 'Huelva', '22': 'Huesca', '23': 'Jaén', '24': 'León',
      '25': 'Lleida', '26': 'La Rioja', '27': 'Lugo', '28': 'Madrid',
      '29': 'Málaga', '30': 'Murcia', '31': 'Navarra', '32': 'Ourense',
      '33': 'Asturias', '34': 'Palencia', '35': 'Las Palmas', '36': 'Pontevedra',
      '37': 'Salamanca', '38': 'Santa Cruz de Tenerife', '39': 'Cantabria',
      '40': 'Segovia', '41': 'Sevilla', '42': 'Soria', '43': 'Tarragona',
      '44': 'Teruel', '45': 'Toledo', '46': 'Valencia', '47': 'Valladolid',
      '48': 'Bizkaia', '49': 'Zamora', '50': 'Zaragoza', '51': 'Ceuta',
      '52': 'Melilla'
    }

    const prefijo = cp.substring(0, 2)
    if (provinciaMap[prefijo]) {
      setFormData(prev => ({ ...prev, provincia: provinciaMap[prefijo] }))
    }
  }

  // Validación en tiempo real
  const validateField = (name: string, value: string) => {
    const newErrors = { ...errors }

    switch (name) {
      case 'cif':
        if (value && !/^[A-HJ-NP-SUVW][0-9]{7}[0-9A-J]$|^[0-9]{8}[A-Z]$/.test(value)) {
          newErrors.cif = 'CIF/NIF no válido'
        } else {
          delete newErrors.cif
        }
        break
      case 'codigo_postal':
        if (value && !/^[0-9]{5}$/.test(value)) {
          newErrors.codigo_postal = 'Código postal debe tener 5 dígitos'
        } else {
          delete newErrors.codigo_postal
        }
        break
      case 'telefono':
        if (value && !/^[6-9][0-9]{8}$/.test(value.replace(/\s/g, ''))) {
          newErrors.telefono = 'Teléfono no válido (ej: 678123456)'
        } else {
          delete newErrors.telefono
        }
        break
      case 'email':
        if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          newErrors.email = 'Email no válido'
        } else {
          delete newErrors.email
        }
        break
    }

    setErrors(newErrors)
  }

  useEffect(() => {
    const planFromUrl = searchParams.get('plan')
    if (planFromUrl && planTotalPrices[planFromUrl]) {
      setSelectedPlan(planFromUrl)
    }
  }, [searchParams])

  // CORRECTED: New calculation logic with proper payment split
  const calculateTotal = () => {
    const planPrice = selectedPlan ? planTotalPrices[selectedPlan] : 0
    const kitPrice = kitComunicacion ? 30 : 0 // Kit price SIN IVA
    const isTemporalPlan = selectedPlan === 'temporal'

    // CORRECTED: Payment logic per your specifications
    // Plans (except temporal): 50% plan now + 100% kit now, 50% plan in 6 months
    // Temporal: 100% now
    // Kit: Always 100% now when selected

    let firstPaymentBase, secondPaymentBase

    if (isTemporalPlan) {
      // Temporal: 100% now, nothing later
      firstPaymentBase = planPrice + kitPrice
      secondPaymentBase = 0
    } else {
      // Regular plans: 50% plan + 100% kit now, 50% plan later
      firstPaymentBase = (planPrice / 2) + kitPrice
      secondPaymentBase = planPrice / 2
    }

    const firstPaymentVat = firstPaymentBase * 0.21
    const secondPaymentVat = secondPaymentBase * 0.21

    const firstPayment = firstPaymentBase + firstPaymentVat
    const secondPayment = secondPaymentBase + secondPaymentVat

    // Total service calculation
    const subtotal = planPrice + kitPrice
    const vat = subtotal * 0.21
    const totalComplete = subtotal + vat

    return {
      subtotal,           // Total sin IVA del servicio completo
      vat,               // Total IVA del servicio completo
      total: totalComplete,     // Total completo del servicio
      firstPayment,      // Pago de hoy (50% plan + 100% kit + IVA)
      secondPayment,     // Pago a los 6 meses (50% plan + IVA)
      firstPaymentBase,  // Base sin IVA del primer pago
      secondPaymentBase, // Base sin IVA del segundo pago
      firstPaymentVat,   // IVA del primer pago
      secondPaymentVat,  // IVA del segundo pago
      isTemporalPlan
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target

    setFormData(prev => ({
      ...prev,
      [name]: value
    }))

    if (name === 'num_menores') {
      const autoSelectedPlan = getAutoSelectedPlan(value)
      if (autoSelectedPlan) {
        setSelectedPlan(autoSelectedPlan)
        console.log(`🎯 Plan seleccionado automáticamente: ${autoSelectedPlan} para ${value} menores`)
      }
    }
  }

  const validateForm = (): boolean => {
    const required = [
      'nombre_entidad', 'cif', 'tipo_entidad', 'num_menores',
      'direccion_linea1', 'codigo_postal', 'ciudad', 'provincia',
      'responsable', 'cargo_responsable', 'email', 'telefono'
    ]

    for (const field of required) {
      if (!formData[field as keyof FormData]) {
        alert(`Por favor completa el campo: ${field.replace('_', ' ')}`)
        return false
      }
    }

    if (!selectedPlan) {
      alert('Por favor selecciona un plan')
      return false
    }

    if (Object.keys(errors).length > 0) {
      alert('Por favor corrige los errores en el formulario')
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setLoading(true)
    setShowPayment(true)
    setLoading(false)
  }

  if (showPayment) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex items-center mb-6">
              <button
                onClick={() => setShowPayment(false)}
                className="flex items-center text-orange-600 hover:text-orange-700 mr-4"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Volver al formulario
              </button>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              💳 Completar Pago
            </h2>

            <div className="mb-6 p-4 bg-orange-50 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">Resumen del pedido - Pago de hoy:</h3>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Plan {planNames[selectedPlan]} {calculateTotal().isTemporalPlan ? '(completo)' : '(50%)'}</span>
                  <span>{calculateTotal().isTemporalPlan ? planTotalPrices[selectedPlan] : (planTotalPrices[selectedPlan] / 2)}€</span>
                </div>
                {kitComunicacion && (
                  <div className="flex justify-between">
                    <span>Kit de Comunicación (100%)</span>
                    <span>30€</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-600">
                  <span>IVA (21%)</span>
                  <span>{calculateTotal().firstPaymentVat.toFixed(2)}€</span>
                </div>
                <div className="border-t pt-2 space-y-1">
                  <div className="flex justify-between font-bold text-lg text-orange-600">
                    <span>Total a pagar hoy:</span>
                    <span>{calculateTotal().firstPayment.toFixed(2)}€</span>
                  </div>
                  {!calculateTotal().isTemporalPlan && calculateTotal().secondPayment > 0 && (
                    <div className="bg-blue-50 rounded p-2 mt-2">
                      <div className="text-xs text-blue-700 font-semibold">Próximo pago automático (6 meses):</div>
                      <div className="text-sm text-blue-800">
                        Plan restante (50%): {(planTotalPrices[selectedPlan] / 2)}€ + IVA = {calculateTotal().secondPayment.toFixed(2)}€
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <SimplePayment
              formData={formData}
              selectedPlan={selectedPlan}
              includesKit={kitComunicacion}
            />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-white border-b py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-4">
            <Link href="/planes" className="flex items-center text-orange-600 hover:text-orange-700 mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Volver a Planes
            </Link>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Contratación Custodia360</h1>
          <p className="text-gray-600 mt-2">Completa tus datos y selecciona tu plan. Implementación en 24 horas.</p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-2 gap-8">

            {/* FORMULARIO INTELIGENTE MEJORADO */}
            <div className="space-y-6">

              {/* DATOS BÁSICOS DE LA ENTIDAD */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">📋 Datos de la Entidad</h3>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre de la Entidad *
                    </label>
                    <input
                      type="text"
                      value={formData.nombre_entidad}
                      onChange={handleInputChange}
                      name="nombre_entidad"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Club Deportivo Ejemplo"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      CIF/NIF *
                    </label>
                    <input
                      type="text"
                      value={formData.cif}
                      onChange={(e) => {
                        const value = e.target.value.toUpperCase()
                        handleInputChange({ target: { name: 'cif', value } } as any)
                        validateField('cif', value)
                      }}
                      name="cif"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                        errors.cif ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="G12345678"
                      required
                    />
                    {errors.cif && <p className="text-red-500 text-xs mt-1">{errors.cif}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de Entidad *
                    </label>
                    <select
                      value={formData.tipo_entidad}
                      onChange={(e) => {
                        handleInputChange({ target: { name: 'tipo_entidad', value: e.target.value } } as any)
                        setFormData(prev => ({ ...prev, cargo_responsable: '' }))
                      }}
                      name="tipo_entidad"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      required
                    >
                      <option value="">Selecciona el tipo</option>
                      {Object.entries(TIPOS_ENTIDAD).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Número de Menores *
                    </label>
                    <input
                      type="number"
                      value={formData.num_menores}
                      onChange={handleInputChange}
                      name="num_menores"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      placeholder="50"
                      min="1"
                      max="10000"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* DIRECCIÓN FISCAL */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">📍 Dirección Fiscal</h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dirección Completa *
                    </label>
                    <input
                      type="text"
                      value={formData.direccion_linea1}
                      onChange={handleInputChange}
                      name="direccion_linea1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Calle Mayor 123, 2º A"
                      required
                    />
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Código Postal *
                      </label>
                      <input
                        type="text"
                        value={formData.codigo_postal}
                        onChange={(e) => {
                          const value = e.target.value
                          handleCodigoPostalChange(value)
                          validateField('codigo_postal', value)
                        }}
                        name="codigo_postal"
                        className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                          errors.codigo_postal ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="28001"
                        maxLength={5}
                        required
                      />
                      {errors.codigo_postal && <p className="text-red-500 text-xs mt-1">{errors.codigo_postal}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Ciudad *
                      </label>
                      <input
                        type="text"
                        value={formData.ciudad}
                        onChange={handleInputChange}
                        name="ciudad"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        placeholder="Madrid"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Provincia *
                      </label>
                      <input
                        type="text"
                        value={formData.provincia}
                        onChange={handleInputChange}
                        name="provincia"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        placeholder="Madrid"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* CONTACTO PRINCIPAL */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">👤 Responsable Principal</h3>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre del Responsable *
                    </label>
                    <input
                      type="text"
                      value={formData.responsable}
                      onChange={handleInputChange}
                      name="responsable"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Juan Pérez García"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cargo *
                    </label>
                    <select
                      value={formData.cargo_responsable}
                      onChange={handleInputChange}
                      name="cargo_responsable"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                      required
                    >
                      <option value="">Selecciona el cargo</option>
                      {getAvailableCargos().map(cargo => (
                        <option key={cargo} value={cargo}>{cargo}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => {
                        const value = e.target.value
                        handleInputChange({ target: { name: 'email', value } } as any)
                        validateField('email', value)
                      }}
                      name="email"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                        errors.email ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="contacto@entidad.com"
                      required
                    />
                    {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Teléfono *
                    </label>
                    <input
                      type="tel"
                      value={formData.telefono}
                      onChange={(e) => {
                        const value = e.target.value
                        handleInputChange({ target: { name: 'telefono', value } } as any)
                        validateField('telefono', value)
                      }}
                      name="telefono"
                      className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                        errors.telefono ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="678 123 456"
                      required
                    />
                    {errors.telefono && <p className="text-red-500 text-xs mt-1">{errors.telefono}</p>}
                  </div>
                </div>
              </div>

              {/* CAMPOS OPCIONALES */}
              <div className="bg-blue-50 rounded-lg shadow p-6">
                <button
                  type="button"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="flex items-center text-blue-700 hover:text-blue-800 font-medium"
                >
                  <span>{showAdvanced ? '▼' : '▶'}</span>
                  <span className="ml-2">🔧 Configuración Adicional (Opcional)</span>
                </button>

                {showAdvanced && (
                  <div className="mt-4 space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Delegado de Protección (si ya designado)
                        </label>
                        <input
                          type="text"
                          value={formData.delegado_designado || ''}
                          onChange={handleInputChange}
                          name="delegado_designado"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                          placeholder="María González"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email del Delegado
                        </label>
                        <input
                          type="email"
                          value={formData.email_delegado || ''}
                          onChange={handleInputChange}
                          name="email_delegado"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                          placeholder="delegado@entidad.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email Facturación (si diferente)
                        </label>
                        <input
                          type="email"
                          value={formData.email_facturacion || ''}
                          onChange={handleInputChange}
                          name="email_facturacion"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                          placeholder="facturacion@entidad.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Idioma Preferido
                        </label>
                        <select
                          value={formData.idioma_preferido}
                          onChange={handleInputChange}
                          name="idioma_preferido"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        >
                          <option value="es">🇪🇸 Español</option>
                          <option value="ca">🏴󠁥󠁳󠁣󠁴󠁿 Català</option>
                          <option value="gl">🏴󠁥󠁳󠁧󠁡󠁿 Galego</option>
                          <option value="eu">🏴󠁥󠁳󠁰󠁶󠁿 Euskera</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Observaciones adicionales
                      </label>
                      <textarea
                        value={formData.observaciones || ''}
                        onChange={handleInputChange}
                        name="observaciones"
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        placeholder="Información adicional sobre tu entidad o necesidades específicas..."
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* ACEPTACIÓN */}
              <div className="bg-white rounded-lg shadow-lg p-6">
                <div className="space-y-4">
                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      required
                      className="mt-1 mr-3 h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                    />
                    <span className="text-sm text-gray-700">
                      Acepto los <Link href="/terminos" className="text-orange-600 hover:underline">términos y condiciones</Link> y la <Link href="/privacidad" className="text-orange-600 hover:underline">política de privacidad</Link> *
                    </span>
                  </label>

                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      required
                      className="mt-1 mr-3 h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                    />
                    <span className="text-sm text-gray-700">
                      Confirmo que los datos proporcionados son correctos y que tengo autoridad para contratar en nombre de la entidad *
                    </span>
                  </label>
                </div>
              </div>
            </div>

            {/* Selección de Plan y Resumen */}
            <div className="space-y-6">

              {/* Selección de Plan */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Selecciona tu Plan</h2>

                <div className="space-y-4">
                  {Object.entries(planTotalPrices).map(([key, price]) => (
                    <label key={key} className={`block p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      selectedPlan === key ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                    }`}>
                      <input
                        type="radio"
                        name="plan"
                        value={key}
                        className="sr-only"
                        checked={selectedPlan === key}
                        onChange={(e) => setSelectedPlan(e.target.value)}
                      />
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-gray-900">{planNames[key]}</div>
                          <div className="text-sm text-gray-600">
                            {price}€ + IVA {key !== 'temporal' ? '(50% ahora + 50% a los 6 meses)' : '(pago único)'}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">{price}€</div>
                          {key !== 'temporal' && (
                            <div className="text-sm text-gray-500">Total: {(price * 1.21).toFixed(2)}€</div>
                          )}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Kit de Comunicación */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Complementos Opcionales</h3>

                <label className="flex items-start p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <input
                    type="checkbox"
                    name="kit_comunicacion"
                    checked={kitComunicacion}
                    onChange={(e) => setKitComunicacion(e.target.checked)}
                    className="mt-1 mr-4 h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-semibold text-gray-900">Kit de Comunicación</div>
                      <div className="text-xl font-bold text-teal-600">+30€</div>
                    </div>
                    <div className="text-sm text-gray-600 mb-3">
                      Material LOPIVI completo para comunicar con familias y personal
                    </div>
                    <div className="text-sm text-gray-700">
                      <div className="font-medium mb-1">Incluye:</div>
                      <ul className="space-y-1 text-xs">
                        <li>• Carteles informativos LOPIVI</li>
                        <li>• Comunicados para familias</li>
                        <li>• Templates personalizados</li>
                        <li>• Entrega en 24 horas</li>
                      </ul>
                    </div>
                  </div>
                </label>
              </div>

              {/* Resumen del Pedido */}
              <div className="bg-orange-50 rounded-lg shadow-lg p-8 border-2 border-orange-200">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Resumen del Pedido</h3>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-700">Plan seleccionado:</span>
                    <span className="font-medium">{selectedPlan ? planNames[selectedPlan] : 'No seleccionado'}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-gray-700">Kit de comunicación:</span>
                    <span className="font-medium">{kitComunicacion ? 'Kit añadido (+30€)' : 'No añadido'}</span>
                  </div>

                  <div className="border-t pt-3 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal (sin IVA):</span>
                      <span>{calculateTotal().subtotal.toFixed(2)}€</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>IVA (21%):</span>
                      <span>{calculateTotal().vat.toFixed(2)}€</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Total completo del servicio:</span>
                      <span>{calculateTotal().total.toFixed(2)}€</span>
                    </div>

                    <div className="bg-orange-100 rounded-lg p-3 mt-3">
                      <div className="flex justify-between text-lg font-bold">
                        <span className="text-orange-800">
                          {calculateTotal().isTemporalPlan ? 'Pago único hoy:' : 'Pago hoy:'}
                        </span>
                        <span className="text-orange-600">{calculateTotal().firstPayment.toFixed(2)}€</span>
                      </div>

                      {/* Desglose del pago de hoy */}
                      <div className="text-xs text-orange-700 mt-1">
                        {!calculateTotal().isTemporalPlan && `• Plan (50%): ${(planTotalPrices[selectedPlan] / 2).toFixed(0)}€`}
                        {calculateTotal().isTemporalPlan && selectedPlan && `• Plan completo: ${planTotalPrices[selectedPlan]}€`}
                        {kitComunicacion && ` • Kit: 30€`}
                        {` • IVA: ${calculateTotal().firstPaymentVat.toFixed(2)}€`}
                      </div>

                      {!calculateTotal().isTemporalPlan && calculateTotal().secondPayment > 0 && (
                        <>
                          <div className="flex justify-between text-sm text-orange-700 mt-2">
                            <span>Segundo pago (6 meses):</span>
                            <span>{calculateTotal().secondPayment.toFixed(2)}€</span>
                          </div>
                          <div className="text-xs text-orange-700">
                            • Plan (50%): {(planTotalPrices[selectedPlan] / 2).toFixed(0)}€ • IVA: {calculateTotal().secondPaymentVat.toFixed(2)}€
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Botón de Contratación */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <div className="text-center">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">¿Todo correcto?</h3>
                  <button
                    type="submit"
                    disabled={!selectedPlan || loading}
                    className="w-full bg-orange-600 text-white py-4 px-6 rounded-lg hover:bg-orange-700 transition-colors font-bold text-lg disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {loading ? 'Procesando...' : '💳 Proceder al Pago'}
                  </button>
                  <div className="text-sm text-gray-600 mt-3">
                    Pago seguro con tarjeta • Implementación en 24h
                  </div>
                </div>
              </div>

              {/* Qué incluye */}
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Todos los planes incluyen:</h3>
                <div className="space-y-2 text-sm text-gray-700">
                  <div className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span>Delegado de protección formado</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span>Plan de protección personalizado</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span>Protocolos de actuación</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span>Formación del personal</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    <span>Documentación completa</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Cargando...</p>
      </div>
    </div>
  )
}

export default function ContratacionPage() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <ContratacionContent />
    </Suspense>
  )
}
