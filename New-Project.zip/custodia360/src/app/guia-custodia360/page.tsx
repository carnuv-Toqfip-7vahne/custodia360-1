import type { Metadata } from 'next'
import Link from 'next/link'
import { BookOpen, Download, CheckCircle, ArrowRight, FileText, Video, Users } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Guía Custodia360 - Cómo Funciona | Manual de Usuario LOPIVI y Plan de Protección',
  description: 'Guía completa de Custodia360: cómo funciona la implementación LOPIVI y Plan de Protección, pasos a seguir y mejores prácticas para tu entidad.',
}

export default function GuiaCustodia360Page() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Guía <span className="text-orange-600">Custodia360</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Todo lo que necesitas saber para implementar la LOPIVI y Plan de Protección en tu entidad
          </p>
        </div>
      </section>

      {/* Pasos del Proceso */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Proceso Paso a Paso</h2>
            <p className="text-xl text-gray-600">De la contratación al cumplimiento total en 24 horas</p>
          </div>

          <div className="space-y-12">
            {/* Paso 1 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/3">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold text-blue-600">1</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 text-center mb-4">Contratación</h3>
              </div>
              <div className="md:w-2/3">
                <div className="bg-blue-50 rounded-lg p-6">
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Selecciona tu plan según número de menores</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Completa el formulario con datos de tu entidad</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Realiza el pago seguro con Stripe</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Recibe confirmación inmediata</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Paso 2 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/3 md:order-2">
                <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold text-orange-600">2</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 text-center mb-4">Implementación</h3>
              </div>
              <div className="md:w-2/3 md:order-1">
                <div className="bg-orange-50 rounded-lg p-6">
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">La asignación del delegado la hace la entidad</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Generación personalizada de toda la documentación</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Configuración de protocolos específicos</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Activación del sistema de gestión</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Paso 3 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/3">
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold text-green-600">3</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 text-center mb-4">Contacto directo con tu delegado designado</h3>
              </div>
              <div className="md:w-2/3">
                <div className="bg-green-50 rounded-lg p-6">
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Recepción de documentación completa por email</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">A través del dashboard el delegado está totalmente al día</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Acceso al panel de gestión online</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Formación inicial para tu equipo</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Paso 4 */}
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/3 md:order-2">
                <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold text-purple-600">4</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 text-center mb-4">Mantenimiento</h3>
              </div>
              <div className="md:w-2/3 md:order-1">
                <div className="bg-purple-50 rounded-lg p-6">
                  <ul className="space-y-3">

                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Actualizaciones automáticas de normativa</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Formación continua del personal</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-1" />
                      <span className="text-gray-700">Renovación automática a los 12 meses</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recursos Disponibles */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Recursos Disponibles</h2>
            <p className="text-xl text-gray-600">Todo lo que necesitas para el éxito de tu implementación</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Documentación */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <FileText className="h-8 w-8 text-blue-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Documentación</h3>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Plan de protección integral</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Protocolos de actuación</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Código de conducta</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Registros y formularios</span>
                </li>
              </ul>
              <Link
                href="/demo"
                className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
              >
                Ver ejemplos <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>

            {/* Formación */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Video className="h-8 w-8 text-green-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Formación</h3>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Manuales descargables</span>
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Certificados de participación</span>
                </li>
              </ul>
              <Link
                href="/contacto"
                className="inline-flex items-center text-green-600 hover:text-green-700 font-medium"
              >
                Solicitar formación <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>

            {/* Soporte */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Users className="h-8 w-8 text-orange-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Soporte</h3>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Chat en vivo 24/7</span>
                </li>


                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></span>
                  <span className="text-gray-700">Comunicación vía mail</span>
                </li>
              </ul>
              <Link
                href="/contacto"
                className="inline-flex items-center text-orange-600 hover:text-orange-700 font-medium"
              >
                Contactar soporte <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Preguntas Frecuentes</h2>
            <p className="text-xl text-gray-600">Resolvemos las dudas más comunes sobre Custodia360</p>
          </div>

          <div className="space-y-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Qué pasa si cambia la normativa?</h3>
              <p className="text-gray-600">
                Nuestro sistema se actualiza automáticamente cuando hay cambios normativos.
                Recibirás la documentación actualizada sin coste adicional.
              </p>
            </div>



            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Cómo funciona la formación del personal?</h3>
              <p className="text-gray-600">
                Incluimos formación inicial online y actualizaciones cuando hay cambios.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">¿Qué incluye exactamente cada plan?</h3>
              <p className="text-gray-600">
                Todos los planes incluyen lo mismo: delegado formado, documentación, formación y soporte.
                Solo cambia el precio según el número de menores.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Descargables */}
      <section className="py-16 bg-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Recursos Descargables</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <Download className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-4">Guía LOPIVI Básica</h3>
              <p className="text-gray-600 mb-6">Introducción completa a la normativa y obligaciones</p>
              <a
                href="/guia-lopivi-basica.html"
                download="Guia-LOPIVI-Basica-Custodia360.html"
                className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Descargar PDF
              </a>
            </div>

            <div className="bg-white rounded-lg p-8 shadow-lg">
              <Download className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-4">Checklist de Cumplimiento</h3>
              <p className="text-gray-600 mb-6">Lista verificable de todos los requisitos LOPIVI</p>
              <a
                href="/checklist-cumplimiento-lopivi.html"
                download="Checklist-Cumplimiento-LOPIVI-Custodia360.html"
                className="inline-block bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
              >
                Descargar PDF
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Listo para comenzar?</h2>
          <p className="text-xl mb-8 opacity-90">Implementa la LOPIVI en tu entidad hoy mismo</p>

          <div className="flex justify-center gap-4">
            <Link
              href="/planes"
              className="px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Ver Planes
            </Link>
            <Link
              href="/demo"
              className="px-8 py-4 bg-orange-700 text-white border-2 border-white rounded-lg hover:bg-orange-800 transition-colors font-semibold"
            >
              Ver Demo
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
