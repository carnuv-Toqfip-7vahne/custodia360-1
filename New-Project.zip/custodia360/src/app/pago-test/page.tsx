'use client'

export default function PagoTestPage() {
  const handleStripePayment = () => {
    // Simulate successful payment
    alert('✅ Simulando pago exitoso...')
    // Redirect to success page
    window.location.href = '/contratacion/success?session_id=test_session_12345&plan=51-200'
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md mx-auto text-center p-8 bg-white rounded-lg shadow-lg">
        <h1 className="text-2xl font-bold mb-6">Test de Pago Directo</h1>

        <div className="mb-6">
          <p className="text-gray-600 mb-2">Plan: 51-200 menores</p>
          <p className="text-2xl font-bold text-orange-600">59.29€</p>
          <p className="text-sm text-gray-500">(IVA incluido)</p>
        </div>

        <button
          onClick={handleStripePayment}
          className="w-full bg-orange-600 text-white py-4 px-6 rounded-lg hover:bg-orange-700 transition-colors font-bold text-lg"
        >
          💳 Pagar Ahora con Stripe
        </button>

        <p className="text-xs text-gray-500 mt-4">
          Test con tarjeta: 4242 4242 4242 4242
        </p>
      </div>
    </div>
  )
}
