import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, Users, FileText, AlertTriangle, CheckCircle, Clock, Bell } from 'lucide-react'
import AccionesRapidas from '@/components/AccionesRapidas'

export const metadata: Metadata = {
  title: 'Demo - Panel de Control LOPIVI | Custodia360',
  description: 'Descubre el panel de control de Custodia360: gestión completa LOPIVI, seguimiento de casos, protocolos y más.',
}

export default function DemoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Panel de Control <span className="text-orange-600">LOPIVI</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Gestiona toda la protección infantil desde una sola plataforma
          </p>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-xl overflow-hidden">

            {/* Dashboard Header */}
            <div className="bg-orange-600 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Shield className="h-8 w-8 mr-3" />
                  <div>
                    <h2 className="text-2xl font-bold">Dashboard Custodia360</h2>
                    <p className="opacity-90">Club Deportivo Ejemplo - 156 menores</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Bell className="h-6 w-6 mr-2" />
                  <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">3</span>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="p-6 border-b">
              <div className="grid md:grid-cols-4 gap-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="h-8 w-8 text-green-600 mr-3" />
                    <div>
                      <div className="text-2xl font-bold text-green-600">100%</div>
                      <div className="text-sm text-gray-600">Cumplimiento LOPIVI</div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-blue-600 mr-3" />
                    <div>
                      <div className="text-2xl font-bold text-blue-600">15</div>
                      <div className="text-sm text-gray-600">Personal Formado</div>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <FileText className="h-8 w-8 text-orange-600 mr-3" />
                    <div>
                      <div className="text-2xl font-bold text-orange-600">23</div>
                      <div className="text-sm text-gray-600">Protocolos Activos</div>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
                    <div>
                      <div className="text-2xl font-bold text-red-600">2</div>
                      <div className="text-sm text-gray-600">Casos Abiertos</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-8">

                {/* Recent Activity */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Actividad Reciente</h3>
                  <div className="space-y-4">
                    <div className="flex items-start p-4 bg-yellow-50 rounded-lg">
                      <Clock className="h-5 w-5 text-yellow-600 mr-3 mt-1" />
                      <div>
                        <div className="font-medium text-gray-900">Formación Pendiente</div>
                        <div className="text-sm text-gray-600">3 personas necesitan completar la formación obligatoria</div>
                        <div className="text-xs text-yellow-600 mt-1">Hace 2 horas</div>
                      </div>
                    </div>

                    <div className="flex items-start p-4 bg-green-50 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-1" />
                      <div>
                        <div className="font-medium text-gray-900">Protocolo Actualizado</div>
                        <div className="text-sm text-gray-600">Protocolo de prevención revisado y aprobado</div>
                        <div className="text-xs text-green-600 mt-1">Hace 1 día</div>
                      </div>
                    </div>

                    <div className="flex items-start p-4 bg-blue-50 rounded-lg">
                      <FileText className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                      <div>
                        <div className="font-medium text-gray-900">Nuevo Registro</div>
                        <div className="text-sm text-gray-600">Comunicación con autoridades documentada</div>
                        <div className="text-xs text-blue-600 mt-1">Hace 3 días</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Acciones Rápidas</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <button className="p-4 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                      <FileText className="h-6 w-6 mx-auto mb-2" />
                      <div className="text-sm font-medium">Nuevo Caso</div>
                    </button>

                    <button className="p-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                      <Users className="h-6 w-6 mx-auto mb-2" />
                      <div className="text-sm font-medium">Formar Personal</div>
                    </button>

                    <button className="p-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                      <CheckCircle className="h-6 w-6 mx-auto mb-2" />
                      <div className="text-sm font-medium">Ver Protocolos</div>
                    </button>

                    <button className="p-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                      <Shield className="h-6 w-6 mx-auto mb-2" />
                      <div className="text-sm font-medium">Contactar Delegado</div>
                    </button>
                  </div>

                  {/* Nuevo: Botón de Emergencia */}
                  <div className="mt-6">
                    <AccionesRapidas
                      delegadoNombre="María García"
                      delegadoTelefono="678 771 198"
                      delegadoEmail="delegado@clubejemplo.es"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Dashboard Footer */}
            <div className="bg-gray-50 p-4 border-t">
              <div className="flex justify-between items-center text-sm text-gray-600">
                <div>Última actualización: Hoy 14:30</div>
                <div>Estado: ✅ Todos los sistemas operativos</div>
              </div>
            </div>
          </div>

          {/* Features Overview */}
          <div className="mt-12 grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Shield className="h-12 w-12 text-orange-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Protección Total</h3>
              <p className="text-gray-600">Monitoreo 24/7 con alertas automáticas y protocolos de actuación inmediata.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <FileText className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Documentación Completa</h3>
              <p className="text-gray-600">Todos los protocolos, registros y comunicaciones organizados automáticamente.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Users className="h-12 w-12 text-green-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Formación Continua</h3>
              <p className="text-gray-600">Sistema de formación automático con seguimiento de progreso del personal.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Listo para implementar la LOPIVI en tu entidad?</h2>
          <p className="text-xl mb-8 opacity-90">Panel de control completo incluido en todos nuestros planes</p>

          <div className="flex justify-center gap-4">
            <Link
              href="/planes"
              className="px-8 py-4 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Ver Planes
            </Link>
            <Link
              href="/contacto"
              className="px-8 py-4 bg-orange-700 text-white border-2 border-white rounded-lg hover:bg-orange-800 transition-colors font-semibold"
            >
              Contactar
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
