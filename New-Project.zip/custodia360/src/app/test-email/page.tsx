'use client'

import { useState } from 'react'

export default function TestEmailPage() {
  const [email, setEmail] = useState('rsune@teamsml.com')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const testEmailConfiguration = async () => {
    setLoading(true)
    setResult(null)

    try {
      console.log('🧪 Testing email configuration...')

      const response = await fetch('/api/test-email-simple', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      })

      const data = await response.json()
      setResult(data)

      console.log('📧 Email test result:', data)

    } catch (error) {
      console.error('❌ Email test failed:', error)
      setResult({
        success: false,
        error: 'Network error',
        details: error instanceof Error ? error.message : 'Unknown error'
      })
    } finally {
      setLoading(false)
    }
  }

  const testPaymentEmail = async () => {
    setLoading(true)
    setResult(null)

    try {
      console.log('🧪 Testing payment confirmation email...')

      const mockData = {
        sessionId: 'test_session_123',
        customerData: {
          nombre_entidad: 'Test Entity',
          cif: 'G12345678',
          responsable: 'Test User',
          email: email,
          telefono: '678 123 456',
          direccion: 'Test Address 123, Madrid'
        },
        orderData: {
          sessionId: 'test_session_123',
          planName: '51-200 menores + Kit',
          amount: 95.59,
          includesKit: true,
          paymentDate: new Date()
        }
      }

      const response = await fetch('/api/send-emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(mockData)
      })

      const data = await response.json()
      setResult(data)

      console.log('📧 Payment email test result:', data)

    } catch (error) {
      console.error('❌ Payment email test failed:', error)
      setResult({
        success: false,
        error: 'Network error',
        details: error instanceof Error ? error.message : 'Unknown error'
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">🧪 Test Email Configuration</h1>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email de prueba:
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500"
                placeholder="email@ejemplo.com"
              />
            </div>

            <div className="flex gap-4">
              <button
                onClick={testEmailConfiguration}
                disabled={loading}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
              >
                {loading ? 'Enviando...' : '📧 Test Simple Email'}
              </button>

              <button
                onClick={testPaymentEmail}
                disabled={loading}
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 transition-colors"
              >
                {loading ? 'Enviando...' : '💳 Test Payment Email'}
              </button>
            </div>

            {result && (
              <div className={`p-6 rounded-lg ${result.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                <h3 className={`text-lg font-bold mb-4 ${result.success ? 'text-green-800' : 'text-red-800'}`}>
                  {result.success ? '✅ Email Sent Successfully!' : '❌ Email Failed'}
                </h3>

                <pre className="bg-gray-100 p-4 rounded text-xs overflow-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>

                {result.success && (
                  <div className="mt-4 p-4 bg-blue-50 rounded">
                    <p className="text-blue-800">
                      <strong>✅ Check your email inbox (and spam folder) for the test message.</strong>
                    </p>
                    {result.emailId && (
                      <p className="text-blue-600 mt-2">Email ID: {result.emailId}</p>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
