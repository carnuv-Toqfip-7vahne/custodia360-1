import Link from 'next/link'
import { CheckCircle } from 'lucide-react'

export default function SuccessTestPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-lg mx-auto text-center p-8 bg-white rounded-lg shadow-lg">
        <CheckCircle className="w-16 h-16 text-green-600 mb-6 mx-auto" />

        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          ¡Página Success FUNCIONA! ✅
        </h1>

        <div className="bg-green-50 rounded-lg p-6 mb-6">
          <p className="text-green-800 font-medium mb-2">Esta es una página estática ultra simple.</p>
          <p className="text-green-700">Si ves esto, el problema NO está en Next.js ni el servidor.</p>
        </div>

        <div className="bg-blue-50 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-blue-800 mb-2">🔍 Diagnóstico:</h4>
          <div className="text-sm text-blue-700 text-left space-y-1">
            <p>✅ Servidor Next.js funcionando</p>
            <p>✅ Componentes React funcionando</p>
            <p>✅ Lucide icons funcionando</p>
            <p>✅ Tailwind CSS funcionando</p>
            <p>✅ Routing funcionando</p>
          </div>
        </div>

        <div className="space-y-3">
          <Link
            href="/"
            className="block w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors font-medium"
          >
            Volver al Inicio
          </Link>

          <Link
            href="/contratacion/success"
            className="block w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Probar Success Original
          </Link>
        </div>

        <div className="mt-6 text-xs text-gray-500">
          <p>🧪 Success Test Page - Diagnóstico Sistemático</p>
        </div>
      </div>
    </div>
  )
}
