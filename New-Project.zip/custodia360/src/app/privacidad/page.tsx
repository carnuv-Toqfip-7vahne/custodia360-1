import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft, Shield } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Política de Privacidad - Custodia360',
  description: 'Política de privacidad de Custodia360. Protección de datos según RGPD.',
}

export default function PrivacidadPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white border-b py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-4">
            <Link href="/" className="flex items-center text-orange-600 hover:text-orange-700 mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Volver al Inicio
            </Link>
          </div>
          <div className="flex items-center space-x-3">
            <Shield className="h-8 w-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-gray-900">Política de Privacidad</h1>
          </div>
          <p className="text-gray-600 mt-2">Última actualización: 22 de julio de 2025</p>
        </div>
      </section>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-lg p-8">

          <div className="prose prose-lg max-w-none">

            <h2>1. Responsable del Tratamiento</h2>
            <p>
              <strong>Custodia360</strong> (propiedad de sportsmotherland)<br />
              Email: info@custodia360.es<br />
              Teléfono: 678 771 198<br />
              Dirección: Barcelona, España
            </p>

            <h2>2. Datos que Recopilamos</h2>

            <h3>2.1 Datos de Identificación</h3>
            <ul>
              <li>Nombre y apellidos del responsable de la entidad</li>
              <li>Nombre de la entidad deportiva u organización</li>
              <li>CIF/NIF de la entidad</li>
              <li>Dirección postal completa</li>
              <li>Teléfono de contacto</li>
              <li>Dirección de correo electrónico</li>
            </ul>

            <h3>2.2 Datos de la Actividad</h3>
            <ul>
              <li>Tipo de entidad (club deportivo, escuela, etc.)</li>
              <li>Número de menores bajo responsabilidad</li>
              <li>Información sobre la estructura organizativa</li>
              <li>Datos relevantes para el cumplimiento LOPIVI</li>
            </ul>

            <h3>2.3 Datos de Navegación</h3>
            <ul>
              <li>Dirección IP</li>
              <li>Datos de cookies técnicas</li>
              <li>Información del navegador y dispositivo</li>
              <li>Páginas visitadas y tiempo de navegación</li>
            </ul>

            <h2>3. Finalidades del Tratamiento</h2>

            <h3>3.1 Prestación de Servicios</h3>
            <p>
              Utilizamos sus datos para proporcionar nuestros servicios de cumplimiento LOPIVI,
              incluyendo la creación de planes de protección personalizados, formación del personal
              y mantenimiento de la documentación.
            </p>

            <h3>3.2 Gestión Comercial</h3>
            <p>
              Para la gestión de presupuestos, contratos, facturación y comunicaciones
              comerciales relacionadas con nuestros servicios.
            </p>

            <h3>3.3 Cumplimiento Legal</h3>
            <p>
              Para cumplir con las obligaciones legales aplicables, incluyendo el mantenimiento
              de registros contables y fiscales.
            </p>

            <h2>4. Base Jurídica</h2>
            <ul>
              <li><strong>Ejecución contractual:</strong> Para la prestación de nuestros servicios</li>
              <li><strong>Interés legítimo:</strong> Para comunicaciones comerciales y mejora de servicios</li>
              <li><strong>Cumplimiento legal:</strong> Para obligaciones fiscales y contables</li>
              <li><strong>Consentimiento:</strong> Para envío de newsletter y comunicaciones promocionales</li>
            </ul>

            <h2>5. Destinatarios de los Datos</h2>
            <p>Sus datos pueden ser compartidos con:</p>
            <ul>
              <li><strong>Proveedores de servicios tecnológicos:</strong> Para el funcionamiento de nuestra plataforma</li>
              <li><strong>Servicios de pago:</strong> Stripe para el procesamiento de pagos</li>
              <li><strong>Servicios de email:</strong> Resend para el envío de comunicaciones</li>
              <li><strong>Asesores profesionales:</strong> Cuando sea necesario para la prestación del servicio</li>
              <li><strong>Autoridades competentes:</strong> Cuando sea requerido por ley</li>
            </ul>

            <h2>6. Transferencias Internacionales</h2>
            <p>
              Algunos de nuestros proveedores de servicios pueden estar ubicados fuera del Espacio
              Económico Europeo. En estos casos, garantizamos que se aplican las medidas de protección
              adecuadas según el RGPD.
            </p>

            <h2>7. Conservación de Datos</h2>
            <ul>
              <li><strong>Clientes activos:</strong> Durante la duración del contrato y 6 años adicionales</li>
              <li><strong>Datos fiscales:</strong> 4 años desde la última operación</li>
              <li><strong>Datos de navegación:</strong> Máximo 2 años</li>
              <li><strong>Newsletter:</strong> Hasta que revoque el consentimiento</li>
            </ul>

            <h2>8. Sus Derechos</h2>
            <p>Según el RGPD, tiene derecho a:</p>
            <ul>
              <li><strong>Acceso:</strong> Conocer qué datos tenemos sobre usted</li>
              <li><strong>Rectificación:</strong> Corregir datos inexactos</li>
              <li><strong>Supresión:</strong> Solicitar la eliminación de sus datos</li>
              <li><strong>Limitación:</strong> Restringir el tratamiento</li>
              <li><strong>Portabilidad:</strong> Recibir sus datos en formato estructurado</li>
              <li><strong>Oposición:</strong> Oponerse al tratamiento por interés legítimo</li>
              <li><strong>Revocación:</strong> Retirar el consentimiento en cualquier momento</li>
            </ul>

            <h3>8.1 Ejercicio de Derechos</h3>
            <p>
              Para ejercer sus derechos, puede contactarnos en:
            </p>
            <ul>
              <li>Email: info@custodia360.es</li>
              <li>Incluyendo una copia de su documento de identidad</li>
              <li>Especificando claramente el derecho que desea ejercer</li>
            </ul>

            <h2>9. Medidas de Seguridad</h2>
            <p>
              Implementamos medidas técnicas y organizativas apropiadas para proteger sus datos
              personales contra el acceso no autorizado, alteración, divulgación o destrucción.
            </p>

            <h2>10. Cookies</h2>
            <p>
              Utilizamos cookies técnicas necesarias para el funcionamiento del sitio web.
              Para más información, consulte nuestra <Link href="/cookies" className="text-orange-600 hover:underline">Política de Cookies</Link>.
            </p>

            <h2>11. Menores de Edad</h2>
            <p>
              Nuestros servicios están dirigidos a entidades, no a menores de edad directamente.
              No recopilamos intencionalmente datos personales de menores de 14 años.
            </p>

            <h2>12. Modificaciones</h2>
            <p>
              Podemos actualizar esta política de privacidad periódicamente. Le notificaremos
              de cualquier cambio significativo por email o mediante aviso en nuestro sitio web.
            </p>

            <h2>13. Autoridad de Control</h2>
            <p>
              Si considera que el tratamiento de sus datos no se ajusta a la normativa,
              puede presentar una reclamación ante la Agencia Española de Protección de Datos (AEPD):
            </p>
            <ul>
              <li>Web: www.aepd.es</li>
              <li>Teléfono: 901 100 099</li>
            </ul>

            <h2>14. Contacto</h2>
            <p>
              Para cualquier consulta sobre esta política de privacidad:
            </p>
            <ul>
              <li>Email: info@custodia360.es</li>
              <li>Teléfono: 678 771 198</li>
            </ul>

          </div>
        </div>
      </div>
    </div>
  )
}
