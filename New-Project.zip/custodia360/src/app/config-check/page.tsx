'use client'

import { useState, useEffect } from 'react'

export default function ConfigCheckPage() {
  const [config, setConfig] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkConfig()
  }, [])

  const checkConfig = async () => {
    try {
      const response = await fetch('/api/config-check')
      const data = await response.json()
      setConfig(data)
    } catch (error) {
      console.error('Error checking config:', error)
      setConfig({ error: 'Failed to check configuration' })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando configuración...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">🔧 Verificación de Configuración</h1>

          <div className="space-y-6">

            {/* RESEND Configuration */}
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">📧 Configuración de Email (Resend)</h2>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">RESEND_API_KEY:</span>
                  <span className={`px-3 py-1 rounded ${config?.resend?.configured ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {config?.resend?.configured ? '✅ Configurada' : '❌ No configurada'}
                  </span>
                </div>

                {config?.resend?.configured && (
                  <div className="text-sm text-gray-600">
                    API Key termina en: ...{config.resend.keyEnd}
                  </div>
                )}
              </div>

              {!config?.resend?.configured && (
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded">
                  <h4 className="font-medium text-yellow-800 mb-2">⚠️ Configuración requerida:</h4>
                  <ol className="text-sm text-yellow-700 space-y-1">
                    <li>1. Ve a <a href="https://resend.com" target="_blank" className="underline">resend.com</a></li>
                    <li>2. Crea una cuenta gratis (hasta 3,000 emails/mes)</li>
                    <li>3. Ve a API Keys y crea una nueva</li>
                    <li>4. Agrega RESEND_API_KEY=tu_api_key a las variables de entorno</li>
                    <li>5. Reinicia el servidor</li>
                  </ol>
                </div>
              )}
            </div>

            {/* Stripe Configuration */}
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">💳 Configuración de Stripe</h2>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">STRIPE_SECRET_KEY:</span>
                  <span className={`px-3 py-1 rounded ${config?.stripe?.configured ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {config?.stripe?.configured ? '✅ Configurada' : '❌ No configurada'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-medium">STRIPE_WEBHOOK_SECRET:</span>
                  <span className={`px-3 py-1 rounded ${config?.webhook?.configured ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {config?.webhook?.configured ? '✅ Configurada' : '⚠️ Opcional'}
                  </span>
                </div>
              </div>
            </div>

            {/* Test Buttons */}
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">🧪 Tests Disponibles</h2>

              <div className="space-y-3">
                <div>
                  <a
                    href="/test-email-simple"
                    className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    📧 Test Email Sistema
                  </a>
                  <p className="text-sm text-gray-600 mt-1">Prueba el envío de emails de pago</p>
                </div>

                <div>
                  <a
                    href="/test-email"
                    className="inline-block px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    📧 Test Email Original
                  </a>
                  <p className="text-sm text-gray-600 mt-1">Sistema de testing original</p>
                </div>
              </div>
            </div>

            {/* System Status */}
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">🚀 Estado del Sistema</h2>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded">
                  <div className="text-2xl font-bold text-gray-900">Email</div>
                  <div className={`text-sm ${config?.resend?.configured ? 'text-green-600' : 'text-red-600'}`}>
                    {config?.resend?.configured ? 'Funcional' : 'Necesita configuración'}
                  </div>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded">
                  <div className="text-2xl font-bold text-gray-900">Pagos</div>
                  <div className={`text-sm ${config?.stripe?.configured ? 'text-green-600' : 'text-red-600'}`}>
                    {config?.stripe?.configured ? 'Funcional' : 'Necesita configuración'}
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}
