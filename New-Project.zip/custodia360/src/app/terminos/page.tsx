import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft, Shield } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Términos y Condiciones - Custodia360',
  description: 'Términos y condiciones de uso de Custodia360. Protección infantil LOPIVI garantizada.',
}

export default function TerminosPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white border-b py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-4">
            <Link href="/" className="flex items-center text-orange-600 hover:text-orange-700 mr-4">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Volver al Inicio
            </Link>
          </div>
          <div className="flex items-center space-x-3">
            <Shield className="h-8 w-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-gray-900">Términos y Condiciones</h1>
          </div>
          <p className="text-gray-600 mt-2">Última actualización: 22 de julio de 2025</p>
        </div>
      </section>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-lg p-8">

          <div className="prose prose-lg max-w-none">

            <h2>1. Aceptación de los Términos</h2>
            <p>
              Al acceder y utilizar el sitio web de Custodia360 y contratar nuestros servicios,
              usted acepta estar legalmente vinculado por estos términos y condiciones.
              Si no está de acuerdo con alguno de estos términos, no debe utilizar nuestros servicios.
            </p>

            <h2>2. Descripción del Servicio</h2>
            <p>
              Custodia360 es una empresa especializada en el cumplimiento de la Ley Orgánica de
              Protección Integral de la Infancia y la Adolescencia frente a la Violencia (LOPIVI).
              Ofrecemos servicios de implementación, formación y mantenimiento de sistemas de
              protección infantil para entidades deportivas y de ocio.
            </p>

            <h3>2.1 Servicios Incluidos</h3>
            <ul>
              <li>Designación y formación de delegado de protección</li>
              <li>Desarrollo de plan de protección personalizado</li>
              <li>Creación de protocolos de actuación</li>
              <li>Formación del personal de la entidad</li>
              <li>Documentación completa y actualizada</li>
              <li>Mantenimiento y actualizaciones continuas</li>
            </ul>

            <h2>3. Condiciones de Contratación</h2>

            <h3>3.1 Precios y Facturación</h3>
            <p>
              Los precios de nuestros servicios se estructuran según el número de menores bajo
              la responsabilidad de la entidad. Los planes regulares se facturan en dos pagos:
            </p>
            <ul>
              <li>50% del importe total al contratar el servicio</li>
              <li>50% restante a los 6 meses mediante cargo automático</li>
              <li>Todos los precios incluyen IVA del 21%</li>
            </ul>

            <h3>3.2 Servicios de Pago Único</h3>
            <p>
              La custodia temporal y el kit de comunicación se facturan en su totalidad
              al momento de la contratación.
            </p>

            <h2>4. Obligaciones del Cliente</h2>
            <p>El cliente se compromete a:</p>
            <ul>
              <li>Proporcionar información veraz y actualizada sobre su entidad</li>
              <li>Facilitar el acceso necesario para la implementación del servicio</li>
              <li>Cumplir con las recomendaciones y protocolos establecidos</li>
              <li>Mantener actualizada la información de contacto y facturación</li>
              <li>Comunicar cualquier cambio en el número de menores o estructura de la entidad</li>
            </ul>

            <h2>5. Política de Cancelación y Reembolsos</h2>
            <p>
              Una vez iniciado el servicio de implementación, no se realizan reembolsos del
              primer pago. El cliente puede cancelar el servicio antes del segundo pago
              notificándolo por escrito con al menos 30 días de antelación.
            </p>

            <h2>6. Responsabilidades y Limitaciones</h2>
            <p>
              custodia360 proporciona herramientas, formación y protocolos para el cumplimiento
              de la LOPIVI. La responsabilidad final del cumplimiento normativo recae en la
              entidad contratante. Nuestro servicio no exime a la entidad de sus obligaciones legales.
            </p>

            <h2>7. Confidencialidad</h2>
            <p>
              Nos comprometemos a mantener la confidencialidad de toda la información proporcionada
              por nuestros clientes y a utilizarla únicamente para la prestación de nuestros servicios.
            </p>

            <h2>8. Propiedad Intelectual</h2>
            <p>
              Todos los materiales, documentos y contenidos proporcionados por custodia360
              son de nuestra propiedad intelectual. El cliente obtiene una licencia de uso
              para su aplicación interna, pero no puede redistribuir o comercializar dichos materiales.
            </p>

            <h2>9. Modificaciones</h2>
            <p>
              custodia360 se reserva el derecho de modificar estos términos en cualquier momento.
              Las modificaciones entrarán en vigor tras su publicación en nuestro sitio web.
            </p>

            <h2>10. Legislación Aplicable</h2>
            <p>
              Estos términos se rigen por la legislación española. Cualquier disputa será
              resuelta por los tribunales competentes de Barcelona, España.
            </p>

            <h2>11. Contacto</h2>
            <p>
              Para cualquier consulta sobre estos términos y condiciones, puede contactarnos en:
            </p>
            <ul>
              <li>Email: info@custodia360.es</li>
              <li>Teléfono: 678 771 198</li>
              <li>Dirección: Barcelona, España</li>
            </ul>

          </div>
        </div>
      </div>
    </div>
  )
}
