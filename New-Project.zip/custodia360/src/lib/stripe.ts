import Stripe from 'stripe'

// Server-side Stripe instance - REAL KEYS
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2022-11-15'
    })
  : null

// VAT rate for Spain
export const VAT_RATE = 0.21

// Plan definitions with real prices (without VAT)
export const CUSTODIA360_PLANS = {
  '1-50': {
    name: '1-50 menores',
    price: 18.44,
    maxMinors: 50,
    description: 'Plan básico para entidades pequeñas'
  },
  '51-200': {
    name: '51-200 menores',
    price: 48.94,
    maxMinors: 200,
    description: 'Plan intermedio para entidades medianas'
  },
  '201-500': {
    name: '201-500 menores',
    price: 107.44,
    maxMinors: 500,
    description: 'Plan avanzado para entidades grandes'
  },
  '501+': {
    name: '+501 menores',
    price: 250,
    maxMinors: 999999,
    description: 'Plan enterprise para entidades multideporte'
  },
  'temporal': {
    name: 'Custodia Temporal',
    price: 39,
    maxMinors: 999999,
    description: 'Cobertura temporal hasta 60 días'
  }
} as const

// Kit de Comunicación
export const KIT_COMUNICACION = {
  name: 'Kit de Comunicación LOPIVI',
  price: 30,
  description: 'Material completo para comunicar LOPIVI'
}

// Company data for invoicing
export const COMPANY_DATA = {
  name: process.env.COMPANY_NAME || 'custodia360',
  cif: process.env.COMPANY_CIF || 'B12345678',
  address: process.env.COMPANY_ADDRESS || 'Barcelona, España',
  email: process.env.COMPANY_EMAIL || 'info@custodia360.es',
  phone: process.env.COMPANY_PHONE || '678 771 198'
}

// CORRECTED: Extended customer data interface for intelligent form
export interface CustomerData {
  // Datos básicos
  entityName: string;
  entityCIF: string;
  entityType?: string;
  numMinors?: string;

  // Dirección completa
  addressLine1?: string;
  postalCode?: string;
  city?: string;
  province?: string;
  country?: string;
  entityAddress?: string; // Dirección completa como string

  // Contacto principal
  contactName: string;
  contactTitle?: string;
  contactEmail: string;
  contactPhone: string;

  // Contactos adicionales
  billingEmail?: string;
  delegateName?: string;
  delegateEmail?: string;
  delegatePhone?: string;

  // Preferencias
  preferredLanguage?: string;
  observations?: string;
}

// Types
export interface PaymentMetadata {
  plan: string
  planName: string
  includesKit: boolean | string
  paymentNumber: '1' | '2'
  customerId: string
  entityName: string
  entityCIF: string
}

// Utility functions
export function formatPrice(amount: number): string {
  return amount.toFixed(2).replace('.', ',') + '€'
}

export function calculateVAT(amount: number): number {
  return amount * VAT_RATE
}

export function getTotalWithVAT(amount: number): number {
  return amount + calculateVAT(amount)
}

export function centsToCurrency(cents: number): number {
  return cents / 100
}

export function currencyToCents(amount: number): number {
  return Math.round(amount * 100)
}

// Create Stripe Checkout Session - CORRECTED WITH PROPER TYPES
export async function createCheckoutSession(
  amount: number,
  metadata: PaymentMetadata,
  customerEmail: string,
  currentDomain?: string,
  customerData?: CustomerData // CORRECTED: Use the proper interface
): Promise<Stripe.Checkout.Session> {
  if (!stripe) {
    throw new Error('Stripe not initialized. Check STRIPE_SECRET_KEY environment variable.')
  }

  const totalWithVAT = getTotalWithVAT(amount)
  const amountInCents = currencyToCents(totalWithVAT)

  // CORRECTED: Build complete address string if needed
  const entityAddress = customerData?.entityAddress ||
    `${customerData?.addressLine1 || ''}, ${customerData?.postalCode || ''} ${customerData?.city || ''}, ${customerData?.province || ''}`.trim()

  // Convert boolean to string for Stripe metadata - DATOS COMPLETOS PARA AUTOMATIZACIÓN
  const stripeMetadata = {
    ...metadata,
    includesKit: metadata.includesKit.toString(),
    originalAmount: amount.toString(),
    vatAmount: calculateVAT(amount).toString(),
    totalWithVAT: totalWithVAT.toString(),
    companyName: COMPANY_DATA.name,
    companyCIF: COMPANY_DATA.cif,

    // Datos básicos de la entidad
    entityType: customerData?.entityType || '',
    numMinors: customerData?.numMinors || '',

    // Dirección fiscal completa (para facturación AEAT)
    addressLine1: customerData?.addressLine1 || '',
    postalCode: customerData?.postalCode || '',
    city: customerData?.city || '',
    province: customerData?.province || '',
    country: customerData?.country || 'España',

    // Contacto principal
    contactName: customerData?.contactName || metadata.entityName,
    contactTitle: customerData?.contactTitle || '',
    contactEmail: customerEmail,
    contactPhone: customerData?.contactPhone || '',

    // Contactos adicionales
    billingEmail: customerData?.billingEmail || customerEmail,
    delegateName: customerData?.delegateName || '',
    delegateEmail: customerData?.delegateEmail || '',
    delegatePhone: customerData?.delegatePhone || '',

    // Preferencias
    preferredLanguage: customerData?.preferredLanguage || 'es',
    observations: customerData?.observations || ''
  }

  // CORREGIDO: Usar dominio del cliente o fallback
  const domain = currentDomain || process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

  console.log('🔗 Creating Stripe session with domain:', domain)
  console.log('🌍 Environment check:', {
    NODE_ENV: process.env.NODE_ENV,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    currentDomain,
    finalDomain: domain
  })

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'eur',
          product_data: {
            name: `custodia360 - ${metadata.planName}`,
            description: `Pago ${metadata.paymentNumber} - Protección LOPIVI`,
          },
          unit_amount: amountInCents,
        },
        quantity: 1,
      },
    ],
    mode: 'payment',
    customer_email: customerEmail,
    // ARREGLADO: Agregar información del cliente para evitar teléfono incorrecto
    customer_creation: 'always',
    phone_number_collection: {
      enabled: false, // Deshabilitamos la colección de teléfono de Stripe para evitar conflictos
    },
    success_url: `${domain}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${domain}/planes`,
    metadata: stripeMetadata,
    billing_address_collection: 'required',
    payment_intent_data: {
      description: `custodia360 - ${metadata.planName} - Pago ${metadata.paymentNumber}`,
      statement_descriptor_suffix: 'custodia360',
    },
    // ARREGLADO: Configuración más simple para evitar errores
    allow_promotion_codes: false,
    automatic_tax: {
      enabled: false,
    },
  })

  console.log('✅ Stripe session created:', {
    id: session.id,
    url: session.url,
    success_url: session.success_url,
    cancel_url: session.cancel_url
  })

  return session
}

// Legacy function for compatibility - now creates checkout session
export async function createPaymentIntent(
  amount: number,
  metadata: PaymentMetadata,
  currentDomain?: string
): Promise<{ client_secret: string; checkout_url: string }> {
  const session = await createCheckoutSession(amount, metadata, metadata.customerId, currentDomain)

  return {
    client_secret: session.id,
    checkout_url: session.url || ''
  }
}

// Get plan by key
export function getPlanByKey(planKey: string) {
  return CUSTODIA360_PLANS[planKey as keyof typeof CUSTODIA360_PLANS]
}

// Validate plan exists
export function isValidPlan(planKey: string): boolean {
  return planKey in CUSTODIA360_PLANS
}

export default stripe
