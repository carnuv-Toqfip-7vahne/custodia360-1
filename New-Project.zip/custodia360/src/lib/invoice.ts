import jsPDF from 'jspdf'

export interface InvoiceData {
  sessionId: string
  customerName: string
  customerCIF: string
  customerEmail: string
  customerAddress?: string
  planName: string
  planPrice: number
  kitIncluded: boolean
  kitPrice: number
  subtotal: number
  vatAmount: number
  total: number
  paymentDate: Date
  invoiceNumber: string
}

export const generateInvoicePDF = (invoiceData: InvoiceData): void => {
  // Create new PDF document in A4 format
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  })

  // Page dimensions
  const pageWidth = 210
  const pageHeight = 297
  const margin = 20

  // Colors (custodia360 brand)
  const primaryColor = '#EA5A27' // Orange
  const darkColor = '#1F2937'
  const grayColor = '#6B7280'
  const lightGrayColor = '#F3F4F6'

  // Fonts
  doc.setFont('helvetica')

  // Header with logo and company info
  doc.setFillColor(primaryColor)
  doc.rect(0, 0, pageWidth, 30, 'F')

  // Company logo/name
  doc.setTextColor(255, 255, 255)
  doc.setFontSize(24)
  doc.setFont('helvetica', 'bold')
  doc.text('custodia360', margin, 20)

  // Invoice title
  doc.setTextColor(darkColor)
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text('FACTURA', margin, 50)

  // Invoice details box
  doc.setFillColor(lightGrayColor)
  doc.rect(margin, 60, pageWidth - 2 * margin, 30, 'F')
  doc.setDrawColor(grayColor)
  doc.rect(margin, 60, pageWidth - 2 * margin, 30, 'S')

  // Invoice info
  doc.setTextColor(darkColor)
  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')

  doc.text(`Número de factura: INV-${invoiceData.invoiceNumber}`, margin + 5, 70)
  doc.text(`Fecha: ${invoiceData.paymentDate.toLocaleDateString('es-ES')}`, margin + 5, 77)
  doc.text(`ID de transacción: ${invoiceData.sessionId.substring(0, 20)}...`, margin + 5, 84)

  // Company details
  doc.setFontSize(12)
  doc.setFont('helvetica', 'bold')
  doc.text('DATOS DEL PROVEEDOR:', margin, 110)

  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')
  doc.text('custodia360', margin, 120)
  doc.text('CIF: B12345678', margin, 127)
  doc.text('Barcelona, España', margin, 134)
  doc.text('Teléfono: 678 771 198', margin, 141)
  doc.text('Email: info@custodia360.es', margin, 148)

  // Customer details
  doc.setFontSize(12)
  doc.setFont('helvetica', 'bold')
  doc.text('DATOS DEL CLIENTE:', 110, 110)

  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')
  doc.text(invoiceData.customerName || 'Cliente', 110, 120)
  doc.text(`CIF: ${invoiceData.customerCIF || 'No especificado'}`, 110, 127)
  doc.text(`Email: ${invoiceData.customerEmail || 'No especificado'}`, 110, 134)

  // Format address properly (split if too long)
  if (invoiceData.customerAddress) {
    const address = invoiceData.customerAddress
    if (address.length > 35) {
      // Split long addresses into multiple lines
      const words = address.split(' ')
      let line1 = ''
      let line2 = ''
      let currentLine = 1

      for (const word of words) {
        if (currentLine === 1 && (line1 + word).length < 35) {
          line1 += (line1 ? ' ' : '') + word
        } else {
          currentLine = 2
          line2 += (line2 ? ' ' : '') + word
        }
      }

      doc.text(line1, 110, 141)
      if (line2) {
        doc.text(line2, 110, 148)
      }
    } else {
      doc.text(address, 110, 141)
    }
  }

  // Services table header
  const tableTop = 170
  doc.setFillColor(primaryColor)
  doc.rect(margin, tableTop, pageWidth - 2 * margin, 12, 'F')

  doc.setTextColor(255, 255, 255)
  doc.setFontSize(10)
  doc.setFont('helvetica', 'bold')
  doc.text('DESCRIPCIÓN', margin + 5, tableTop + 8)
  doc.text('PRECIO', 120, tableTop + 8)
  doc.text('IVA', 150, tableTop + 8)
  doc.text('TOTAL', 170, tableTop + 8)

  // Services table content
  let currentY = tableTop + 20
  doc.setTextColor(darkColor)
  doc.setFont('helvetica', 'normal')

  // Calculate properly
  let lineSubtotal = 0
  let lineVatTotal = 0

  // Plan service
  const planPriceWithoutVat = invoiceData.planPrice
  const planVat = planPriceWithoutVat * 0.21
  const planTotalWithVat = planPriceWithoutVat + planVat

  doc.text(`Plan LOPIVI: ${invoiceData.planName}`, margin + 5, currentY)
  doc.text(`${planPriceWithoutVat.toFixed(2)}€`, 120, currentY)
  doc.text(`${planVat.toFixed(2)}€`, 150, currentY)
  doc.text(`${planTotalWithVat.toFixed(2)}€`, 170, currentY)

  lineSubtotal += planPriceWithoutVat
  lineVatTotal += planVat
  currentY += 8

  // Kit if included
  if (invoiceData.kitIncluded) {
    const kitPriceWithoutVat = invoiceData.kitPrice
    const kitVat = kitPriceWithoutVat * 0.21
    const kitTotalWithVat = kitPriceWithoutVat + kitVat

    doc.text('Kit de Comunicación LOPIVI', margin + 5, currentY)
    doc.text(`${kitPriceWithoutVat.toFixed(2)}€`, 120, currentY)
    doc.text(`${kitVat.toFixed(2)}€`, 150, currentY)
    doc.text(`${kitTotalWithVat.toFixed(2)}€`, 170, currentY)

    lineSubtotal += kitPriceWithoutVat
    lineVatTotal += kitVat
    currentY += 8
  }

  // Table border
  doc.setDrawColor(grayColor)
  doc.rect(margin, tableTop, pageWidth - 2 * margin, currentY - tableTop + 8, 'S')

  // Calculate final totals
  const finalSubtotal = lineSubtotal
  const finalVat = lineVatTotal
  const finalTotal = finalSubtotal + finalVat

  // Totals section
  currentY += 20
  doc.setFillColor(lightGrayColor)
  doc.rect(120, currentY, pageWidth - 120 - margin, 30, 'F')
  doc.setDrawColor(grayColor)
  doc.rect(120, currentY, pageWidth - 120 - margin, 30, 'S')

  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')
  doc.text(`Subtotal: ${finalSubtotal.toFixed(2)}€`, 125, currentY + 8)
  doc.text(`IVA (21%): ${finalVat.toFixed(2)}€`, 125, currentY + 16)

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.text(`TOTAL: ${finalTotal.toFixed(2)}€`, 125, currentY + 24)

  // Payment information
  currentY += 50
  doc.setFillColor(primaryColor)
  doc.rect(margin, currentY, pageWidth - 2 * margin, 8, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFontSize(11)
  doc.setFont('helvetica', 'bold')
  doc.text('INFORMACIÓN DE PAGO', margin + 5, currentY + 6)

  currentY += 20
  doc.setTextColor(darkColor)
  doc.setFontSize(9)
  doc.setFont('helvetica', 'normal')
  doc.text('✅ Pago procesado con éxito por Stripe', margin, currentY)
  doc.text(`📅 Fecha de pago: ${invoiceData.paymentDate.toLocaleDateString('es-ES')}`, margin, currentY + 7)
  doc.text('🔒 Transacción segura y certificada', margin, currentY + 14)

  // Next payment reminder - CORRECTED: Show correct amount for second payment
  const nextPaymentDate = new Date(invoiceData.paymentDate)
  nextPaymentDate.setMonth(nextPaymentDate.getMonth() + 6)

  // Calculate second payment amount (50% of plan only, no kit)
  const secondPaymentBase = invoiceData.planPrice  // Same as first payment base
  const secondPaymentVat = secondPaymentBase * 0.21
  const secondPaymentTotal = secondPaymentBase + secondPaymentVat

  currentY += 25
  doc.setFillColor('#FEF3C7') // Yellow background
  doc.rect(margin, currentY, pageWidth - 2 * margin, 20, 'F')
  doc.setDrawColor('#F59E0B')
  doc.rect(margin, currentY, pageWidth - 2 * margin, 20, 'S')

  doc.setTextColor('#92400E')
  doc.setFontSize(10)
  doc.setFont('helvetica', 'bold')
  doc.text('📅 PRÓXIMO PAGO AUTOMÁTICO:', margin + 5, currentY + 8)
  doc.setFont('helvetica', 'normal')
  doc.text(`${nextPaymentDate.toLocaleDateString('es-ES')} - ${secondPaymentTotal.toFixed(2)}€`, margin + 5, currentY + 15)

  // Footer
  const footerY = pageHeight - 30
  doc.setFillColor(darkColor)
  doc.rect(0, footerY, pageWidth, 30, 'F')

  doc.setTextColor(255, 255, 255)
  doc.setFontSize(9)
  doc.setFont('helvetica', 'normal')
  doc.text('Gracias por confiar en custodia360 para la protección de los menores', margin, footerY + 10)
  doc.text('Tu implementación LOPIVI comenzará en las próximas 24 horas', margin, footerY + 17)
  doc.text('© 2025 custodia360 - Protección infantil garantizada', margin, footerY + 24)

  // Generate filename
  const fileName = `factura-custodia360-${invoiceData.invoiceNumber}.pdf`

  // Download the PDF
  doc.save(fileName)
}

// Utility function to generate invoice number
export const generateInvoiceNumber = (sessionId: string): string => {
  const date = new Date()
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const shortSessionId = sessionId.substring(0, 8).toUpperCase()
  return `${year}${month}-${shortSessionId}`
}
