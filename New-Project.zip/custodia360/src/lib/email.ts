import { Resend } from 'resend'

// Initialize Resend with API key
const resend = new Resend(process.env.RESEND_API_KEY)

export interface CustomerData {
  nombre_entidad: string
  cif: string
  responsable: string
  email: string
  telefono: string
  direccion: string
}

export interface OrderData {
  sessionId: string
  planName: string
  amount: number
  includesKit: boolean
  paymentDate: Date
  invoiceUrl?: string
}

// Utility functions
export function formatPrice(amount: number): string {
  return amount.toFixed(2).replace('.', ',') + '€'
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString('es-ES')
}

// Email 1: Confirmación de Pago (inmediato) - SIMPLIFICADO
export const sendPaymentConfirmation = async (
  customerData: CustomerData,
  orderData: OrderData
) => {
  try {
    console.log('📧 Enviando confirmación de pago a:', customerData.email)
    console.log('📧 Resend API Key present:', !!process.env.RESEND_API_KEY)

    // Simple HTML email without complex templates
    const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Pago Confirmado - custodia360</title>
    </head>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #f97316; color: white; padding: 20px; text-align: center; border-radius: 8px;">
            <h1>🛡️ custodia360</h1>
            <h2>¡Pago Confirmado!</h2>
        </div>

        <div style="padding: 20px; background-color: #f9f9f9; margin: 20px 0; border-radius: 8px;">
            <h3>Hola ${customerData.responsable},</h3>
            <p>Tu pago de <strong>${orderData.amount.toFixed(2)}€</strong> para <strong>${orderData.planName}</strong> ha sido procesado exitosamente.</p>

            <h4>Detalles del pedido:</h4>
            <ul>
                <li><strong>Entidad:</strong> ${customerData.nombre_entidad}</li>
                <li><strong>Plan:</strong> ${orderData.planName}</li>
                <li><strong>Importe:</strong> ${orderData.amount.toFixed(2)}€</li>
                <li><strong>Fecha:</strong> ${new Date().toLocaleDateString('es-ES')}</li>
                <li><strong>ID Transacción:</strong> ${orderData.sessionId}</li>
            </ul>

            <p><strong>¿Qué ocurre ahora?</strong></p>
            <p>Nuestro equipo comenzará la implementación de tu protección LOPIVI en las próximas 24 horas. Recibirás un email de bienvenida con los siguientes pasos.</p>
        </div>

        <div style="text-align: center; padding: 20px;">
            <p>¿Tienes dudas? Contacta con nosotros:</p>
            <p>📞 678 771 198 | ✉️ info@custodia360.es</p>
        </div>
    </body>
    </html>
    `

    console.log('📧 Enviando email HTML simple...')

    const result = await resend.emails.send({
      from: 'custodia360 <onboarding@resend.dev>',
      to: customerData.email,
      subject: '✅ Pago confirmado - Tu protección LOPIVI ya está en marcha',
      html: emailHtml,
      cc: 'rsune@teamsml.com',
    })

    console.log('✅ Email confirmación enviado:', result.data?.id)
    console.log('📧 Resend response:', result)

    // Por ahora no programamos email de bienvenida para simplificar debugging
    // await scheduleWelcomeEmail(customerData, orderData)

    return result
  } catch (error) {
    console.error('❌ Error enviando confirmación:', error)
    throw error
  }
}

// Email 2: Bienvenida + Próximos Pasos (+5 minutos)
export const sendWelcomeEmail = async (
  customerData: CustomerData,
  orderData: OrderData
) => {
  try {
    console.log('👋 Enviando email de bienvenida a:', customerData.email)

    const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Bienvenido a custodia360</title>
    </head>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #16a34a; color: white; padding: 20px; text-align: center; border-radius: 8px;">
            <h1>🛡️ custodia360</h1>
            <h2>¡Bienvenido a la protección LOPIVI!</h2>
        </div>

        <div style="padding: 20px; background-color: #f0f9ff; margin: 20px 0; border-radius: 8px;">
            <h3>Hola ${customerData.responsable},</h3>
            <p>¡Ya formas parte de la protección automatizada de custodia360! Tu entidad <strong>${customerData.nombre_entidad}</strong> estará protegida en 24 horas.</p>

            <h4>📋 Próximos pasos:</h4>
            <ol>
                <li><strong>Designación de Delegado</strong> - Te contactaremos para asignar tu delegado de protección</li>
                <li><strong>Plan personalizado</strong> - Crearemos tu plan específico</li>
                <li><strong>Protocolos</strong> - Implementaremos todos los protocolos necesarios</li>
                <li><strong>Formación</strong> - Formaremos a tu personal</li>
                <li><strong>Documentación</strong> - Entregaremos toda la documentación LOPIVI</li>
            </ol>

            <p><strong>📞 ¿Necesitas ayuda inmediata?</strong></p>
            <p>Contacta con nuestro equipo:</p>
            <p>📞 678 771 198 | ✉️ info@custodia360.es</p>
        </div>
    </body>
    </html>
    `

    const result = await resend.emails.send({
      from: 'custodia360 <onboarding@resend.dev>',
      to: customerData.email,
      subject: '👋 Bienvenido a custodia360 - Próximos pasos para tu LOPIVI',
      html: emailHtml,
    })

    console.log('✅ Email bienvenida enviado:', result.data?.id)
    return result
  } catch (error) {
    console.error('❌ Error enviando bienvenida:', error)
    throw error
  }
}

// Programar email de bienvenida (simular delay)
const scheduleWelcomeEmail = async (
  customerData: CustomerData,
  orderData: OrderData
) => {
  try {
    console.log('⏰ Programando email de bienvenida en 5 minutos...')

    // En desarrollo: enviar inmediatamente
    // En producción: usar un job scheduler real
    if (process.env.NODE_ENV === 'development') {
      console.log('🔧 Modo desarrollo: enviando bienvenida inmediatamente')
      setTimeout(() => {
        sendWelcomeEmail(customerData, orderData)
      }, 5000) // 5 segundos en desarrollo
    } else {
      // TODO: Implementar con cron job o queue system
      setTimeout(() => {
        sendWelcomeEmail(customerData, orderData)
      }, 5 * 60 * 1000) // 5 minutos en producción
    }
  } catch (error) {
    console.error('❌ Error programando bienvenida:', error)
  }
}

// Functions already defined above - removed duplicates
