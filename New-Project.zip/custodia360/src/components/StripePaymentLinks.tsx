'use client'

import React from 'react'
import { CreditCard, ExternalLink } from 'lucide-react'

interface FormData {
  nombre_entidad: string;
  email: string;
  telefono?: string;
  cif?: string;
}

interface StripePaymentLinksProps {
  formData: FormData;
  selectedPlan: string;
  includesKit: boolean;
}

// Direct Stripe Payment Links - Much simpler and more reliable
const STRIPE_PAYMENT_LINKS = {
  '1-50': 'https://buy.stripe.com/test_3cs28q8Kq0YL0Ug145',
  '51-200': 'https://buy.stripe.com/test_4gw6oO5yeh1ngFO6oq',
  '201-500': 'https://buy.stripe.com/test_6oE5ku6Ci3YX4f6001',
  '501+': 'https://buy.stripe.com/test_9AQ3cs9Os1YPbvCeV0',
  'temporal': 'https://buy.stripe.com/test_fZe9AW8Kq8lu7oe3ch'
}

export default function StripePaymentLinks({ formData, selectedPlan, includesKit }: StripePaymentLinksProps) {

  const getPaymentLink = () => {
    const baseLink = STRIPE_PAYMENT_LINKS[selectedPlan as keyof typeof STRIPE_PAYMENT_LINKS] || STRIPE_PAYMENT_LINKS['51-200']

    // Add customer info as URL parameters
    const params = new URLSearchParams({
      'prefilled_email': formData.email,
      'client_reference_id': `${selectedPlan}_${formData.nombre_entidad}`,
      'success_url': `${window.location.origin}/contratacion/success?plan=${selectedPlan}&entity=${encodeURIComponent(formData.nombre_entidad)}`,
      'cancel_url': `${window.location.origin}/planes`
    })

    return `${baseLink}?${params.toString()}`
  }

  const handleDirectPayment = () => {
    // Validate required data
    if (!formData.nombre_entidad || !formData.email) {
      alert('Por favor completa los datos básicos (nombre de entidad y email)')
      return
    }

    console.log('🚀 Redirigiendo a Stripe Payment Link directo...')

    // Show user what's happening
    alert(`✅ Te llevaremos directamente a Stripe.\n\nCompletarás el pago de forma segura en Stripe.\nDespués volverás automáticamente a Custodia360.`)

    // Direct redirect to Stripe Payment Link
    window.location.href = getPaymentLink()
  }

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-semibold mb-2">Resumen del pago:</h4>
        <p><strong>Entidad:</strong> {formData.nombre_entidad}</p>
        <p><strong>Plan:</strong> {selectedPlan} menores</p>
        <p><strong>Email:</strong> {formData.email}</p>
        {includesKit && <p><strong>Kit incluido:</strong> Sí (+30€)</p>}
      </div>

      {/* Direct Payment Button */}
      <button
        type="button"
        onClick={handleDirectPayment}
        className="w-full bg-orange-600 text-white py-4 px-6 rounded-lg hover:bg-orange-700 transition-colors font-bold text-lg flex items-center justify-center"
      >
        <CreditCard className="h-5 w-5 mr-2" />
        💳 Pagar con Stripe
        <ExternalLink className="h-4 w-4 ml-2" />
      </button>

      {/* How it works */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h5 className="font-medium text-green-800 mb-2">🔒 Proceso ultra simple:</h5>
        <div className="text-sm text-green-700 space-y-1">
          <p>1. Haces click en "Pagar con Stripe"</p>
          <p>2. Te redirigimos <strong>directamente a Stripe</strong></p>
          <p>3. Introduces tus datos de tarjeta en <strong>Stripe</strong></p>
          <p>4. Stripe te devuelve a <strong>Custodia360</strong> con confirmación</p>
          <p>5. ¡Listo! Sin complicaciones</p>
        </div>
      </div>

      {/* Test cards info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800 font-medium">💳 Tarjetas de prueba:</p>
        <p className="text-blue-700 text-sm mt-1">
          <strong>Pago exitoso:</strong> 4242 4242 4242 4242<br/>
          <strong>Fecha:</strong> Cualquier fecha futura<br/>
          <strong>CVC:</strong> 123
        </p>
      </div>
    </div>
  )
}
