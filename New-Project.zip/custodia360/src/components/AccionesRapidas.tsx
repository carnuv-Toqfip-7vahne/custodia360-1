'use client'

import React, { useState } from 'react'
import { AlertTriangle, Shield, Phone, FileText, Users, Lock, Clock, CheckCircle } from 'lucide-react'

interface AccionesRapidasProps {
  delegadoNombre?: string
  delegadoTelefono?: string
  delegadoEmail?: string
}

export default function AccionesRapidas({
  delegadoNombre = "Juan Pérez",
  delegadoTelefono = "678 771 198",
  delegadoEmail = "delegado@tuentidad.es"
}: AccionesRapidasProps) {
  const [isOpen, setIsOpen] = useState(false)

  const pasos = [
    {
      numero: 1,
      icono: <Clock className="h-6 w-6" />,
      titulo: "ACTÚA INMEDIATAMENTE",
      descripcion: "No esperes, no dudes. Cada segundo cuenta.",
      color: "bg-red-500 text-white",
      detalles: "La respuesta inmediata es crítica. No pierdas tiempo consultando con otros.",
      urgencia: "CRÍTICO"
    },
    {
      numero: 2,
      icono: <Shield className="h-6 w-6" />,
      titulo: "PROTEGE AL MENOR",
      descripcion: "Separa inmediatamente del presunto agresor.",
      color: "bg-orange-500 text-white",
      detalles: "Garantiza la seguridad física inmediata del menor. No lo dejes solo.",
      urgencia: "URGENTE"
    },
    {
      numero: 3,
      icono: <Phone className="h-6 w-6" />,
      titulo: "LLAMA AL DELEGADO",
      descripcion: `${delegadoNombre} - ${delegadoTelefono}`,
      color: "bg-blue-500 text-white",
      detalles: "Informa inmediatamente al delegado de protección. Es obligatorio por LOPIVI.",
      urgencia: "INMEDIATO"
    },
    {
      numero: 4,
      icono: <FileText className="h-6 w-6" />,
      titulo: "DOCUMENTA TODO",
      descripcion: "Fecha, hora, testigos, hechos exactos.",
      color: "bg-purple-500 text-white",
      detalles: "Registra todos los detalles mientras están frescos en tu memoria.",
      urgencia: "IMPORTANTE"
    },
    {
      numero: 5,
      icono: <Users className="h-6 w-6" />,
      titulo: "COMUNICA AUTORIDADES",
      descripcion: "Si es grave, contactar policía (091) o guardia civil (062).",
      color: "bg-green-600 text-white",
      detalles: "En casos graves, contacta directamente con las fuerzas de seguridad.",
      urgencia: "SI PROCEDE"
    },
    {
      numero: 6,
      icono: <Lock className="h-6 w-6" />,
      titulo: "CONFIDENCIALIDAD",
      descripcion: "Solo informa a personas estrictamente necesarias.",
      color: "bg-gray-600 text-white",
      detalles: "Protege la privacidad del menor. Solo personal autorizado debe conocer los hechos.",
      urgencia: "OBLIGATORIO"
    }
  ]

  return (
    <div className="w-full">
      {/* Botón principal */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-lg shadow-lg transition-colors border-l-4 border-red-800 flex items-center justify-between"
      >
        <div className="flex items-center">
          <AlertTriangle className="h-6 w-6 mr-3 animate-pulse" />
          <div className="text-left">
            <div className="text-lg font-bold">🚨 ¿Caso de Abuso/Violencia?</div>
            <div className="text-sm opacity-90">Protocolo de Actuación Inmediata</div>
          </div>
        </div>
        <div className="text-2xl">{isOpen ? '−' : '+'}</div>
      </button>

      {/* Panel expandido */}
      {isOpen && (
        <div className="mt-4 bg-white border-2 border-red-200 rounded-lg shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-red-600 text-white p-4">
            <h3 className="text-xl font-bold flex items-center">
              <AlertTriangle className="h-6 w-6 mr-2" />
              PROTOCOLO DE EMERGENCIA LOPIVI
            </h3>
            <p className="text-red-100 mt-1">Sigue estos pasos en orden estricto</p>
          </div>

          {/* Pasos */}
          <div className="p-6">
            <div className="space-y-4">
              {pasos.map((paso, index) => (
                <div key={index} className="flex items-start border-l-4 border-gray-200 pl-4 py-3">
                  <div className={`${paso.color} rounded-full p-3 mr-4 flex-shrink-0`}>
                    <span className="text-lg font-bold">{paso.numero}</span>
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <div className={`${paso.color} rounded-full p-1 mr-2`}>
                        {paso.icono}
                      </div>
                      <h4 className="text-lg font-bold text-gray-900">{paso.titulo}</h4>
                      <span className={`ml-auto px-2 py-1 rounded text-xs font-bold ${
                        paso.urgencia === 'CRÍTICO' ? 'bg-red-100 text-red-800' :
                        paso.urgencia === 'URGENTE' ? 'bg-orange-100 text-orange-800' :
                        paso.urgencia === 'INMEDIATO' ? 'bg-blue-100 text-blue-800' :
                        paso.urgencia === 'IMPORTANTE' ? 'bg-purple-100 text-purple-800' :
                        paso.urgencia === 'SI PROCEDE' ? 'bg-green-100 text-green-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {paso.urgencia}
                      </span>
                    </div>
                    <p className="text-gray-700 font-medium mb-1">{paso.descripcion}</p>
                    <p className="text-gray-600 text-sm">{paso.detalles}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Contactos de emergencia */}
            <div className="mt-6 bg-blue-50 rounded-lg p-4 border-2 border-blue-200">
              <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                CONTACTOS DE EMERGENCIA
              </h4>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="font-medium text-blue-800">Delegado de Protección:</div>
                  <div>{delegadoNombre}</div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    <a href={`tel:${delegadoTelefono}`} className="text-blue-600 hover:underline">
                      {delegadoTelefono}
                    </a>
                  </div>
                  <div className="text-blue-600">{delegadoEmail}</div>
                </div>
                <div>
                  <div className="font-medium text-blue-800">Emergencias:</div>
                  <div>• Policía: <strong>091</strong></div>
                  <div>• Guardia Civil: <strong>062</strong></div>
                  <div>• Teléfono ANAR: <strong>900 20 20 10</strong></div>
                </div>
              </div>
            </div>

            {/* Recordatorio legal */}
            <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2 mt-0.5" />
                <div>
                  <h5 className="font-bold text-yellow-800">RECORDATORIO LEGAL</h5>
                  <p className="text-yellow-700 text-sm mt-1">
                    Según la LOPIVI, cualquier adulto que observe una situación de riesgo tiene la
                    <strong> obligación legal de actuar</strong>. No actuar puede constituir un delito.
                  </p>
                </div>
              </div>
            </div>

            {/* Botón de confirmación */}
            <div className="mt-6 text-center">
              <button
                onClick={() => setIsOpen(false)}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg flex items-center mx-auto"
              >
                <CheckCircle className="h-5 w-5 mr-2" />
                PROTOCOLO ENTENDIDO
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
