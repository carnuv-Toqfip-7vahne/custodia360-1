'use client'

import { useState } from 'react'
import { MessageCircle, X, Send } from 'lucide-react'

export default function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)

  const suggestedQuestions = [
    "¿Cuánto cuesta implementar la LOPIVI?",
    "¿En cuánto tiempo se implementa?",
    "¿Qué incluye el delegado de protección?",
    "¿Necesito formación para mi personal?",
    "¿Cómo funciona el mantenimiento?",
    "¿Puedo solicitar una demo?"
  ]

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 z-50 bg-orange-600 text-white p-4 rounded-full shadow-lg hover:bg-orange-700 transition-colors"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <MessageCircle className="h-6 w-6" />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 z-50 w-80 bg-white rounded-lg shadow-xl border">

          {/* Chat Header */}
          <div className="bg-orange-600 text-white p-4 rounded-t-lg">
            <div className="flex items-center">
              <MessageCircle className="h-5 w-5 mr-2" />
              <span className="font-medium">¿En qué podemos ayudarte?</span>
            </div>
          </div>

          {/* Suggested Questions */}
          <div className="p-4 max-h-80 overflow-y-auto">
            <div className="space-y-2">
              {suggestedQuestions.map((question, index) => (
                <button
                  key={index}
                  className="w-full text-left p-3 bg-gray-50 hover:bg-orange-50 rounded-lg text-sm transition-colors"
                  onClick={() => {
                    // Simular redirección a contacto con la pregunta
                    window.location.href = `/contacto?question=${encodeURIComponent(question)}`
                  }}
                >
                  {question}
                </button>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t">
              <div className="text-sm text-gray-600 mb-3">
                O contacta directamente:
              </div>
              <div className="space-y-2 text-sm">
                <div>📞 <a href="tel:678771198" className="text-orange-600 hover:underline">678 771 198</a></div>
                <div>✉️ <a href="mailto:info@custodia360.es" className="text-orange-600 hover:underline">info@custodia360.es</a></div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="p-4 border-t bg-gray-50 rounded-b-lg">
            <div className="grid grid-cols-2 gap-2">
              <a
                href="/planes"
                className="text-center py-2 px-3 bg-orange-600 text-white rounded text-sm hover:bg-orange-700 transition-colors"
              >
                Ver Planes
              </a>
              <a
                href="/contacto"
                className="text-center py-2 px-3 bg-white border border-orange-600 text-orange-600 rounded text-sm hover:bg-orange-50 transition-colors"
              >
                Contactar
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
