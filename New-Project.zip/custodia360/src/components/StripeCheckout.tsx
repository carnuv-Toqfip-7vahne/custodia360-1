'use client'

import React, { useState } from 'react'
import { CreditCard, Loader2, AlertTriangle } from 'lucide-react'

interface FormData {
  nombre_entidad: string;
  email: string;
  telefono?: string;
  cif?: string;
  [key: string]: string | undefined;
}

interface DebugInfo {
  step: string;
  data?: Record<string, unknown>;
  status?: number;
  checkoutUrl?: string;
  sessionId?: string;
  error?: string;
}

interface StripeCheckoutProps {
  formData: FormData;
  selectedPlan: string;
  includesKit: boolean;
}

export default function StripeCheckout({ formData, selectedPlan, includesKit }: StripeCheckoutProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [debugInfo, setDebugInfo] = useState<DebugInfo | null>(null)

  const handleRealPayment = async () => {
    // Validate required data
    if (!formData.nombre_entidad || !formData.email) {
      alert('Por favor completa los datos básicos (nombre de entidad y email)')
      return
    }

    setIsLoading(true)
    setError(null)
    setDebugInfo(null)

    try {
      console.log('🚀 Iniciando pago REAL con Stripe...')

      const requestData = {
        plan: selectedPlan,
        includesKit,
        entityName: formData.nombre_entidad,
        entityCIF: formData.cif || 'G12345678',
        customerEmail: formData.email,
        contactName: formData.nombre_entidad,
        contactPhone: formData.telefono || '678123456',
        currentDomain: window.location.origin
      }

      console.log('📤 Enviando datos a Stripe API:', requestData)
      setDebugInfo({ step: 'Enviando datos a API...', data: requestData })

      // Call our simplified Stripe API
      const response = await fetch('/api/stripe/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      })

      console.log('📥 Respuesta del servidor:', response.status, response.statusText)
      setDebugInfo(prev => ({ ...prev, step: 'Procesando respuesta...', status: response.status }))

      const data = await response.json()
      console.log('📋 Datos recibidos:', data)

      if (!response.ok) {
        throw new Error(data.error || `Error ${response.status}: ${response.statusText}`)
      }

      if (!data.success || !data.checkoutUrl) {
        throw new Error('No se recibió URL de pago de Stripe')
      }

      console.log('✅ URL de Stripe recibida:', data.checkoutUrl)
      setDebugInfo(prev => ({
        ...prev,
        step: 'Redirigiendo a Stripe...',
        checkoutUrl: data.checkoutUrl,
        sessionId: data.sessionId
      }))

      // Show user what's happening
      alert(`✅ Redirigiendo a Stripe...\n\nTe llevaremos a Stripe para completar el pago de forma segura.\nDespués del pago, volverás automáticamente a Custodia360.`)

      // Redirect to REAL Stripe Checkout
      console.log('🔄 Redirigiendo a Stripe Checkout...')
      window.location.href = data.checkoutUrl

    } catch (err) {
      console.error('❌ Error en pago real:', err)
      const errorMessage = err instanceof Error ? err.message : 'Error de pago'
      setError(errorMessage)
      setDebugInfo(prev => ({ ...prev, step: 'ERROR', error: errorMessage }))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-semibold mb-2">Resumen del pago:</h4>
        <p><strong>Entidad:</strong> {formData.nombre_entidad}</p>
        <p><strong>Plan:</strong> {selectedPlan} menores</p>
        <p><strong>Email:</strong> {formData.email}</p>
        {includesKit && <p><strong>Kit incluido:</strong> Sí (+30€)</p>}
      </div>

      {/* Payment Button */}
      <button
        type="button"
        onClick={handleRealPayment}
        disabled={isLoading}
        className="w-full bg-orange-600 text-white py-4 px-6 rounded-lg hover:bg-orange-700 disabled:bg-gray-400 transition-colors font-bold text-lg flex items-center justify-center"
      >
        {isLoading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin mr-2" />
            {debugInfo?.step || 'Procesando...'}
          </>
        ) : (
          <>
            <CreditCard className="h-5 w-5 mr-2" />
            💳 Pagar con Stripe
          </>
        )}
      </button>

      {/* Debug Info - Visible to user */}
      {debugInfo && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h5 className="font-medium text-blue-800 mb-2">📊 Estado del proceso:</h5>
          <div className="text-sm text-blue-700 space-y-1">
            <p><strong>Paso actual:</strong> {debugInfo.step}</p>
            {debugInfo.status && <p><strong>Estado HTTP:</strong> {debugInfo.status}</p>}
            {debugInfo.sessionId && <p><strong>Session ID:</strong> {debugInfo.sessionId.substring(0, 20)}...</p>}
            {debugInfo.checkoutUrl && <p><strong>URL Stripe:</strong> ✅ Recibida</p>}
            {debugInfo.error && <p><strong>Error:</strong> {debugInfo.error}</p>}
          </div>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
            <div>
              <p className="text-red-800 font-medium">Error en el pago:</p>
              <p className="text-red-700 text-sm mt-1">{error}</p>
              <button
                onClick={() => {
                  setError(null)
                  setDebugInfo(null)
                }}
                className="text-red-600 underline mt-2 text-sm"
              >
                Reintentar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Info about Stripe */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h5 className="font-medium text-green-800 mb-2">🔒 Proceso de pago seguro:</h5>
        <div className="text-sm text-green-700 space-y-1">
          <p>1. Haces click en "Pagar con Stripe"</p>
          <p>2. Te redirigimos a <strong>Stripe</strong> (plataforma segura)</p>
          <p>3. Introduces tus datos de tarjeta en <strong>Stripe</strong></p>
          <p>4. Stripe procesa el pago y te devuelve a <strong>Custodia360</strong></p>
          <p>5. Ves la confirmación de pago exitoso</p>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800 font-medium">💳 Tarjetas de prueba Stripe:</p>
        <p className="text-blue-700 text-sm mt-1">
          <strong>Pago exitoso:</strong> 4242 4242 4242 4242<br/>
          <strong>Pago rechazado:</strong> 4000 0000 0000 0002<br/>
          <strong>Fecha:</strong> Cualquier fecha futura<br/>
          <strong>CVC:</strong> Cualquier 3 dígitos
        </p>
      </div>
    </div>
  )
}
