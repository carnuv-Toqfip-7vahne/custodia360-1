'use client'

import { useState, useEffect } from 'react'
import { EntityFormData, TIPOS_ENTIDAD, CARGOS_POR_TIPO } from '@/types/form-data'

interface SmartFormProps {
  onSubmit: (data: EntityFormData) => void
  initialData?: Partial<EntityFormData>
}

export default function SmartForm({ onSubmit, initialData }: SmartFormProps) {
  const [formData, setFormData] = useState<EntityFormData>({
    nombre_entidad: '',
    cif: '',
    tipo_entidad: '',
    num_menores: '',
    direccion_linea1: '',
    codigo_postal: '',
    ciudad: '',
    provincia: '',
    pais: 'España',
    responsable: '',
    cargo_responsable: '',
    email: '',
    telefono: '',
    idioma_preferido: 'es',
    ...initialData
  })

  const [showAdvanced, setShowAdvanced] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Cargos dinámicos según tipo de entidad
  const getAvailableCargos = () => {
    const tipo = formData.tipo_entidad as keyof typeof CARGOS_POR_TIPO
    return CARGOS_POR_TIPO[tipo] || CARGOS_POR_TIPO.default
  }

  // Autocompletar provincia según código postal
  const handleCodigoPostalChange = (cp: string) => {
    setFormData(prev => ({ ...prev, codigo_postal: cp }))

    // Autocompletado básico de provincias españolas
    const provinciaMap: Record<string, string> = {
      '01': 'Álava', '02': 'Albacete', '03': 'Alicante', '04': 'Almería',
      '28': 'Madrid', '08': 'Barcelona', '41': 'Sevilla', '46': 'Valencia',
      // ... más provincias según necesidad
    }

    const prefijo = cp.substring(0, 2)
    if (provinciaMap[prefijo]) {
      setFormData(prev => ({ ...prev, provincia: provinciaMap[prefijo] }))
    }
  }

  // Validación en tiempo real
  const validateField = (name: string, value: string) => {
    const newErrors = { ...errors }

    switch (name) {
      case 'cif':
        if (value && !/^[A-HJ-NP-SUVW][0-9]{7}[0-9A-J]$|^[0-9]{8}[A-Z]$/.test(value)) {
          newErrors.cif = 'CIF/NIF no válido'
        } else {
          delete newErrors.cif
        }
        break
      case 'codigo_postal':
        if (value && !/^[0-9]{5}$/.test(value)) {
          newErrors.codigo_postal = 'Código postal debe tener 5 dígitos'
        } else {
          delete newErrors.codigo_postal
        }
        break
      case 'telefono':
        if (value && !/^[6-9][0-9]{8}$/.test(value.replace(/\s/g, ''))) {
          newErrors.telefono = 'Teléfono no válido (ej: 678123456)'
        } else {
          delete newErrors.telefono
        }
        break
      case 'email':
        if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          newErrors.email = 'Email no válido'
        } else {
          delete newErrors.email
        }
        break
    }

    setErrors(newErrors)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validación final
    const requiredFields = [
      'nombre_entidad', 'cif', 'tipo_entidad', 'num_menores',
      'direccion_linea1', 'codigo_postal', 'ciudad', 'provincia',
      'responsable', 'cargo_responsable', 'email', 'telefono'
    ]

    const missingFields = requiredFields.filter(field =>
      !formData[field as keyof EntityFormData]
    )

    if (missingFields.length > 0 || Object.keys(errors).length > 0) {
      alert('Por favor completa todos los campos obligatorios correctamente')
      return
    }

    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">

      {/* DATOS BÁSICOS DE LA ENTIDAD */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📋 Datos de la Entidad</h3>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de la Entidad *
            </label>
            <input
              type="text"
              value={formData.nombre_entidad}
              onChange={(e) => setFormData(prev => ({ ...prev, nombre_entidad: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="Club Deportivo Ejemplo"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              CIF/NIF *
            </label>
            <input
              type="text"
              value={formData.cif}
              onChange={(e) => {
                const value = e.target.value.toUpperCase()
                setFormData(prev => ({ ...prev, cif: value }))
                validateField('cif', value)
              }}
              className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                errors.cif ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="G12345678"
              required
            />
            {errors.cif && <p className="text-red-500 text-xs mt-1">{errors.cif}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo de Entidad *
            </label>
            <select
              value={formData.tipo_entidad}
              onChange={(e) => setFormData(prev => ({ ...prev, tipo_entidad: e.target.value, cargo_responsable: '' }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              required
            >
              <option value="">Selecciona el tipo</option>
              {Object.entries(TIPOS_ENTIDAD).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Número de Menores *
            </label>
            <input
              type="number"
              value={formData.num_menores}
              onChange={(e) => setFormData(prev => ({ ...prev, num_menores: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="50"
              min="1"
              max="10000"
              required
            />
          </div>
        </div>
      </div>

      {/* DIRECCIÓN FISCAL */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">📍 Dirección Fiscal</h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Dirección *
            </label>
            <input
              type="text"
              value={formData.direccion_linea1}
              onChange={(e) => setFormData(prev => ({ ...prev, direccion_linea1: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="Calle Mayor 123, 2º A"
              required
            />
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código Postal *
              </label>
              <input
                type="text"
                value={formData.codigo_postal}
                onChange={(e) => {
                  const value = e.target.value
                  handleCodigoPostalChange(value)
                  validateField('codigo_postal', value)
                }}
                className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                  errors.codigo_postal ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="28001"
                maxLength={5}
                required
              />
              {errors.codigo_postal && <p className="text-red-500 text-xs mt-1">{errors.codigo_postal}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ciudad *
              </label>
              <input
                type="text"
                value={formData.ciudad}
                onChange={(e) => setFormData(prev => ({ ...prev, ciudad: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                placeholder="Madrid"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Provincia *
              </label>
              <input
                type="text"
                value={formData.provincia}
                onChange={(e) => setFormData(prev => ({ ...prev, provincia: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                placeholder="Madrid"
                required
              />
            </div>
          </div>
        </div>
      </div>

      {/* CONTACTO PRINCIPAL */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">👤 Responsable Principal</h3>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre del Responsable *
            </label>
            <input
              type="text"
              value={formData.responsable}
              onChange={(e) => setFormData(prev => ({ ...prev, responsable: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="Juan Pérez García"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cargo *
            </label>
            <select
              value={formData.cargo_responsable}
              onChange={(e) => setFormData(prev => ({ ...prev, cargo_responsable: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              required
            >
              <option value="">Selecciona el cargo</option>
              {getAvailableCargos().map(cargo => (
                <option key={cargo} value={cargo}>{cargo}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email *
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => {
                const value = e.target.value
                setFormData(prev => ({ ...prev, email: value }))
                validateField('email', value)
              }}
              className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                errors.email ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="contacto@entidad.com"
              required
            />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Teléfono *
            </label>
            <input
              type="tel"
              value={formData.telefono}
              onChange={(e) => {
                const value = e.target.value
                setFormData(prev => ({ ...prev, telefono: value }))
                validateField('telefono', value)
              }}
              className={`w-full px-3 py-2 border rounded-md focus:ring-orange-500 focus:border-orange-500 ${
                errors.telefono ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="678 123 456"
              required
            />
            {errors.telefono && <p className="text-red-500 text-xs mt-1">{errors.telefono}</p>}
          </div>
        </div>
      </div>

      {/* CAMPOS OPCIONALES */}
      <div className="bg-blue-50 rounded-lg p-4">
        <button
          type="button"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center text-blue-700 hover:text-blue-800 font-medium"
        >
          <span>{showAdvanced ? '▼' : '▶'}</span>
          <span className="ml-2">Configuración Adicional (Opcional)</span>
        </button>

        {showAdvanced && (
          <div className="mt-4 space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Delegado de Protección (si ya designado)
                </label>
                <input
                  type="text"
                  value={formData.delegado_designado || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, delegado_designado: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                  placeholder="María González"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email del Delegado
                </label>
                <input
                  type="email"
                  value={formData.email_delegado || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, email_delegado: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                  placeholder="delegado@entidad.com"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SUBMIT BUTTON */}
      <div className="text-center">
        <button
          type="submit"
          disabled={Object.keys(errors).length > 0}
          className="w-full max-w-md bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors font-medium text-lg"
        >
          📋 Continuar al Pago
        </button>
      </div>
    </form>
  )
}
