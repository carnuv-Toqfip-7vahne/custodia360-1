import React from 'react'
import {
  Html,
  Head,
  Body,
  Container,
  Section,
  Text,
  Heading,
  Hr,
  Button,
  Img,
} from '@react-email/components'
import { CustomerData, OrderData } from '@/lib/email'

interface WelcomeProps {
  customerData: CustomerData
  orderData: OrderData
}

export default function WelcomeTemplate({
  customerData,
  orderData
}: WelcomeProps) {
  return (
    <Html>
      <Head />
      <Body style={main}>
        <Container style={container}>
          {/* Header */}
          <Section style={header}>
            <Img
              src="https://same-assets.com/custodia360/logo-email.png"
              width="120"
              height="40"
              alt="custodia360"
              style={logo}
            />
          </Section>

          {/* Welcome Message */}
          <Section style={welcomeSection}>
            <Text style={welcomeIcon}>👋</Text>
            <Heading style={title}>¡Bienvenido a custodia360!</Heading>
            <Text style={subtitle}>
              Tu implementación LOPIVI ya ha comenzado
            </Text>
          </Section>

          {/* Personal Greeting */}
          <Section style={greetingSection}>
            <Heading style={sectionTitle}>Hola {customerData.responsable},</Heading>
            <Text style={paragraph}>
              Gracias por confiar en <strong>custodia360</strong> para la protección de tu entidad
              <strong> {customerData.nombre_entidad}</strong>.
            </Text>
            <Text style={paragraph}>
              Nuestro equipo de especialistas ya está trabajando en tu implementación LOPIVI.
              En las próximas horas comenzarás a recibir toda la documentación personalizada.
            </Text>
          </Section>

          <Hr style={divider} />

          {/* Implementation Timeline */}
          <Section style={timelineSection}>
            <Heading style={sectionTitle}>⏰ Timeline de implementación</Heading>

            <div style={timelineItem}>
              <div style={timelineDot}></div>
              <div style={timelineContent}>
                <Text style={timelineTitle}>AHORA - Formulario de datos</Text>
                <Text style={timelineDesc}>
                  Completa el formulario con datos específicos de tu entidad para personalizar
                  tu plan de protección.
                </Text>
                <Button
                  href={`https://custodia360.es/formulario?id=${orderData.sessionId}`}
                  style={primaryButton}
                >
                  📋 Completar Formulario
                </Button>
              </div>
            </div>

            <div style={timelineItem}>
              <div style={timelineDot}></div>
              <div style={timelineContent}>
                <Text style={timelineTitle}>2 HORAS - Asignación de delegado</Text>
                <Text style={timelineDesc}>
                  Te asignaremos un delegado de protección especializado que será tu contacto
                  directo durante toda la implementación.
                </Text>
              </div>
            </div>

            <div style={timelineItem}>
              <div style={timelineDot}></div>
              <div style={timelineContent}>
                <Text style={timelineTitle}>6 HORAS - Análisis y documentación</Text>
                <Text style={timelineDesc}>
                  Crearemos tu plan de protección personalizado, protocolos de actuación y
                  toda la documentación necesaria.
                </Text>
              </div>
            </div>

            <div style={timelineItem}>
              <div style={timelineDotFinal}></div>
              <div style={timelineContent}>
                <Text style={timelineTitle}>24 HORAS - Implementación completa</Text>
                <Text style={timelineDesc}>
                  Recibirás tu plan completo, acceso al panel de gestión y formación para
                  tu equipo. ¡LOPIVI 100% implementada!
                </Text>
              </div>
            </div>
          </Section>

          <Hr style={divider} />

          {/* Documents Needed */}
          <Section style={documentsSection}>
            <Heading style={sectionTitle}>📄 Documentos que necesitaremos</Heading>
            <Text style={paragraph}>
              Para personalizar tu implementación, nos ayudaría tener estos documentos
              (si los tienes disponibles):
            </Text>

            <div style={documentsList}>
              <Text style={documentItem}>✓ Organigrama de la entidad</Text>
              <Text style={documentItem}>✓ Lista de personal que trabaja con menores</Text>
              <Text style={documentItem}>✓ Protocolos actuales (si los tienes)</Text>
              <Text style={documentItem}>✓ Instalaciones donde se desarrollan actividades</Text>
            </div>

            <Text style={noteText}>
              <strong>Nota:</strong> No te preocupes si no tienes algunos documentos.
              Nuestro equipo te ayudará a crearlos desde cero.
            </Text>
          </Section>

          <Hr style={divider} />

          {/* Next Communication */}
          <Section style={nextSection}>
            <Heading style={sectionTitle}>📬 Próximas comunicaciones</Heading>
            <Text style={paragraph}>
              Mantente atento a tu email. En las próximas horas recibirás:
            </Text>

            <div style={communicationsList}>
              <div style={commItem}>
                <Text style={commTime}>En 2 horas</Text>
                <Text style={commDesc}>📞 Contacto de tu delegado asignado</Text>
              </div>
              <div style={commItem}>
                <Text style={commTime}>En 6 horas</Text>
                <Text style={commDesc}>📋 Primer borrador de tu plan de protección</Text>
              </div>
              <div style={commItem}>
                <Text style={commTime}>En 24 horas</Text>
                <Text style={commDesc}>✅ Implementación completa + acceso al panel</Text>
              </div>
            </div>
          </Section>

          {/* Quick Contact */}
          <Section style={contactSection}>
            <div style={contactBox}>
              <Heading style={contactTitle}>💬 ¿Tienes alguna pregunta?</Heading>
              <Text style={contactText}>
                Nuestro equipo está disponible 24/7 para ayudarte:
              </Text>
              <div style={contactMethods}>
                <Text style={contactMethod}>📞 <strong>678 771 198</strong></Text>
                <Text style={contactMethod}>✉️ <strong>info@custodia360.es</strong></Text>
                <Text style={contactMethod}>💬 <strong>Chat en custodia360.es</strong></Text>
              </div>
              <Button
                href="https://custodia360.es/contacto"
                style={secondaryButton}
              >
                🚀 Contactar Ahora
              </Button>
            </div>
          </Section>

          {/* Footer */}
          <Section style={footer}>
            <Text style={footerText}>
              © 2025 custodia360 - Primera empresa automatizada de España especializada en LOPIVI
            </Text>
            <Text style={footerText}>
              Barcelona, España | info@custodia360.es | 678 771 198
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

// Estilos
const main = {
  backgroundColor: '#f6f9fc',
  fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Ubuntu,sans-serif',
}

const container = {
  backgroundColor: '#ffffff',
  margin: '0 auto',
  padding: '20px 0 48px',
  marginBottom: '64px',
  maxWidth: '600px',
}

const header = {
  padding: '20px 30px',
  backgroundColor: '#ffffff',
}

const logo = {
  margin: '0 auto',
}

const welcomeSection = {
  textAlign: 'center' as const,
  padding: '20px 30px',
}

const welcomeIcon = {
  fontSize: '48px',
  margin: '0',
}

const title = {
  color: '#ea580c',
  fontSize: '32px',
  fontWeight: 'bold',
  textAlign: 'center' as const,
  margin: '10px 0',
}

const subtitle = {
  color: '#6b7280',
  fontSize: '18px',
  textAlign: 'center' as const,
  margin: '0 0 20px 0',
}

const greetingSection = {
  padding: '0 30px',
}

const sectionTitle = {
  color: '#374151',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '0 0 15px 0',
}

const paragraph = {
  color: '#4b5563',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '0 0 15px 0',
}

const divider = {
  borderColor: '#e5e7eb',
  margin: '30px 0',
}

const timelineSection = {
  padding: '0 30px',
}

const timelineItem = {
  display: 'flex',
  marginBottom: '25px',
  alignItems: 'flex-start',
}

const timelineDot = {
  width: '12px',
  height: '12px',
  backgroundColor: '#ea580c',
  borderRadius: '50%',
  marginRight: '15px',
  marginTop: '6px',
  flexShrink: 0,
}

const timelineDotFinal = {
  width: '12px',
  height: '12px',
  backgroundColor: '#059669',
  borderRadius: '50%',
  marginRight: '15px',
  marginTop: '6px',
  flexShrink: 0,
}

const timelineContent = {
  flex: 1,
}

const timelineTitle = {
  color: '#374151',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 8px 0',
}

const timelineDesc = {
  color: '#6b7280',
  fontSize: '14px',
  lineHeight: '1.5',
  margin: '0 0 12px 0',
}

const primaryButton = {
  backgroundColor: '#ea580c',
  color: '#ffffff',
  padding: '12px 24px',
  borderRadius: '6px',
  textDecoration: 'none',
  fontWeight: 'bold',
  fontSize: '14px',
  display: 'inline-block',
}

const secondaryButton = {
  backgroundColor: '#ffffff',
  color: '#ea580c',
  padding: '12px 24px',
  borderRadius: '6px',
  textDecoration: 'none',
  fontWeight: 'bold',
  fontSize: '14px',
  display: 'inline-block',
  border: '2px solid #ea580c',
}

const documentsSection = {
  padding: '0 30px',
}

const documentsList = {
  backgroundColor: '#f9fafb',
  padding: '15px',
  borderRadius: '6px',
  margin: '15px 0',
}

const documentItem = {
  color: '#374151',
  fontSize: '14px',
  margin: '0 0 8px 0',
}

const noteText = {
  color: '#6b7280',
  fontSize: '13px',
  fontStyle: 'italic',
  margin: '15px 0 0 0',
}

const nextSection = {
  padding: '0 30px',
}

const communicationsList = {
  margin: '15px 0',
}

const commItem = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 0',
  borderBottom: '1px solid #f3f4f6',
}

const commTime = {
  color: '#ea580c',
  fontSize: '14px',
  fontWeight: 'bold',
  width: '100px',
  flexShrink: 0,
}

const commDesc = {
  color: '#374151',
  fontSize: '14px',
  flex: 1,
}

const contactSection = {
  padding: '0 30px',
}

const contactBox = {
  backgroundColor: '#f0f9ff',
  padding: '20px',
  borderRadius: '8px',
  textAlign: 'center' as const,
}

const contactTitle = {
  color: '#0369a1',
  fontSize: '18px',
  fontWeight: 'bold',
  margin: '0 0 10px 0',
}

const contactText = {
  color: '#374151',
  fontSize: '14px',
  margin: '0 0 15px 0',
}

const contactMethods = {
  margin: '15px 0',
}

const contactMethod = {
  color: '#374151',
  fontSize: '14px',
  margin: '0 0 5px 0',
}

const footer = {
  padding: '20px 30px',
  borderTop: '1px solid #e5e7eb',
  marginTop: '30px',
  textAlign: 'center' as const,
}

const footerText = {
  color: '#6b7280',
  fontSize: '12px',
  margin: '0 0 10px 0',
}
