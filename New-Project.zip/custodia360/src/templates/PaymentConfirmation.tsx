import React from 'react'
import {
  Html,
  Head,
  Body,
  Container,
  Section,
  Text,
  Heading,
  Hr,
  Button,
  Img,
} from '@react-email/components'
import { CustomerData, OrderData, formatPrice, formatDate } from '@/lib/email'

interface PaymentConfirmationProps {
  customerData: CustomerData
  orderData: OrderData
}

export default function PaymentConfirmationTemplate({
  customerData,
  orderData
}: PaymentConfirmationProps) {
  return (
    <Html>
      <Head />
      <Body style={main}>
        <Container style={container}>
          {/* Header */}
          <Section style={header}>
            <Img
              src="https://same-assets.com/custodia360/logo-email.png"
              width="120"
              height="40"
              alt="custodia360"
              style={logo}
            />
          </Section>

          {/* Success Message */}
          <Section style={successSection}>
            <Text style={successIcon}>✅</Text>
            <Heading style={title}>¡Pago Confirmado!</Heading>
            <Text style={subtitle}>
              Tu protección LOPIVI ya está en marcha
            </Text>
          </Section>

          {/* Customer Info */}
          <Section style={infoSection}>
            <Heading style={sectionTitle}>Hola {customerData.responsable},</Heading>
            <Text style={paragraph}>
              Tu pago de <strong>{formatPrice(orderData.amount)}</strong> ha sido procesado correctamente.
              ¡Bienvenido a custodia360!
            </Text>
          </Section>

          {/* Order Details */}
          <Section style={orderSection}>
            <Heading style={sectionTitle}>📄 Detalles del pedido</Heading>
            <table style={orderTable}>
              <tr>
                <td style={orderLabel}>Entidad:</td>
                <td style={orderValue}>{customerData.nombre_entidad}</td>
              </tr>
              <tr>
                <td style={orderLabel}>CIF:</td>
                <td style={orderValue}>{customerData.cif}</td>
              </tr>
              <tr>
                <td style={orderLabel}>Plan contratado:</td>
                <td style={orderValue}>{orderData.planName}</td>
              </tr>
              <tr>
                <td style={orderLabel}>Kit de Comunicación:</td>
                <td style={orderValue}>{orderData.includesKit ? 'Sí incluido' : 'No incluido'}</td>
              </tr>
              <tr>
                <td style={orderLabel}>Fecha de pago:</td>
                <td style={orderValue}>{formatDate(orderData.paymentDate)}</td>
              </tr>
              <tr>
                <td style={orderLabel}>ID de transacción:</td>
                <td style={orderValue}>{orderData.sessionId}</td>
              </tr>
              <tr style={totalRow}>
                <td style={orderLabel}><strong>Total pagado:</strong></td>
                <td style={orderValue}><strong>{formatPrice(orderData.amount)}</strong></td>
              </tr>
            </table>
          </Section>

          <Hr style={divider} />

          {/* Next Steps */}
          <Section style={stepsSection}>
            <Heading style={sectionTitle}>🚀 ¿Qué pasa ahora?</Heading>
            <Text style={stepTitle}>Próximas 24 horas:</Text>

            <div style={stepItem}>
              <Text style={stepNumber}>1.</Text>
              <Text style={stepText}>
                <strong>En 5 minutos:</strong> Recibirás un email con un formulario para completar
                datos específicos de tu entidad.
              </Text>
            </div>

            <div style={stepItem}>
              <Text style={stepNumber}>2.</Text>
              <Text style={stepText}>
                <strong>En 2 horas:</strong> Te asignaremos un delegado de protección especializado
                y comenzaremos la implementación.
              </Text>
            </div>

            <div style={stepItem}>
              <Text style={stepNumber}>3.</Text>
              <Text style={stepText}>
                <strong>En 24 horas:</strong> Tendrás tu plan de protección LOPIVI completo,
                documentación y acceso a tu panel de gestión.
              </Text>
            </div>
          </Section>

          <Hr style={divider} />

          {/* Important Info */}
          <Section style={importantSection}>
            <Heading style={sectionTitle}>📋 Información importante</Heading>
            <Text style={paragraph}>
              • <strong>Segundo pago:</strong> Se procesará automáticamente en 6 meses ({formatDate(new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000))})
            </Text>
            <Text style={paragraph}>
              • <strong>Factura:</strong> La recibirás por email en las próximas horas
            </Text>
            <Text style={paragraph}>
              • <strong>Soporte 24/7:</strong> Estamos aquí para ayudarte en todo momento
            </Text>
          </Section>

          {/* Contact */}
          <Section style={contactSection}>
            <Heading style={sectionTitle}>¿Necesitas ayuda?</Heading>
            <Text style={paragraph}>
              Nuestro equipo está disponible 24/7 para resolver cualquier duda:
            </Text>
            <Text style={contactInfo}>
              📞 <strong>678 771 198</strong><br />
              ✉️ <strong>info@custodia360.es</strong><br />
              🌐 <strong>custodia360.es</strong>
            </Text>
          </Section>

          {/* Footer */}
          <Section style={footer}>
            <Text style={footerText}>
              © 2025 custodia360. Primera empresa automatizada de España especializada en LOPIVI.
            </Text>
            <Text style={footerText}>
              Este email se envió a {customerData.email} porque contrataste nuestros servicios.
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

// Estilos
const main = {
  backgroundColor: '#f6f9fc',
  fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Ubuntu,sans-serif',
}

const container = {
  backgroundColor: '#ffffff',
  margin: '0 auto',
  padding: '20px 0 48px',
  marginBottom: '64px',
  maxWidth: '600px',
}

const header = {
  padding: '20px 30px',
  backgroundColor: '#ffffff',
}

const logo = {
  margin: '0 auto',
}

const successSection = {
  textAlign: 'center' as const,
  padding: '20px 30px',
}

const successIcon = {
  fontSize: '48px',
  margin: '0',
}

const title = {
  color: '#059669',
  fontSize: '32px',
  fontWeight: 'bold',
  textAlign: 'center' as const,
  margin: '10px 0',
}

const subtitle = {
  color: '#6b7280',
  fontSize: '18px',
  textAlign: 'center' as const,
  margin: '0 0 20px 0',
}

const infoSection = {
  padding: '0 30px',
}

const orderSection = {
  padding: '0 30px',
  margin: '30px 0',
}

const sectionTitle = {
  color: '#374151',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '0 0 15px 0',
}

const paragraph = {
  color: '#4b5563',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '0 0 15px 0',
}

const orderTable = {
  width: '100%',
  borderCollapse: 'collapse' as const,
}

const orderLabel = {
  color: '#6b7280',
  fontSize: '14px',
  padding: '8px 0',
  borderBottom: '1px solid #f3f4f6',
  width: '40%',
}

const orderValue = {
  color: '#374151',
  fontSize: '14px',
  fontWeight: '500',
  padding: '8px 0',
  borderBottom: '1px solid #f3f4f6',
}

const totalRow = {
  borderTop: '2px solid #d1d5db',
}

const divider = {
  borderColor: '#e5e7eb',
  margin: '30px 0',
}

const stepsSection = {
  padding: '0 30px',
}

const stepTitle = {
  color: '#059669',
  fontSize: '16px',
  fontWeight: 'bold',
  margin: '0 0 20px 0',
}

const stepItem = {
  display: 'flex',
  marginBottom: '15px',
  alignItems: 'flex-start',
}

const stepNumber = {
  backgroundColor: '#059669',
  color: '#ffffff',
  borderRadius: '50%',
  width: '24px',
  height: '24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '12px',
  fontWeight: 'bold',
  marginRight: '12px',
  flexShrink: 0,
}

const stepText = {
  color: '#4b5563',
  fontSize: '14px',
  lineHeight: '1.5',
  margin: '0',
}

const importantSection = {
  backgroundColor: '#fef3c7',
  borderRadius: '8px',
  margin: '20px 30px',
  padding: '20px',
}

const contactSection = {
  padding: '0 30px',
}

const contactInfo = {
  color: '#374151',
  fontSize: '14px',
  lineHeight: '1.6',
  margin: '0',
}

const footer = {
  padding: '20px 30px',
  borderTop: '1px solid #e5e7eb',
  marginTop: '30px',
}

const footerText = {
  color: '#6b7280',
  fontSize: '12px',
  textAlign: 'center' as const,
  margin: '0 0 10px 0',
}
