# Configuración de Stripe para Custodia360

## ✅ PROBLEMA SSR RESUELTO

La integración de Stripe ha sido implementada con las mejores prácticas para evitar errores de SSR:

- ✅ **Dynamic imports con `{ ssr: false }`** - Los componentes de Stripe solo se cargan en el cliente
- ✅ **Conditional rendering** - Verificaciones para asegurar que Stripe está disponible antes de usar
- ✅ **Separación de componentes** - Provider y componentes de checkout separados
- ✅ **Build exitoso** - Sin errores de prerendering

## Configuración Rápida para Deployment

### 1. Configurar Variables de Entorno

Copia `.env.example` a `.env.local` y añade tus claves reales de Stripe:

```bash
# Obtén estas claves de https://dashboard.stripe.com/apikeys
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_tu_clave_publica_aqui
STRIPE_SECRET_KEY=sk_live_tu_clave_secreta_aqui
```

### 2. Configurar Productos en Stripe Dashboard

Crea estos productos en tu dashboard de Stripe con los precios indicados:

- **Plan Básico**: €29.99/mes → `price_basic_monthly`
- **Plan Premium**: €59.99/mes → `price_premium_monthly`
- **Plan Enterprise**: €99.99/mes → `price_enterprise_monthly`

### 3. Actualizar Price IDs

Edita `src/lib/stripe.ts` y reemplaza los `priceId` con los reales de tu dashboard:

```typescript
export const STRIPE_PLANS = {
  basic: {
    priceId: 'price_1XxXxXxXxXxXxXxX', // Reemplazar con ID real
    // ... resto del plan
  }
  // ...
}
```

### 4. Verificar Build

```bash
bun run build
```

## Arquitectura SSR-Safe Implementada

### Dynamic Imports
```typescript
// ✅ CORRECTO - No causa errores SSR
const StripeCheckout = dynamic(
  () => import('@/components/StripeCheckout'),
  { ssr: false }
);
```

### Conditional Rendering
```typescript
// ✅ CORRECTO - Verifica que Stripe esté disponible
if (!stripe || !elements) {
  setError('Stripe no está disponible');
  return;
}
```

### Client-Side Only Components
```typescript
// ✅ CORRECTO - Componentes marcados con 'use client'
'use client';
import { useStripe, useElements } from '@stripe/react-stripe-js';
```

## Páginas Disponibles

- `/` - Landing page principal
- `/planes` - Página de selección de planes con checkout integrado

## Deployment Ready

El proyecto ahora puede ser deployado sin errores de SSR. El build genera:

- **Static pages**: `/`, `/planes`
- **API Routes**: `/api/stripe/create-payment-intent`
- **No errores de prerendering**: Todos los componentes de Stripe están client-side only

¡Listo para deployment a www.custodia360.es! 🚀
